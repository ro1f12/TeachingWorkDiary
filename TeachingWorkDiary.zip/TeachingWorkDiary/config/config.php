<?php
declare(strict_types=1);

const APP_NAME = 'Teaching & Work Diary';
const DB_HOST = '127.0.0.1';
const DB_NAME = 'teaching_work_diary';
const DB_USER = 'root';
const DB_PASS = '';
const BASE_URL = '/TeachingWorkDiary';
const TIMEZONE = 'Asia/Kolkata';

date_default_timezone_set(TIMEZONE);

// Production Error Handling: log to file, never expose errors, paths, or traces to end-users
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../error.log');
error_reporting(E_ALL);

// Secure session cookies
if (session_status() !== PHP_SESSION_ACTIVE) {
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => BASE_URL . '/',
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    }
    session_start();
}
