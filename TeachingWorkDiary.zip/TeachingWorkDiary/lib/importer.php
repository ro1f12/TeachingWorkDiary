<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/materializer.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 * Teaching & Work Diary — Reusable Academic Excel Importer
 * Lalit Chandra Bharali College, Department of Information Technology
 */
class AcademicImporter {

    private PDO $pdo;

    public function __construct(?PDO $pdo = null) {
        $this->pdo = $pdo ?? db();
    }

    /**
     * Parse uploaded Excel spreadsheet into rows
     */
    public function parseUploadedFile(array $file): array {
        if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException('Upload failed or no file uploaded.');
        }

        $allowedExts = ['xlsx', 'xls'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExts, true)) {
            throw new InvalidArgumentException('Invalid file format. Please upload a valid .xlsx or .xls Excel spreadsheet.');
        }

        if ($file['size'] > 10 * 1024 * 1024) {
            throw new InvalidArgumentException('File exceeds maximum allowed size (10MB).');
        }

        $spreadsheet = IOFactory::load($file['tmp_name']);
        $sheet = $spreadsheet->getSheetByName('Import Data') ?? $spreadsheet->getActiveSheet();
        $rawRows = $sheet->toArray(null, true, true, true);

        if (count($rawRows) < 2) {
            throw new InvalidArgumentException('The uploaded spreadsheet contains no data rows.');
        }

        return $rawRows;
    }

    /**
     * Validate parsed rows according to module rules
     */
    public function validate(string $module, array $rawRows, array $options = []): array {
        $headerRow = array_shift($rawRows); // remove row 1
        $totalRows = count($rawRows);
        $validRows = [];
        $errors = [];
        $warnings = [];

        // Preload reference maps for fast in-memory validation
        $progs = $this->pdo->query("SELECT id, short_code, name FROM programmes")->fetchAll(PDO::FETCH_ASSOC);
        $progByCode = [];
        foreach ($progs as $p) {
            $progByCode[strtoupper(trim($p['short_code']))] = $p['id'];
            $progByCode[strtoupper(trim($p['name']))] = $p['id'];
        }

        $sems = $this->pdo->query("SELECT id, name FROM semesters")->fetchAll(PDO::FETCH_ASSOC);
        $semByName = [];
        foreach ($sems as $s) {
            $semByName[strtoupper(trim($s['name']))] = $s['id'];
        }

        $teachers = $this->pdo->query("SELECT id, short_code, name FROM teachers")->fetchAll(PDO::FETCH_ASSOC);
        $teacherByCode = [];
        foreach ($teachers as $t) {
            $teacherByCode[strtoupper(trim($t['short_code']))] = $t['id'];
            $teacherByCode[strtoupper(trim($t['name']))] = $t['id'];
        }

        $rooms = $this->pdo->query("SELECT id, name FROM rooms")->fetchAll(PDO::FETCH_ASSOC);
        $roomByName = [];
        foreach ($rooms as $r) {
            $roomByName[strtoupper(trim($r['name']))] = $r['id'];
        }

        $papers = $this->pdo->query("SELECT id, code, name, programme_id, semester_id FROM papers")->fetchAll(PDO::FETCH_ASSOC);

        $rowNum = 1;
        foreach ($rawRows as $r) {
            $rowNum++;
            // Check if row is completely empty
            $nonEmpty = array_filter($r, fn($v) => $v !== null && trim((string)$v) !== '');
            if (!$nonEmpty) continue;

            $rowErrors = [];
            $rowWarnings = [];
            $parsed = [];

            switch ($module) {
                case 'timetable':
                    $session = trim((string)($r['A'] ?? '2026-27'));
                    $progCode = strtoupper(trim((string)($r['B'] ?? '')));
                    $semName = strtoupper(trim((string)($r['C'] ?? '')));
                    $dow = (int)($r['D'] ?? 0);
                    $startTime = trim((string)($r['E'] ?? ''));
                    $endTime = trim((string)($r['F'] ?? ''));
                    $paperCode = strtoupper(trim((string)($r['G'] ?? '')));
                    $teacherCode = strtoupper(trim((string)($r['H'] ?? '')));
                    $roomCode = strtoupper(trim((string)($r['I'] ?? '')));
                    $classType = ucfirst(strtolower(trim((string)($r['J'] ?? 'Theory'))));

                    // Validate Day
                    if ($dow < 1 || $dow > 6) {
                        $rowErrors[] = "Invalid Day of Week ($dow). Must be 1 to 6 (Monday to Saturday). Sundays are not permitted.";
                    }

                    // Validate Times
                    if (!preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/', $startTime)) {
                        $rowErrors[] = "Invalid Start Time format ('$startTime'). Use HH:MM format.";
                    }
                    if (!preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/', $endTime)) {
                        $rowErrors[] = "Invalid End Time format ('$endTime'). Use HH:MM format.";
                    }
                    if (strtotime($endTime) <= strtotime($startTime)) {
                        $rowErrors[] = "End time ($endTime) must be after start time ($startTime).";
                    }

                    // Validate Programme
                    if (!isset($progByCode[$progCode])) {
                        $rowErrors[] = "Unknown Programme ('$progCode'). Must match existing programme code.";
                    }
                    $pId = $progByCode[$progCode] ?? null;

                    // Validate Semester
                    if (!isset($semByName[$semName])) {
                        $rowErrors[] = "Unknown Semester ('$semName'). Must match existing semester.";
                    }
                    $sId = $semByName[$semName] ?? null;

                    // Validate Teacher
                    if (!isset($teacherByCode[$teacherCode])) {
                        $rowErrors[] = "Unknown Teacher ('$teacherCode').";
                    }
                    $tId = $teacherByCode[$teacherCode] ?? null;

                    // Validate Room
                    $rId = null;
                    if ($roomCode !== '') {
                        if (isset($roomByName[$roomCode])) {
                            $rId = $roomByName[$roomCode];
                        } else {
                            $rowWarnings[] = "Room '$roomCode' not found in master; will be left unassigned.";
                        }
                    }

                    // Validate Paper belongs to Prog + Sem
                    $matchedPaperId = null;
                    if ($pId && $sId) {
                        foreach ($papers as $pa) {
                            if ((int)$pa['programme_id'] === (int)$pId && 
                                (int)$pa['semester_id'] === (int)$sId && 
                                (strtoupper(trim($pa['code'] ?? '')) === $paperCode || strtoupper(trim($pa['name'])) === $paperCode)) {
                                $matchedPaperId = (int)$pa['id'];
                                break;
                            }
                        }
                        if (!$matchedPaperId) {
                            $rowErrors[] = "Paper '$paperCode' does not belong to Programme '$progCode' Semester '$semName'.";
                        }
                    }

                    $parsed = [
                        'row_num' => $rowNum,
                        'session_name' => $session,
                        'day_of_week' => $dow,
                        'start_time' => substr($startTime, 0, 5) . ':00',
                        'end_time' => substr($endTime, 0, 5) . ':00',
                        'programme_id' => $pId,
                        'semester_id' => $sId,
                        'paper_id' => $matchedPaperId,
                        'teacher_id' => $tId,
                        'room_id' => $rId,
                        'class_type' => in_array($classType, ['Theory', 'Practical', 'Tutorial']) ? $classType : 'Theory',
                        'raw' => $r
                    ];
                    break;

                case 'teachers':
                    $code = strtoupper(trim((string)($r['A'] ?? '')));
                    $name = trim((string)($r['B'] ?? ''));
                    $desig = trim((string)($r['C'] ?? 'Assistant Professor'));
                    $email = trim((string)($r['D'] ?? ''));
                    $active = (int)($r['E'] ?? 1);

                    if (!$code || !$name) {
                        $rowErrors[] = "Teacher Code and Full Name are required.";
                    }
                    $parsed = ['row_num' => $rowNum, 'short_code' => $code, 'name' => $name, 'designation' => $desig, 'email' => $email, 'active' => $active ? 1 : 0];
                    break;

                case 'programmes':
                    $code = strtoupper(trim((string)($r['A'] ?? '')));
                    $name = trim((string)($r['B'] ?? ''));
                    $short = strtoupper(trim((string)($r['C'] ?? $code)));
                    $active = (int)($r['D'] ?? 1);
                    if (!$name) $rowErrors[] = "Programme Name is required.";
                    $parsed = ['row_num' => $rowNum, 'short_code' => $short ?: $code, 'name' => $name, 'active' => $active ? 1 : 0];
                    break;

                case 'semesters':
                    $name = trim((string)($r['A'] ?? ''));
                    $active = (int)($r['B'] ?? 1);
                    if (!$name) $rowErrors[] = "Semester Name is required.";
                    $parsed = ['row_num' => $rowNum, 'name' => $name, 'active' => $active ? 1 : 0];
                    break;

                case 'papers':
                    $code = strtoupper(trim((string)($r['A'] ?? '')));
                    $name = trim((string)($r['B'] ?? ''));
                    $progCode = strtoupper(trim((string)($r['C'] ?? '')));
                    $semName = strtoupper(trim((string)($r['D'] ?? '')));
                    $active = (int)($r['E'] ?? 1);

                    if (!$name) $rowErrors[] = "Paper Name is required.";
                    if (!isset($progByCode[$progCode])) $rowErrors[] = "Unknown Programme '$progCode'.";
                    if (!isset($semByName[$semName])) $rowErrors[] = "Unknown Semester '$semName'.";

                    $parsed = [
                        'row_num' => $rowNum,
                        'code' => $code,
                        'name' => $name,
                        'programme_id' => $progByCode[$progCode] ?? null,
                        'semester_id' => $semByName[$semName] ?? null,
                        'active' => $active ? 1 : 0
                    ];
                    break;

                case 'rooms':
                    $name = trim((string)($r['A'] ?? ''));
                    $type = trim((string)($r['B'] ?? 'Classroom'));
                    $active = (int)($r['C'] ?? 1);
                    if (!$name) $rowErrors[] = "Room / Lab Code is required.";
                    $parsed = ['row_num' => $rowNum, 'name' => $name, 'room_type' => $type, 'active' => $active ? 1 : 0];
                    break;

                case 'class_strength':
                    $sess = trim((string)($r['A'] ?? '2026-27'));
                    $progCode = strtoupper(trim((string)($r['B'] ?? '')));
                    $semName = strtoupper(trim((string)($r['C'] ?? '')));
                    $strength = (int)($r['D'] ?? 0);
                    $active = (int)($r['E'] ?? 1);

                    if ($strength <= 0) $rowErrors[] = "Class strength must be a positive integer.";
                    if (!isset($progByCode[$progCode])) $rowErrors[] = "Unknown Programme '$progCode'.";
                    if (!isset($semByName[$semName])) $rowErrors[] = "Unknown Semester '$semName'.";

                    $parsed = [
                        'row_num' => $rowNum,
                        'session_name' => $sess,
                        'programme_id' => $progByCode[$progCode] ?? null,
                        'semester_id' => $semByName[$semName] ?? null,
                        'strength' => $strength,
                        'active' => $active ? 1 : 0
                    ];
                    break;

                case 'holidays':
                    $hDate = trim((string)($r['A'] ?? ''));
                    $title = trim((string)($r['B'] ?? ''));
                    $type = strtolower(trim((string)($r['C'] ?? 'official')));
                    $active = (int)($r['D'] ?? 1);

                    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $hDate)) {
                        $rowErrors[] = "Date must be in YYYY-MM-DD format ('$hDate').";
                    }
                    if (!$title) $rowErrors[] = "Holiday Name is required.";
                    if (!in_array($type, ['official', 'local', 'restricted'], true)) {
                        $type = 'local';
                    }

                    // Protect authoritative GU holidays
                    $chkGu = $this->pdo->prepare("SELECT id, title, holiday_type FROM holidays WHERE holiday_date=? AND holiday_type='official'");
                    $chkGu->execute([$hDate]);
                    $existingGu = $chkGu->fetch();
                    if ($existingGu && strtolower($existingGu['title']) !== strtolower($title)) {
                        $rowWarnings[] = "Date $hDate is already an authoritative Official Holiday ('{$existingGu['title']}').";
                    }

                    $parsed = [
                        'row_num' => $rowNum,
                        'holiday_date' => $hDate,
                        'title' => $title,
                        'holiday_type' => $type,
                        'active' => $active ? 1 : 0
                    ];
                    break;

                case 'duty_types':
                    $name = trim((string)($r['A'] ?? ''));
                    $desc = trim((string)($r['B'] ?? ''));
                    $active = (int)($r['C'] ?? 1);
                    if (!$name) $rowErrors[] = "Duty Type Name is required.";
                    $parsed = ['row_num' => $rowNum, 'name' => $name, 'description' => $desc, 'active' => $active ? 1 : 0];
                    break;

                case 'additional_works':
                    $wDate = trim((string)($r['A'] ?? ''));
                    $st = trim((string)($r['B'] ?? ''));
                    $et = trim((string)($r['C'] ?? ''));
                    $tCode = strtoupper(trim((string)($r['D'] ?? '')));
                    $wType = trim((string)($r['E'] ?? 'Official Meeting'));
                    $details = trim((string)($r['F'] ?? ''));
                    $dur = trim((string)($r['G'] ?? ''));
                    $rem = trim((string)($r['H'] ?? ''));

                    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $wDate)) $rowErrors[] = "Invalid Date format ('$wDate').";
                    if (!isset($teacherByCode[$tCode])) $rowErrors[] = "Unknown Teacher '$tCode'.";
                    if (!$details) $rowErrors[] = "Details / Description is required.";

                    $parsed = [
                        'row_num' => $rowNum,
                        'work_date' => $wDate,
                        'start_time' => $st ?: null,
                        'end_time' => $et ?: null,
                        'teacher_id' => $teacherByCode[$tCode] ?? null,
                        'work_type' => $wType,
                        'details' => $details,
                        'duration' => $dur,
                        'remarks' => $rem
                    ];
                    break;

                case 'duties':
                    $dDate = trim((string)($r['A'] ?? ''));
                    $st = trim((string)($r['B'] ?? ''));
                    $et = trim((string)($r['C'] ?? ''));
                    $tCode = strtoupper(trim((string)($r['D'] ?? '')));
                    $dType = trim((string)($r['E'] ?? 'Invigilation Duty'));
                    $details = trim((string)($r['F'] ?? ''));
                    $status = trim((string)($r['G'] ?? 'Planned'));
                    $rem = trim((string)($r['H'] ?? ''));

                    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dDate)) $rowErrors[] = "Invalid Date format ('$dDate').";
                    if (!isset($teacherByCode[$tCode])) $rowErrors[] = "Unknown Teacher '$tCode'.";
                    if (!$details) $rowErrors[] = "Details is required.";

                    $parsed = [
                        'row_num' => $rowNum,
                        'duty_date' => $dDate,
                        'start_time' => $st ?: null,
                        'end_time' => $et ?: null,
                        'teacher_id' => $teacherByCode[$tCode] ?? null,
                        'duty_type' => $dType,
                        'details' => $details,
                        'status' => in_array($status, ['Planned', 'Completed', 'Cancelled']) ? $status : 'Planned',
                        'remarks' => $rem
                    ];
                    break;
            }

            if ($rowErrors) {
                $errors[] = ['row' => $rowNum, 'messages' => $rowErrors, 'data' => $r];
            } else {
                $validRows[] = $parsed;
            }
            if ($rowWarnings) {
                $warnings[] = ['row' => $rowNum, 'messages' => $rowWarnings];
            }
        }

        return [
            'total' => $totalRows,
            'valid_count' => count($validRows),
            'error_count' => count($errors),
            'warning_count' => count($warnings),
            'valid_rows' => $validRows,
            'errors' => $errors,
            'warnings' => $warnings
        ];
    }

    /**
     * Commit valid rows to database within an atomic transaction
     */
    public function commitImport(string $module, array $validRows, array $options = []): array {
        $mode = $options['mode'] ?? 'add_new'; // 'add_new', 'update_existing', 'replace_session'
        $imported = 0;
        $updated = 0;
        $skipped = 0;

        $this->pdo->beginTransaction();
        try {
            switch ($module) {
                case 'timetable':
                    // If mode is replace_session, deactivate existing entries for this session
                    if ($mode === 'replace_session') {
                        $this->pdo->exec("UPDATE timetable SET active = 0");
                    }

                    $checkSt = $this->pdo->prepare("
                        SELECT id FROM timetable 
                        WHERE day_of_week=? AND start_time=? AND end_time=? AND teacher_id=? AND programme_id=? AND semester_id=? AND paper_id=? AND active=1
                    ");
                    $insSt = $this->pdo->prepare("
                        INSERT INTO timetable(day_of_week, start_time, end_time, teacher_id, programme_id, semester_id, paper_id, room_id, class_type, active)
                        VALUES(?,?,?,?,?,?,?,?,?,1)
                    ");
                    $updSt = $this->pdo->prepare("
                        UPDATE timetable 
                        SET room_id=?, class_type=?, active=1
                        WHERE id=?
                    ");

                    foreach ($validRows as $r) {
                        $checkSt->execute([$r['day_of_week'], $r['start_time'], $r['end_time'], $r['teacher_id'], $r['programme_id'], $r['semester_id'], $r['paper_id']]);
                        $existingId = $checkSt->fetchColumn();

                        if ($existingId) {
                            if ($mode === 'update_existing') {
                                $updSt->execute([$r['room_id'], $r['class_type'], $existingId]);
                                $updated++;
                            } else {
                                $skipped++;
                            }
                        } else {
                            $insSt->execute([
                                $r['day_of_week'], $r['start_time'], $r['end_time'],
                                $r['teacher_id'], $r['programme_id'], $r['semester_id'],
                                $r['paper_id'], $r['room_id'], $r['class_type']
                            ]);
                            $imported++;
                        }
                    }
                    break;

                case 'teachers':
                    $st = $this->pdo->prepare("
                        INSERT INTO teachers(short_code, name, designation, email, active)
                        VALUES(?,?,?,?,?)
                        ON DUPLICATE KEY UPDATE name=VALUES(name), designation=VALUES(designation), email=VALUES(email), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['short_code'], $r['name'], $r['designation'], $r['email'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'programmes':
                    $st = $this->pdo->prepare("
                        INSERT INTO programmes(short_code, name, active)
                        VALUES(?,?,?)
                        ON DUPLICATE KEY UPDATE name=VALUES(name), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['short_code'], $r['name'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'semesters':
                    $st = $this->pdo->prepare("
                        INSERT INTO semesters(name, active) VALUES(?,?)
                        ON DUPLICATE KEY UPDATE active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['name'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'papers':
                    $st = $this->pdo->prepare("
                        INSERT INTO papers(code, name, programme_id, semester_id, active)
                        VALUES(?,?,?,?,?)
                        ON DUPLICATE KEY UPDATE name=VALUES(name), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['code'], $r['name'], $r['programme_id'], $r['semester_id'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'rooms':
                    $st = $this->pdo->prepare("
                        INSERT INTO rooms(name, room_type, active) VALUES(?,?,?)
                        ON DUPLICATE KEY UPDATE room_type=VALUES(room_type), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['name'], $r['room_type'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'class_strength':
                    $st = $this->pdo->prepare("
                        INSERT INTO class_strength(session_name, programme_id, semester_id, strength, active)
                        VALUES(?,?,?,?,?)
                        ON DUPLICATE KEY UPDATE strength=VALUES(strength), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['session_name'], $r['programme_id'], $r['semester_id'], $r['strength'], $r['active']]);
                        // Propagate strength using existing validated engine:
                        propagate_class_strength($this->pdo, (int)$r['programme_id'], (int)$r['semester_id'], $r['session_name'], (int)$r['strength']);
                        $imported++;
                    }
                    break;

                case 'holidays':
                    $st = $this->pdo->prepare("
                        INSERT INTO holidays(holiday_date, title, holiday_type, active)
                        VALUES(?,?,?,?)
                        ON DUPLICATE KEY UPDATE title=VALUES(title), holiday_type=VALUES(holiday_type), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['holiday_date'], $r['title'], $r['holiday_type'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'duty_types':
                    $st = $this->pdo->prepare("
                        INSERT INTO duty_types(name, description, active) VALUES(?,?,?)
                        ON DUPLICATE KEY UPDATE description=VALUES(description), active=VALUES(active)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([$r['name'], $r['description'], $r['active']]);
                        $imported++;
                    }
                    break;

                case 'additional_works':
                    $st = $this->pdo->prepare("
                        INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks)
                        VALUES(?,?,?,?,?,?,?,?)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([
                            $r['work_date'], $r['start_time'], $r['end_time'],
                            $r['teacher_id'], $r['work_type'], $r['details'],
                            $r['duration'], $r['remarks']
                        ]);
                        $imported++;
                    }
                    break;

                case 'duties':
                    $st = $this->pdo->prepare("
                        INSERT INTO duties(duty_date, start_time, end_time, teacher_id, duty_type, details, status, remarks)
                        VALUES(?,?,?,?,?,?,?,?)
                    ");
                    foreach ($validRows as $r) {
                        $st->execute([
                            $r['duty_date'], $r['start_time'], $r['end_time'],
                            $r['teacher_id'], $r['duty_type'], $r['details'],
                            $r['status'], $r['remarks']
                        ]);
                        $imported++;
                    }
                    break;
            }

            $this->pdo->commit();
            return [
                'success' => true,
                'imported' => $imported,
                'updated' => $updated,
                'skipped' => $skipped
            ];
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'imported' => 0,
                'updated' => 0,
                'skipped' => 0
            ];
        }
    }
}
