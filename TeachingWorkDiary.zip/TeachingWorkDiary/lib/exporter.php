<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

/**
 * Teaching & Work Diary — Reusable Academic Excel Exporter
 * Lalit Chandra Bharali College, Department of Information Technology
 */
class AcademicExporter {

    private PDO $pdo;

    public function __construct(?PDO $pdo = null) {
        $this->pdo = $pdo ?? db();
    }

    /**
     * Download Excel template with instructions and reference values
     */
    public function downloadTemplate(string $module): void {
        $spreadsheet = $this->buildTemplateSpreadsheet($module);
        $filename = 'Template_' . ucfirst($module) . '_' . date('Ymd') . '.xlsx';
        $this->streamSpreadsheet($spreadsheet, $filename);
    }

    /**
     * Generate Excel template binary bytes
     */
    public function generateTemplateBytes(string $module): string {
        $spreadsheet = $this->buildTemplateSpreadsheet($module);
        return $this->getSpreadsheetBytes($spreadsheet);
    }

    /**
     * Build template Spreadsheet object
     */
    public function buildTemplateSpreadsheet(string $module): Spreadsheet {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()
            ->setCreator('Lalit Chandra Bharali College')
            ->setTitle(ucfirst($module) . ' Import Template');

        // Sheet 1: Import Data
        $dataSheet = $spreadsheet->getActiveSheet();
        $dataSheet->setTitle('Import Data');

        $headers = $this->getTemplateHeaders($module);
        $sampleRows = $this->getTemplateSamples($module);

        $colChar = 'A';
        foreach ($headers as $h) {
            $dataSheet->setCellValue($colChar . '1', $h);
            $colChar++;
        }
        $lastCol = chr(ord('A') + max(0, count($headers) - 1));

        // Style header row
        $headerRange = 'A1:' . $lastCol . '1';
        $dataSheet->getStyle($headerRange)->applyFromArray([
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF'], 'size' => 10],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '112A4A']],
            'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => Alignment::HORIZONTAL_CENTER],
            'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '0A1B30']]]
        ]);
        $dataSheet->getRowDimension(1)->setRowHeight(24);
        $dataSheet->freezePane('A2');

        // Populate sample rows
        $rIdx = 2;
        foreach ($sampleRows as $row) {
            $cChar = 'A';
            foreach ($row as $val) {
                $dataSheet->setCellValue($cChar . $rIdx, $val);
                $cChar++;
            }
            $rIdx++;
        }

        // Auto width
        $colChar = 'A';
        for ($i = 0; $i < count($headers); $i++) {
            $dataSheet->getColumnDimension($colChar)->setAutoSize(true);
            $colChar++;
        }

        // Sheet 2: Instructions
        $instSheet = $spreadsheet->createSheet();
        $instSheet->setTitle('Instructions');
        $this->populateInstructions($instSheet, $module);

        // Sheet 3: Reference Values
        $refSheet = $spreadsheet->createSheet();
        $refSheet->setTitle('Reference Values');
        $this->populateReferenceValues($refSheet, $module);

        $spreadsheet->setActiveSheetIndex(0);
        return $spreadsheet;
    }

    /**
     * Download exported data as Excel
     */
    public function exportData(string $module, array $filters = []): void {
        $spreadsheet = $this->buildExportSpreadsheet($module, $filters);
        $filename = ucfirst($module) . '_Export_' . date('Ymd_His') . '.xlsx';
        $this->streamSpreadsheet($spreadsheet, $filename);
    }

    /**
     * Export data to binary bytes
     */
    public function exportDataBytes(string $module, array $filters = []): string {
        $spreadsheet = $this->buildExportSpreadsheet($module, $filters);
        return $this->getSpreadsheetBytes($spreadsheet);
    }

    /**
     * Export diary to Excel
     */
    public function exportDiary(array $filters = []): void {
        $this->exportData('diary', $filters);
    }

    /**
     * Export diary to binary bytes
     */
    public function exportDiaryBytes(array $filters = []): string {
        return $this->exportDataBytes('diary', $filters);
    }

    /**
     * Build exported data Spreadsheet object
     */
    public function buildExportSpreadsheet(string $module, array $filters = []): Spreadsheet {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle(ucfirst($module));

        $headers = [];
        $rows = [];

        switch ($module) {
            case 'timetable':
                $headers = ['Academic Session', 'Day of Week', 'Day Name', 'Start Time', 'End Time', 'Programme', 'Semester', 'Paper Code', 'Paper Name', 'Teacher Code', 'Teacher Name', 'Room', 'Class Type', 'Status'];
                $q = "
                    SELECT '2026-27' as session_name, t.day_of_week, 
                           CASE t.day_of_week 
                               WHEN 1 THEN 'Monday' WHEN 2 THEN 'Tuesday' WHEN 3 THEN 'Wednesday'
                               WHEN 4 THEN 'Thursday' WHEN 5 THEN 'Friday' WHEN 6 THEN 'Saturday' ELSE 'Sunday'
                           END as day_name,
                           t.start_time, t.end_time, p.short_code as prog, s.name as sem,
                           pa.code as pcode, pa.name as pname, te.short_code as tcode, te.name as tname,
                           r.name as room, t.class_type, IF(t.active=1, 'Active', 'Inactive') as status
                    FROM timetable t
                    JOIN teachers te ON te.id = t.teacher_id
                    JOIN programmes p ON p.id = t.programme_id
                    JOIN semesters s ON s.id = t.semester_id
                    JOIN papers pa ON pa.id = t.paper_id
                    LEFT JOIN rooms r ON r.id = t.room_id
                    WHERE t.active = 1
                ";
                $args = [];
                if (!empty($filters['teacher_id'])) { $q .= ' AND t.teacher_id = ?'; $args[] = (int)$filters['teacher_id']; }
                if (!empty($filters['programme_id'])) { $q .= ' AND t.programme_id = ?'; $args[] = (int)$filters['programme_id']; }
                if (!empty($filters['day_of_week'])) { $q .= ' AND t.day_of_week = ?'; $args[] = (int)$filters['day_of_week']; }
                $q .= ' ORDER BY t.day_of_week, t.start_time';
                $st = $this->pdo->prepare($q);
                $st->execute($args);
                $rows = $st->fetchAll(PDO::FETCH_NUM);
                break;

            case 'teachers':
                $headers = ['Teacher Code', 'Full Name', 'Designation', 'Department', 'Email Address', 'Status'];
                $q = "SELECT short_code, name, designation, 'Department of Information Technology' as dept, email, IF(active=1, 'Active', 'Inactive') FROM teachers ORDER BY name";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'programmes':
                $headers = ['Programme Code', 'Programme Name', 'Short Code', 'Status'];
                $q = "SELECT short_code, name, short_code, IF(active=1, 'Active', 'Inactive') FROM programmes ORDER BY name";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'semesters':
                $headers = ['Semester Name', 'Status'];
                $q = "SELECT name, IF(active=1, 'Active', 'Inactive') FROM semesters ORDER BY id";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'papers':
                $headers = ['Paper Code', 'Paper Name', 'Programme', 'Semester', 'Status'];
                $q = "
                    SELECT pa.code, pa.name, p.short_code as prog, s.name as sem, IF(pa.active=1, 'Active', 'Inactive')
                    FROM papers pa
                    LEFT JOIN programmes p ON p.id = pa.programme_id
                    LEFT JOIN semesters s ON s.id = pa.semester_id
                    ORDER BY p.name, s.id, pa.name
                ";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'rooms':
                $headers = ['Room / Lab Code', 'Room Type', 'Status'];
                $q = "SELECT name, room_type, IF(active=1, 'Active', 'Inactive') FROM rooms ORDER BY name";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'class_strength':
                $headers = ['Academic Session', 'Programme', 'Semester', 'Strength', 'Status'];
                $q = "
                    SELECT cs.session_name, p.short_code, s.name, cs.strength, IF(cs.active=1, 'Active', 'Inactive')
                    FROM class_strength cs
                    JOIN programmes p ON p.id = cs.programme_id
                    JOIN semesters s ON s.id = cs.semester_id
                    ORDER BY cs.session_name, p.name, s.id
                ";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'holidays':
                $headers = ['Holiday Date', 'Holiday Name', 'Holiday Type', 'Status'];
                $q = "SELECT holiday_date, title, holiday_type, IF(active=1, 'Active', 'Inactive') FROM holidays ORDER BY holiday_date";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'duty_types':
                $headers = ['Duty Type Name', 'Description', 'Status'];
                $q = "SELECT name, description, IF(active=1, 'Active', 'Inactive') FROM duty_types ORDER BY name";
                $rows = $this->pdo->query($q)->fetchAll(PDO::FETCH_NUM);
                break;

            case 'additional_works':
                $headers = ['Work Date', 'Start Time', 'End Time', 'Teacher Code', 'Teacher Name', 'Work Type', 'Details / Subject', 'Duration', 'Remarks'];
                $q = "
                    SELECT w.work_date, w.start_time, w.end_time, t.short_code, t.name, w.work_type, w.details, w.duration, w.remarks
                    FROM additional_works w
                    JOIN teachers t ON t.id = w.teacher_id
                ";
                $args = [];
                $where = [];
                if (!empty($filters['from'])) { $where[] = 'w.work_date >= ?'; $args[] = $filters['from']; }
                if (!empty($filters['to'])) { $where[] = 'w.work_date <= ?'; $args[] = $filters['to']; }
                if (!empty($filters['teacher_id'])) { $where[] = 'w.teacher_id = ?'; $args[] = (int)$filters['teacher_id']; }
                if ($where) $q .= ' WHERE ' . implode(' AND ', $where);
                $q .= ' ORDER BY w.work_date DESC, w.start_time DESC';
                $st = $this->pdo->prepare($q);
                $st->execute($args);
                $rows = $st->fetchAll(PDO::FETCH_NUM);
                break;

            case 'duties':
                $headers = ['Duty Date', 'Start Time', 'End Time', 'Teacher Code', 'Teacher Name', 'Duty Type', 'Details', 'Status', 'Remarks'];
                $q = "
                    SELECT d.duty_date, d.start_time, d.end_time, t.short_code, t.name, d.duty_type, d.details, d.status, d.remarks
                    FROM duties d
                    JOIN teachers t ON t.id = d.teacher_id
                ";
                $args = [];
                $where = [];
                if (!empty($filters['from'])) { $where[] = 'd.duty_date >= ?'; $args[] = $filters['from']; }
                if (!empty($filters['to'])) { $where[] = 'd.duty_date <= ?'; $args[] = $filters['to']; }
                if (!empty($filters['teacher_id'])) { $where[] = 'd.teacher_id = ?'; $args[] = (int)$filters['teacher_id']; }
                if ($where) $q .= ' WHERE ' . implode(' AND ', $where);
                $q .= ' ORDER BY d.duty_date DESC, d.start_time DESC';
                $st = $this->pdo->prepare($q);
                $st->execute($args);
                $rows = $st->fetchAll(PDO::FETCH_NUM);
                break;

            case 'diary':
                $headers = [
                    'Date', 'Actual Start', 'Actual End', 'Actual Teacher Code', 'Actual Teacher',
                    'Original Date', 'Original Start', 'Original End', 'Scheduled Teacher',
                    'Programme', 'Semester', 'Paper Code', 'Paper Name', 'Room', 'Class Type',
                    'Present', 'Total Strength', 'Status', 'Topic / Curriculum', 'Remarks', 'Edit State'
                ];
                $q = "
                    SELECT d.diary_date, d.start_time, d.end_time, t.short_code, t.name,
                           d.original_date, d.original_start_time, d.original_end_time, ot.name as orig_teacher,
                           p.short_code as prog, s.name as sem, pa.code as pcode, pa.name as pname,
                           r.name as room, d.class_type, d.present, d.total, d.status, d.topic, d.remarks,
                           IF(d.is_edited=1, 'Confirmed / Edited', 'Untouched Auto') as state
                    FROM diary d
                    JOIN teachers t ON t.id = d.teacher_id
                    LEFT JOIN teachers ot ON ot.id = d.original_teacher_id
                    JOIN programmes p ON p.id = d.programme_id
                    JOIN semesters s ON s.id = d.semester_id
                    JOIN papers pa ON pa.id = d.paper_id
                    LEFT JOIN rooms r ON r.id = d.room_id
                ";
                $args = [];
                $where = [];
                if (!empty($filters['from'])) { $where[] = 'd.diary_date >= ?'; $args[] = $filters['from']; }
                if (!empty($filters['to'])) { $where[] = 'd.diary_date <= ?'; $args[] = $filters['to']; }
                if (!empty($filters['teacher_id'])) { $where[] = 'd.teacher_id = ?'; $args[] = (int)$filters['teacher_id']; }
                if (!empty($filters['programme_id'])) { $where[] = 'd.programme_id = ?'; $args[] = (int)$filters['programme_id']; }
                if (!empty($filters['semester_id'])) { $where[] = 'd.semester_id = ?'; $args[] = (int)$filters['semester_id']; }
                if (!empty($filters['paper_id'])) { $where[] = 'd.paper_id = ?'; $args[] = (int)$filters['paper_id']; }
                if (!empty($filters['status'])) { $where[] = 'd.status = ?'; $args[] = $filters['status']; }
                if ($where) $q .= ' WHERE ' . implode(' AND ', $where);
                $q .= ' ORDER BY d.diary_date, d.start_time, p.name';
                $st = $this->pdo->prepare($q);
                $st->execute($args);
                $rows = $st->fetchAll(PDO::FETCH_NUM);
                break;
        }

        // Render header
        $colChar = 'A';
        foreach ($headers as $h) {
            $sheet->setCellValue($colChar . '1', $h);
            $colChar++;
        }
        $lastCol = chr(ord('A') + max(0, count($headers) - 1));

        $sheet->getStyle('A1:' . $lastCol . '1')->applyFromArray([
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF'], 'size' => 10],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '112A4A']],
            'alignment' => ['vertical' => Alignment::VERTICAL_CENTER, 'horizontal' => Alignment::HORIZONTAL_CENTER],
            'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '0A1B30']]]
        ]);
        $sheet->getRowDimension(1)->setRowHeight(24);
        $sheet->freezePane('A2');

        // Populate rows
        $rIdx = 2;
        foreach ($rows as $r) {
            $cChar = 'A';
            foreach ($r as $val) {
                $sheet->setCellValue($cChar . $rIdx, $val);
                $cChar++;
            }
            $rIdx++;
        }

        // Auto width
        $colChar = 'A';
        for ($i = 0; $i < count($headers); $i++) {
            $sheet->getColumnDimension($colChar)->setAutoSize(true);
            $colChar++;
        }

        return $spreadsheet;
    }

    private function getTemplateHeaders(string $module): array {
        switch ($module) {
            case 'timetable':
                return ['Academic Session', 'Programme', 'Semester', 'Day of Week (1-6)', 'Start Time (HH:MM)', 'End Time (HH:MM)', 'Paper Code', 'Teacher Code', 'Room Code', 'Class Type (Theory/Practical)'];
            case 'teachers':
                return ['Teacher Code', 'Full Name', 'Designation', 'Email Address', 'Active (1/0)'];
            case 'programmes':
                return ['Programme Code', 'Programme Name', 'Short Code', 'Active (1/0)'];
            case 'semesters':
                return ['Semester Name (e.g. 1st, 3rd, 5th)', 'Active (1/0)'];
            case 'papers':
                return ['Paper Code', 'Paper Name', 'Programme Code', 'Semester Name', 'Active (1/0)'];
            case 'rooms':
                return ['Room / Lab Code', 'Room Type (e.g. Theory / Lab)', 'Active (1/0)'];
            case 'class_strength':
                return ['Academic Session (e.g. 2026-27)', 'Programme Code', 'Semester Name', 'Class Strength', 'Active (1/0)'];
            case 'holidays':
                return ['Date (YYYY-MM-DD)', 'Holiday Name', 'Holiday Type (official/local/restricted)', 'Active (1/0)'];
            case 'duty_types':
                return ['Duty Type Name', 'Description', 'Active (1/0)'];
            case 'additional_works':
                return ['Date (YYYY-MM-DD)', 'Start Time (HH:MM)', 'End Time (HH:MM)', 'Teacher Code', 'Work Type', 'Details / Description', 'Duration (e.g. 2 hrs)', 'Remarks'];
            case 'duties':
                return ['Date (YYYY-MM-DD)', 'Start Time (HH:MM)', 'End Time (HH:MM)', 'Teacher Code', 'Duty Type', 'Details', 'Status (Planned/Completed/Cancelled)', 'Remarks'];
            default:
                return ['Field 1', 'Field 2'];
        }
    }

    private function getTemplateSamples(string $module): array {
        switch ($module) {
            case 'timetable':
                return [
                    ['2026-27', 'BCA', '3rd', '1', '10:00', '11:00', 'OOP', 'MAR', 'C222', 'Theory'],
                    ['2026-27', 'BSc-IT', '3rd', '2', '13:00', '14:00', 'OOP', 'MAR', 'C225', 'Practical'],
                    ['2026-27', 'PGDCA', '1st', '6', '10:00', '11:00', 'PGDCA-OA', 'MN', 'C224', 'Theory']
                ];
            case 'teachers':
                return [
                    ['MAR', 'Masud Alam Rofi', 'Assistant Professor', 'mar@lcba.edu.in', '1'],
                    ['PLP', 'Parag Lahkar', 'Assistant Professor', 'plp@lcba.edu.in', '1']
                ];
            case 'programmes':
                return [
                    ['BCA', 'Bachelor of Computer Applications', 'BCA', '1'],
                    ['BSc-IT', 'B.Sc. in Information Technology', 'BSc-IT', '1']
                ];
            case 'semesters':
                return [
                    ['1st', '1'], ['3rd', '1'], ['5th', '1']
                ];
            case 'papers':
                return [
                    ['OOP', 'Object Oriented Programming using C++', 'BCA', '3rd', '1'],
                    ['CIT0100104-N', 'Introduction to C-Programming', 'BSc-IT', '1st', '1']
                ];
            case 'rooms':
                return [
                    ['C222', 'Theory Classroom', '1'],
                    ['C225', 'Computer Laboratory', '1']
                ];
            case 'class_strength':
                return [
                    ['2026-27', 'BCA', '3rd', '60', '1'],
                    ['2026-27', 'BSc-IT', '1st', '30', '1']
                ];
            case 'holidays':
                return [
                    ['2026-10-02', 'Birthday of Mahatma Gandhi', 'official', '1'],
                    ['2026-01-01', 'New Year’s Day', 'restricted', '1']
                ];
            case 'duty_types':
                return [
                    ['Invigilation Duty', 'Semester examination invigilation', '1'],
                    ['Official Meeting', 'Departmental or academic meeting', '1']
                ];
            case 'additional_works':
                return [
                    ['2026-10-07', '14:00', '16:00', 'MAR', 'Official Meeting', 'Departmental syllabus verification meeting', '2 hrs', 'All faculty attended']
                ];
            case 'duties':
                return [
                    ['2026-10-07', '09:00', '12:00', 'MAR', 'Invigilation Duty', 'Internal sessional examination in Hall C222', 'Completed', 'Smooth conduct']
                ];
            default:
                return [];
        }
    }

    private function populateInstructions(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $module): void {
        $sheet->setCellValue('A1', 'IMPORT INSTRUCTIONS FOR ' . strtoupper($module));
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(12);

        $instructions = [
            '1. Do not rename or remove the column headers in the "Import Data" sheet.',
            '2. Fill in the data starting from row 2.',
            '3. Use exact reference codes as listed in the "Reference Values" sheet (e.g. Programme codes, Teacher codes).',
            '4. Days of the week must be integers: 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday.',
            '5. Programme + Semester + Paper relationships are strictly validated. A paper must belong to the selected Programme and Semester.',
            '6. Class Strength imports use automatic propagation: untouched future records will update, while confirmed historical records remain protected.',
            '7. Official Gauhati University holidays are authoritative and will not be overwritten by duplicate entries.',
            '8. Uploaded files must be valid .xlsx or .xls spreadsheets.',
            '9. All imports execute within an atomic database transaction. Any critical integrity errors will roll back cleanly.'
        ];

        $r = 3;
        foreach ($instructions as $inst) {
            $sheet->setCellValue('A' . $r, $inst);
            $r++;
        }
        $sheet->getColumnDimension('A')->setWidth(100);
    }

    private function populateReferenceValues(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, string $module): void {
        $sheet->setCellValue('A1', 'REFERENCE VALUES (Authoritative Database Master Data)');
        $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(11);

        $col = 'A';

        // Column A: Programmes
        $sheet->setCellValue($col . '3', 'Valid Programmes');
        $sheet->getStyle($col . '3')->getFont()->setBold(true);
        $progs = $this->pdo->query("SELECT short_code, name FROM programmes WHERE active=1 ORDER BY name")->fetchAll();
        $r = 4;
        foreach ($progs as $p) {
            $sheet->setCellValue($col . $r, $p['short_code'] . ' (' . $p['name'] . ')');
            $r++;
        }
        $sheet->getColumnDimension($col)->setWidth(30);

        // Column B: Semesters
        $col = 'B';
        $sheet->setCellValue($col . '3', 'Valid Semesters');
        $sheet->getStyle($col . '3')->getFont()->setBold(true);
        $sems = $this->pdo->query("SELECT name FROM semesters WHERE active=1 ORDER BY id")->fetchAll();
        $r = 4;
        foreach ($sems as $s) {
            $sheet->setCellValue($col . $r, $s['name']);
            $r++;
        }
        $sheet->getColumnDimension($col)->setWidth(20);

        // Column C: Teachers
        $col = 'C';
        $sheet->setCellValue($col . '3', 'Valid Teachers');
        $sheet->getStyle($col . '3')->getFont()->setBold(true);
        $teachers = $this->pdo->query("SELECT short_code, name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();
        $r = 4;
        foreach ($teachers as $t) {
            $sheet->setCellValue($col . $r, $t['short_code'] . ' — ' . $t['name']);
            $r++;
        }
        $sheet->getColumnDimension($col)->setWidth(32);

        // Column D: Rooms
        $col = 'D';
        $sheet->setCellValue($col . '3', 'Valid Rooms / Labs');
        $sheet->getStyle($col . '3')->getFont()->setBold(true);
        $rooms = $this->pdo->query("SELECT name, room_type FROM rooms WHERE active=1 ORDER BY name")->fetchAll();
        $r = 4;
        foreach ($rooms as $rm) {
            $sheet->setCellValue($col . $r, $rm['name'] . ' (' . ($rm['room_type'] ?: 'Room') . ')');
            $r++;
        }
        $sheet->getColumnDimension($col)->setWidth(25);

        // Column E: Papers
        $col = 'E';
        $sheet->setCellValue($col . '3', 'Valid Papers (Prog - Sem - Code)');
        $sheet->getStyle($col . '3')->getFont()->setBold(true);
        $papers = $this->pdo->query("
            SELECT pa.code, pa.name, p.short_code as prog, s.name as sem
            FROM papers pa
            JOIN programmes p ON p.id = pa.programme_id
            JOIN semesters s ON s.id = pa.semester_id
            WHERE pa.active = 1
            ORDER BY p.name, s.id, pa.name
        ")->fetchAll();
        $r = 4;
        foreach ($papers as $pa) {
            $sheet->setCellValue($col . $r, $pa['prog'] . ' ' . $pa['sem'] . ' | ' . $pa['code'] . ' - ' . $pa['name']);
            $r++;
        }
        $sheet->getColumnDimension($col)->setWidth(50);
    }

    public function getSpreadsheetBytes(Spreadsheet $spreadsheet): string {
        $writer = new Xlsx($spreadsheet);
        ob_start();
        $writer->save('php://output');
        return (string)ob_get_clean();
    }

    private function streamSpreadsheet(Spreadsheet $spreadsheet, string $filename): void {
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
}
