<?php
declare(strict_types=1);
require_once __DIR__.'/../config/db.php';

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="'.htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8').'">';
}

function check_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        $sessionToken = $_SESSION['csrf'] ?? '';
        if (!$token || !hash_equals($sessionToken, $token)) {
            http_response_code(419);
            exit('Invalid CSRF token. Please refresh the page and try again.');
        }
    }
}

function user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!user()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin(): void {
    require_login();
    if ((user()['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Administrator access required.');
    }
}

function login_user(string $username, string $password): bool {
    $st = db()->prepare('SELECT u.*, t.name as teacher_name, t.short_code as teacher_code FROM users u LEFT JOIN teachers t ON t.id = u.teacher_id WHERE u.username=? AND u.active=1 LIMIT 1');
    $st->execute([trim($username)]);
    $u = $st->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        unset($u['password_hash']);
        session_regenerate_id(true);
        $_SESSION['user'] = $u;
        return true;
    }
    return false;
}
