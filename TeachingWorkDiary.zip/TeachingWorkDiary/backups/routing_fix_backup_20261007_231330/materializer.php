<?php
declare(strict_types=1);
require_once __DIR__.'/../config/db.php';

/**
 * Determine the academic session string (e.g. '2026-27') from a calendar date.
 * Academic session in Assam/India typically runs July to June.
 */
function academic_session_for_date(string $date): string {
    $ts = strtotime($date);
    $y = (int)date('Y', $ts);
    $m = (int)date('n', $ts);
    if ($m >= 7) {
        return sprintf('%04d-%02d', $y, ($y + 1) % 100);
    }
    return sprintf('%04d-%02d', $y - 1, $y % 100);
}

/**
 * Get authoritative class strength from database for Programme + Semester + Academic Session.
 */
function get_class_strength(PDO $pdo, int $programmeId, int $semesterId, string $session): int {
    $st = $pdo->prepare('SELECT strength FROM class_strength WHERE programme_id=? AND semester_id=? AND session_name=? AND active=1 ORDER BY id DESC LIMIT 1');
    $st->execute([$programmeId, $semesterId, $session]);
    $val = $st->fetchColumn();
    if ($val !== false && $val !== null) {
        return (int)$val;
    }
    // Fallback to latest active strength for this prog/sem if specific session not recorded
    $st2 = $pdo->prepare('SELECT strength FROM class_strength WHERE programme_id=? AND semester_id=? AND active=1 ORDER BY id DESC LIMIT 1');
    $st2->execute([$programmeId, $semesterId]);
    $val2 = $st2->fetchColumn();
    return ($val2 !== false && $val2 !== null) ? (int)$val2 : 0;
}

/**
 * Automatically propagates class strength updates to future and untouched auto-generated diary records.
 * Historical manually confirmed records (is_edited = 1) are NEVER touched.
 */
function propagate_class_strength(PDO $pdo, int $programmeId, int $semesterId, string $session, int $newStrength): int {
    $parts = explode('-', $session);
    $startYear = (int)$parts[0];
    if ($startYear > 2000) {
        $startDate = sprintf('%04d-07-01', $startYear);
        $endDate = sprintf('%04d-06-30', $startYear + 1);
        $stmt = $pdo->prepare("
            UPDATE diary 
            SET total = ?,
                present = CASE WHEN status = 'Conducted' THEN ? ELSE 0 END
            WHERE programme_id = ? 
              AND semester_id = ? 
              AND is_edited = 0 
              AND diary_date BETWEEN ? AND ?
        ");
        $stmt->execute([$newStrength, $newStrength, $programmeId, $semesterId, $startDate, $endDate]);
        return $stmt->rowCount();
    } else {
        $stmt = $pdo->prepare("
            UPDATE diary 
            SET total = ?,
                present = CASE WHEN status = 'Conducted' THEN ? ELSE 0 END
            WHERE programme_id = ? 
              AND semester_id = ? 
              AND is_edited = 0
        ");
        $stmt->execute([$newStrength, $newStrength, $programmeId, $semesterId]);
        return $stmt->rowCount();
    }
}

/**
 * Check if a specific or teacher-wide override applies to a timetable slot on a given date.
 */
function get_applicable_override(PDO $pdo, int $teacherId, int $timetableId, string $date): ?array {
    // 1. Check slot-specific override first
    $st = $pdo->prepare('SELECT * FROM overrides WHERE teacher_id=? AND timetable_id=? AND ? BETWEEN start_date AND end_date AND active=1 ORDER BY id DESC LIMIT 1');
    $st->execute([$teacherId, $timetableId, $date]);
    $o = $st->fetch();
    if ($o) {
        return $o;
    }
    // 2. Check teacher-wide override (timetable_id IS NULL)
    $st2 = $pdo->prepare('SELECT * FROM overrides WHERE teacher_id=? AND timetable_id IS NULL AND ? BETWEEN start_date AND end_date AND active=1 ORDER BY id DESC LIMIT 1');
    $st2->execute([$teacherId, $date]);
    $o2 = $st2->fetch();
    return $o2 ?: null;
}

/**
 * Synchronize untouched auto-generated records when overrides or holidays change.
 */
function sync_untouched_diary_records(PDO $pdo, ?string $fromDate = null, ?string $toDate = null): void {
    $where = 'WHERE is_edited = 0';
    $args = [];
    if ($fromDate && $toDate) {
        $where .= ' AND diary_date BETWEEN ? AND ?';
        $args = [$fromDate, $toDate];
    }
    $records = $pdo->prepare("SELECT * FROM diary $where");
    $records->execute($args);
    $rows = $records->fetchAll();

    foreach ($rows as $row) {
        if (!$row['timetable_id']) continue;
        $d = $row['diary_date'];
        
        // Check official / local holiday
        $hSt = $pdo->prepare("SELECT title FROM holidays WHERE holiday_date=? AND active=1 AND holiday_type IN ('official','local') LIMIT 1");
        $hSt->execute([$d]);
        $holidayTitle = $hSt->fetchColumn();

        // Check override
        $originalTeacherId = (int)($row['original_teacher_id'] ?: $row['teacher_id']);
        $override = get_applicable_override($pdo, $originalTeacherId, (int)$row['timetable_id'], $d);

        $actualTeacher = $originalTeacherId;
        $status = $holidayTitle ? 'Scheduled - Holiday' : 'Conducted';
        $remarks = $holidayTitle ? ('Official holiday: ' . $holidayTitle) : '';

        if ($override) {
            if ($override['action'] === 'cancel') {
                $status = 'Cancelled';
                $remarks = trim(($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
            } elseif ($override['action'] === 'substitute' && !empty($override['substitute_teacher_id'])) {
                $actualTeacher = (int)$override['substitute_teacher_id'];
                $remarks = trim('Substitute arrangement. ' . ($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
            }
        }

        $session = academic_session_for_date($d);
        $total = get_class_strength($pdo, (int)$row['programme_id'], (int)$row['semester_id'], $session);
        $present = ($status === 'Conducted') ? $total : 0;

        $up = $pdo->prepare('UPDATE diary SET teacher_id=?, original_teacher_id=?, present=?, total=?, status=?, remarks=? WHERE id=? AND is_edited=0');
        $up->execute([$actualTeacher, $originalTeacherId, $present, $total, $status, $remarks, $row['id']]);
    }
}

/**
 * Materialize timetable records into Diary for the specified date range.
 * Never pre-filters by teacher, so substitutions are correctly captured.
 */
function materialize_range(string $from, string $to, ?int $unusedTeacherFilter = null): int {
    $pdo = db();
    $start = new DateTime($from);
    $end = new DateTime($to);
    $count = 0;

    for ($d = clone $start; $d <= $end; $d->modify('+1 day')) {
        $dateStr = $d->format('Y-m-d');
        $dow = (int)$d->format('N'); // 1 (Mon) to 7 (Sun)

        // Query active timetable slots for this day of week
        $st = $pdo->prepare('SELECT * FROM timetable WHERE active=1 AND day_of_week=? ORDER BY start_time');
        $st->execute([$dow]);
        $timetableSlots = $st->fetchAll();
        if (!$timetableSlots) {
            continue;
        }

        // Query official/local holiday (restricted holidays do NOT cancel classes automatically)
        $hSt = $pdo->prepare("SELECT title FROM holidays WHERE holiday_date=? AND active=1 AND holiday_type IN ('official','local') LIMIT 1");
        $hSt->execute([$dateStr]);
        $holidayTitle = $hSt->fetchColumn();

        $session = academic_session_for_date($dateStr);

        foreach ($timetableSlots as $slot) {
            // Check if diary entry already exists for this timetable slot and date
            $chk = $pdo->prepare('SELECT id, is_edited FROM diary WHERE timetable_id=? AND diary_date=?');
            $chk->execute([$slot['id'], $dateStr]);
            $existing = $chk->fetch();

            if ($existing) {
                // If it is untouched, make sure overrides and holidays stay in sync
                if ((int)$existing['is_edited'] === 0) {
                    $override = get_applicable_override($pdo, (int)$slot['teacher_id'], (int)$slot['id'], $dateStr);
                    $actualTeacher = (int)$slot['teacher_id'];
                    $status = $holidayTitle ? 'Scheduled - Holiday' : 'Conducted';
                    $remarks = $holidayTitle ? ('Official holiday: ' . $holidayTitle) : '';

                    if ($override) {
                        if ($override['action'] === 'cancel') {
                            $status = 'Cancelled';
                            $remarks = trim(($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
                        } elseif ($override['action'] === 'substitute' && !empty($override['substitute_teacher_id'])) {
                            $actualTeacher = (int)$override['substitute_teacher_id'];
                            $remarks = trim('Substitute arrangement. ' . ($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
                        }
                    }

                    $total = get_class_strength($pdo, (int)$slot['programme_id'], (int)$slot['semester_id'], $session);
                    $present = ($status === 'Conducted') ? $total : 0;

                    $up = $pdo->prepare('UPDATE diary SET teacher_id=?, original_teacher_id=?, present=?, total=?, status=?, remarks=? WHERE id=? AND is_edited=0');
                    $up->execute([$actualTeacher, (int)$slot['teacher_id'], $present, $total, $status, $remarks, $existing['id']]);
                }
                continue;
            }

            // Materialize fresh record
            $actualTeacher = (int)$slot['teacher_id'];
            $status = $holidayTitle ? 'Scheduled - Holiday' : 'Conducted';
            $remarks = $holidayTitle ? ('Official holiday: ' . $holidayTitle) : '';

            $override = get_applicable_override($pdo, (int)$slot['teacher_id'], (int)$slot['id'], $dateStr);
            if ($override) {
                if ($override['action'] === 'cancel') {
                    $status = 'Cancelled';
                    $remarks = trim(($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
                } elseif ($override['action'] === 'substitute' && !empty($override['substitute_teacher_id'])) {
                    $actualTeacher = (int)$override['substitute_teacher_id'];
                    $remarks = trim('Substitute arrangement. ' . ($override['reason'] ?? '') . ' ' . ($override['remarks'] ?? ''));
                }
            }

            $total = get_class_strength($pdo, (int)$slot['programme_id'], (int)$slot['semester_id'], $session);
            $present = ($status === 'Conducted') ? $total : 0;

            $ins = $pdo->prepare('
                INSERT INTO diary(
                    diary_date, start_time, end_time, teacher_id, original_teacher_id,
                    programme_id, semester_id, paper_id, room_id, class_type,
                    present, total, status, remarks,
                    original_date, original_start_time, original_end_time,
                    timetable_id, materialized_from, is_edited
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "timetable", 0)
            ');
            $ins->execute([
                $dateStr,
                $slot['start_time'],
                $slot['end_time'],
                $actualTeacher,
                $slot['teacher_id'],
                $slot['programme_id'],
                $slot['semester_id'],
                $slot['paper_id'],
                $slot['room_id'],
                $slot['class_type'],
                $present,
                $total,
                $status,
                $remarks,
                $dateStr,
                $slot['start_time'],
                $slot['end_time'],
                $slot['id']
            ]);
            $count++;
        }
    }
    return $count;
}
