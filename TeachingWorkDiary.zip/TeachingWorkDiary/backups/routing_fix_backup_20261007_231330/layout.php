<?php
declare(strict_types=1);
require_once __DIR__.'/auth.php';

function esc($v): string {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

function page_header(string $title, string $activeNav = ''): void {
    $u = user();
    $displayName = '';
    $designation = '';
    if ($u) {
        $displayName = !empty($u['teacher_name']) ? (string)$u['teacher_name'] : (!empty($u['display_name']) ? (string)$u['display_name'] : (!empty($u['username']) ? (string)$u['username'] : 'User'));
        $designation = !empty($u['role']) && $u['role'] === 'admin' ? 'System Administrator' : 'Department Faculty';
        // Check if teacher has specific designation in DB
        if (!empty($u['teacher_id'])) {
            try {
                $stDesig = db()->prepare('SELECT designation FROM teachers WHERE id=?');
                $stDesig->execute([$u['teacher_id']]);
                $dVal = $stDesig->fetchColumn();
                if ($dVal) $designation = (string)$dVal;
            } catch (Throwable $e) {}
        }
    }
    $role = $u['role'] ?? 'teacher';
    $currentUri = $_SERVER['REQUEST_URI'] ?? '';
    $currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $currentType = $_GET['type'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?=esc($title)?> — <?=esc(APP_NAME)?></title>
    <link rel="stylesheet" href="assets/app.css">
</head>
<body class="academic-app-body">
<!-- Top Institutional Header -->
<header class="inst-top-bar">
    <div class="top-bar-left">
        <?php if ($u): ?>
            <button class="sidebar-toggle-btn" id="sidebarToggle" aria-label="Toggle Navigation">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        <?php endif; ?>
        <div class="top-brand">
            <span class="top-college">Lalit Chandra Bharali College</span>
            <span class="top-sep">&bull;</span>
            <span class="top-system">Teaching &amp; Work Diary</span>
            <span class="top-dept">(Dept. of IT)</span>
        </div>
    </div>
    <?php if ($u): ?>
    <div class="top-bar-right">
        <div class="top-user-info">
            <span class="user-name"><?=esc($displayName)?></span>
            <span class="user-role-badge <?=esc($role)?>"><?=strtoupper(esc($role))?></span>
        </div>
        <a href="logout.php" class="btn-logout" title="Sign Out">Sign Out</a>
    </div>
    <?php endif; ?>
</header>

<div class="academic-app-layout">
    <?php if ($u): ?>
    <!-- Left Academic Sidebar -->
    <aside class="academic-sidebar" id="appSidebar">
        <div class="sidebar-brand-box">
            <div class="sb-title">LCB COLLEGE</div>
            <div class="sb-sub">Department of Information Technology</div>
            <div class="sb-loc">Maligaon, Guwahati – 781011</div>
        </div>

        <nav class="sidebar-nav">
            <!-- TEACHING -->
            <div class="nav-section-label">Teaching</div>
            <a href="index.php" class="sidebar-link <?=$currentScript==='index.php'?'active':''?>">
                <span class="link-icon">📅</span> Diary Dashboard
            </a>
            <a href="timetable.php" class="sidebar-link <?=$currentScript==='timetable.php'?'active':''?>">
                <span class="link-icon">🗓️</span> Timetable
            </a>

            <!-- ACADEMIC -->
            <div class="nav-section-label">Academic Planning</div>
            <a href="holidays.php" class="sidebar-link <?=$currentScript==='holidays.php'?'active':''?>">
                <span class="link-icon">🎉</span> Academic Holidays
            </a>
            <?php if ($role === 'admin'): ?>
                <a href="overrides.php" class="sidebar-link <?=$currentScript==='overrides.php'?'active':''?>">
                    <span class="link-icon">🔄</span> Overrides &amp; Leave
                </a>
            <?php endif; ?>

            <!-- DUTIES -->
            <div class="nav-section-label">Duties &amp; Works</div>
            <a href="duties.php" class="sidebar-link <?=$currentScript==='duties.php'?'active':''?>">
                <span class="link-icon">📋</span> Assigned Duties
            </a>
            <a href="work.php" class="sidebar-link <?=$currentScript==='work.php'?'active':''?>">
                <span class="link-icon">✍️</span> Additional Work
            </a>

            <!-- REPORTS -->
            <div class="nav-section-label">Reports</div>
            <a href="reports.php" class="sidebar-link <?=$currentScript==='reports.php'?'active':''?>">
                <span class="link-icon">📄</span> Teaching Diary Report
            </a>

            <?php if ($role === 'admin'): ?>
            <!-- MASTER DATA -->
            <div class="nav-section-label">Master Data</div>
            <a href="masters.php?type=teachers" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='teachers')?'active':''?>">
                <span class="link-icon">👨‍🏫</span> Teachers
            </a>
            <a href="masters.php?type=programmes" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='programmes')?'active':''?>">
                <span class="link-icon">🎓</span> Programmes
            </a>
            <a href="masters.php?type=semesters" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='semesters')?'active':''?>">
                <span class="link-icon">📚</span> Semesters
            </a>
            <a href="masters.php?type=papers" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='papers')?'active':''?>">
                <span class="link-icon">📖</span> Papers / Subjects
            </a>
            <a href="masters.php?type=rooms" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='rooms')?'active':''?>">
                <span class="link-icon">🏫</span> Rooms / Labs
            </a>
            <a href="masters.php?type=strength" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='strength')?'active':''?>">
                <span class="link-icon">👥</span> Class Strength
            </a>
            <a href="masters.php?type=duty_types" class="sidebar-link <?=($currentScript==='masters.php'&&$currentType==='duty_types')?'active':''?>">
                <span class="link-icon">📌</span> Duty Types
            </a>

            <!-- SYSTEM -->
            <div class="nav-section-label">System</div>
            <a href="settings.php" class="sidebar-link <?=$currentScript==='settings.php'?'active':''?>">
                <span class="link-icon">⚙️</span> Settings &amp; SMTP
            </a>
            <a href="backup.php" class="sidebar-link <?=$currentScript==='backup.php'?'active':''?>">
                <span class="link-icon">💾</span> Backup &amp; Restore
            </a>
            <?php endif; ?>
        </nav>
    </aside>
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>
    <?php endif; ?>

    <!-- Main Content Area -->
    <main class="academic-main-content">
        <div class="content-header-strip">
            <h1 class="page-heading"><?=esc($title)?></h1>
            <div class="page-date-badge"><?=date('l, d F Y')?></div>
        </div>
<?php
}

function page_footer(): void {
?>
        <footer class="academic-footer">
            <div class="footer-text">
                <strong>Lalit Chandra Bharali College</strong> &bull; Department of Information Technology &bull; Maligaon, Guwahati – 781011
            </div>
            <div class="footer-sub">
                Teaching &amp; Work Diary Management Portal &bull; Academic Session 2026-27
            </div>
        </footer>
    </main>
</div>

<script>
(function() {
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('appSidebar');
    const backdrop = document.getElementById('sidebarBackdrop');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            if (backdrop) backdrop.classList.toggle('active');
        });
    }

    if (backdrop && sidebar) {
        backdrop.addEventListener('click', function() {
            sidebar.classList.remove('open');
            backdrop.classList.remove('active');
        });
    }
})();
</script>
</body>
</html>
<?php
}
