<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

require __DIR__ . '/../config/db.php';
$st = db()->query('SELECT id, username, role, teacher_id, active FROM users');
$users = $st->fetchAll();
echo "USERS FOUND: " . count($users) . "\n";
print_r($users);
