<?php
require 'config/config.php';
require 'config/db.php';
require 'lib/materializer.php';
require 'report_pdf.php';

$pdo = db();
materialize_range('2026-10-01', '2026-10-08');
$dates = get_active_report_dates($pdo, '2026-10-01', '2026-10-08', 0);
echo "Active dates: " . implode(', ', $dates) . "\n";
foreach ($dates as $d) {
    $cCount = $pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d'")->fetchColumn();
    $wCount = $pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d'")->fetchColumn();
    echo "$d: $cCount classes, $wCount works\n";
}
