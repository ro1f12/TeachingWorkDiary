<?php
$baseUrl = 'http://localhost/TeachingWorkDiary';
$cookieFile = __DIR__ . '/cookie.txt';
if (file_exists($cookieFile)) unlink($cookieFile);

// Helper curl function
function curl_req($url, $postFields = null, $cookieFile = null) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    if ($cookieFile) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }
    if ($postFields !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postFields));
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);
    curl_close($ch);
    return ['code' => $httpCode, 'headers' => $headers, 'body' => $body];
}

echo "=== 1. TEST UNAUTHENTICATED REQUEST (EXPECT 302 REDIRECT TO login.php) ===\n";
$unauth = curl_req($baseUrl . '/index.php');
echo "URL: $baseUrl/index.php\n";
echo "HTTP STATUS: {$unauth['code']}\n";
if (preg_match('/Location:\s*([^\r\n]+)/i', $unauth['headers'], $m)) {
    echo "REDIRECT TARGET: " . trim($m[1]) . "\n";
}
echo "RESULT: " . ($unauth['code'] === 302 ? "PASS (Proper 302 Redirect)" : "FAIL") . "\n\n";

echo "=== 2. AUTHENTICATING AS ADMIN ===\n";
// Fetch login page for CSRF token
$loginPage = curl_req($baseUrl . '/login.php', null, $cookieFile);
preg_match('/name="csrf"\s+value="([^"]+)"/', $loginPage['body'], $csrfMatches);
$csrf = $csrfMatches[1] ?? '';

$loginRes = curl_req($baseUrl . '/login.php', [
    'csrf' => $csrf,
    'username' => 'admin',
    'password' => 'admin123'
], $cookieFile);

echo "LOGIN HTTP STATUS: {$loginRes['code']}\n";
if ($loginRes['code'] === 302) {
    echo "LOGIN RESULT: PASS (Admin Authenticated Successfully)\n\n";
} else {
    echo "LOGIN RESULT: FAIL\n\n";
    exit(1);
}

echo "=== 3. HTTP SMOKE TEST ON ALL SIDEBAR ROUTES (AUTHENTICATED) ===\n";

$routes = [
    'Diary Dashboard' => '/index.php',
    'Timetable' => '/timetable.php',
    'Academic Holidays' => '/holidays.php',
    'Overrides & Leave' => '/overrides.php',
    'Assigned Duties' => '/duties.php',
    'Additional Work' => '/work.php',
    'Teaching Diary Report' => '/reports.php',
    'Teachers' => '/masters.php?type=teachers',
    'Programmes' => '/masters.php?type=programmes',
    'Semesters' => '/masters.php?type=semesters',
    'Papers / Courses' => '/masters.php?type=papers',
    'Classrooms & Labs' => '/masters.php?type=rooms',
    'Class Strength' => '/masters.php?type=strength',
    'Duty Types' => '/masters.php?type=duty_types',
    'Settings & SMTP' => '/settings.php',
    'Backup & Restore' => '/backup.php'
];

$results = [];
foreach ($routes as $name => $path) {
    $url = $baseUrl . $path;
    $res = curl_req($url, null, $cookieFile);
    
    // Extract title / heading
    $title = '';
    if (preg_match('/<title>(.*?)<\/title>/is', $res['body'], $tm)) {
        $title = trim(strip_tags($tm[1]));
    } elseif (preg_match('/<h[12][^>]*>(.*?)<\/h[12]>/is', $res['body'], $hm)) {
        $title = trim(strip_tags($hm[1]));
    }

    $has500 = ($res['code'] === 500);
    $hasFatal = (stripos($res['body'], 'Fatal error') !== false || stripos($res['body'], 'Exception') !== false);
    
    $statusText = 'PASS';
    if ($res['code'] !== 200 || $hasFatal) {
        $statusText = 'FAIL (Code ' . $res['code'] . ')';
    }

    $results[] = [
        'name' => $name,
        'path' => $path,
        'url' => $url,
        'code' => $res['code'],
        'title' => $title,
        'status' => $statusText
    ];

    printf("%-24s | %-32s | HTTP %-3d | %-4s | %s\n", 
        $name, 
        $path, 
        $res['code'], 
        $statusText, 
        substr($title, 0, 50)
    );
}

if (file_exists($cookieFile)) unlink($cookieFile);
