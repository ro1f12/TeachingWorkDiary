<?php
$pages = [
    'Diary Dashboard' => ['file' => 'index.php', 'query' => ''],
    'Timetable' => ['file' => 'timetable.php', 'query' => ''],
    'Academic Holidays' => ['file' => 'holidays.php', 'query' => ''],
    'Assigned Duties' => ['file' => 'duties.php', 'query' => ''],
    'Additional Work' => ['file' => 'work.php', 'query' => ''],
    'Teaching Diary Report' => ['file' => 'reports.php', 'query' => ''],
];

echo "=== TESTING SIDEBAR TARGETS AS TEACHER (MD-IT) ===\n";
foreach ($pages as $name => $info) {
    $cmd = "c:\\xampp\\php\\php.exe -r \"
        error_reporting(E_ALL); ini_set('display_errors', '1');
        parse_str('{$info['query']}', \\\$_GET);
        \\\$_SERVER['REQUEST_METHOD'] = 'GET';
        \\\$_SERVER['REQUEST_URI'] = '/TeachingWorkDiary/{$info['file']}';
        \\\$_SERVER['SCRIPT_NAME'] = '/TeachingWorkDiary/{$info['file']}';
        session_start();
        \\\$_SESSION['user'] = [
            'id' => 10,
            'username' => 'md_it',
            'role' => 'teacher',
            'teacher_id' => 1,
            'display_name' => 'Dr. Manisha Deka',
            'teacher_name' => 'Dr. Manisha Deka',
            'teacher_code' => 'MD-IT'
        ];
        try {
            ob_start();
            require '{$info['file']}';
            \\\$out = ob_get_clean();
            echo 'SUCCESS (bytes: ' . strlen(\\\$out) . ')';
        } catch (Throwable \\\$e) {
            ob_end_clean();
            echo 'ERROR: ' . \\\$e->getMessage();
        }
    \"";
    $res = shell_exec($cmd);
    echo str_pad($name, 25) . " => " . trim($res) . "\n";
}
