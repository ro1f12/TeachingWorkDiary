<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

$pdo = db();
$tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

$dump = "-- Pre-V1.0.2 Rebuild Database Backup\n";
$dump .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
$dump .= "/*!40101 SET NAMES utf8mb4 */;\n";
$dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tables as $t) {
    $dump .= "-- Table structure for `$t`\n";
    $createRow = $pdo->query("SHOW CREATE TABLE `$t`")->fetch();
    $dump .= "DROP TABLE IF EXISTS `$t`;\n";
    $dump .= $createRow['Create Table'] . ";\n\n";

    $rows = $pdo->query("SELECT * FROM `$t`")->fetchAll();
    if ($rows) {
        $dump .= "-- Dumping data for table `$t`\n";
        foreach ($rows as $r) {
            $cols = array_map(fn($c) => "`$c`", array_keys($r));
            $vals = array_map(function($v) use ($pdo) {
                return $v === null ? 'NULL' : $pdo->quote((string)$v);
            }, array_values($r));
            $dump .= "INSERT INTO `$t` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n";
        }
        $dump .= "\n";
    }
}
$dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

$backupDir = __DIR__ . '/../backups';
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}
$backupFile = $backupDir . '/pre_v102_rebuild_backup_' . date('Ymd_His') . '.sql';
file_put_contents($backupFile, $dump);

echo "Backup created successfully:\n";
echo "File: $backupFile\n";
echo "Size: " . filesize($backupFile) . " bytes\n";
echo "Tables backed up (" . count($tables) . "): " . implode(', ', $tables) . "\n";
