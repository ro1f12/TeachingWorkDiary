<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Setup mock web environment
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI'] = '/TeachingWorkDiary/index.php';
$_SERVER['HTTP_HOST'] = 'localhost';
$_GET = [];

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$_SESSION['user'] = [
    'id' => 1,
    'username' => 'admin',
    'role' => 'admin',
    'teacher_id' => null,
    'teacher_name' => 'Administrator',
    'teacher_code' => 'ADMIN'
];

try {
    ob_start();
    require __DIR__ . '/../index.php';
    $out = ob_get_clean();
    echo "\nINDEX.PHP EXECUTED SUCCESSFULLY (Output length: " . strlen($out) . " bytes)\n";
} catch (Throwable $e) {
    ob_end_clean();
    echo "\nFATAL ERROR CAUGHT:\n";
    echo "Type: " . get_class($e) . "\n";
    echo "Message: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . " on line " . $e->getLine() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
