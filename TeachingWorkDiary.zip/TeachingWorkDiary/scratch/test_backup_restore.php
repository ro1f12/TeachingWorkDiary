<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

echo "=== DATABASE BACKUP & RESTORE VERIFICATION ===\n";

$pdo = db();

// 1. Generate SQL dump using backup.php logic
$tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

$dump = "-- Teaching & Work Diary Database Backup Verification\n";
$dump .= "/*!40101 SET NAMES utf8mb4 */;\n";
$dump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tables as $t) {
    $dump .= "-- Table structure for `$t`\n";
    $createRow = $pdo->query("SHOW CREATE TABLE `$t`")->fetch();
    $dump .= "DROP TABLE IF EXISTS `$t`;\n";
    $dump .= $createRow['Create Table'] . ";\n\n";

    $rows = $pdo->query("SELECT * FROM `$t`")->fetchAll();
    if ($rows) {
        $dump .= "-- Dumping data for table `$t`\n";
        foreach ($rows as $r) {
            $cols = array_map(fn($c) => "`$c`", array_keys($r));
            $vals = array_map(function($v) use ($pdo) {
                return $v === null ? 'NULL' : $pdo->quote((string)$v);
            }, array_values($r));
            $dump .= "INSERT INTO `$t` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n";
        }
        $dump .= "\n";
    }
}
$dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

$dumpSize = strlen($dump);
echo "1. Backup Dump Generated: $dumpSize bytes\n";
echo "   Tables included (" . count($tables) . "): " . implode(', ', $tables) . "\n";

// Verify all required tables are present
$expectedTables = ['users','teachers','programmes','semesters','papers','rooms','class_strength','duty_types','duties','timetable','holidays','diary','overrides','additional_works','settings'];
$missing = array_diff($expectedTables, $tables);
if (empty($missing)) {
    echo "   [PASS] All 15 required tables included in backup.\n";
} else {
    echo "   [FAIL] Missing tables: " . implode(', ', $missing) . "\n";
}

// 2. Controlled Non-destructive Restore Test on isolated sandbox database
echo "\n2. Testing Restore on Sandbox Database `teaching_work_diary_test_backup`...\n";
$rawPdo = new PDO('mysql:host='.DB_HOST.';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$testDbName = 'teaching_work_diary_test_backup';
$rawPdo->exec("CREATE DATABASE IF NOT EXISTS `$testDbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$rawPdo->exec("USE `$testDbName`");

// Execute the backup dump into sandbox database
$statements = preg_split('/;\s*[\r\n]+/', $dump);
$execCount = 0;
foreach ($statements as $st) {
    $st = trim($st);
    if ($st && !str_starts_with($st, '--')) {
        $rawPdo->exec($st);
        $execCount++;
    }
}
echo "   Executed $execCount SQL statements into sandbox database.\n";

// Verify sandbox tables and row counts
$testTables = $rawPdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
echo "   Sandbox tables restored: " . count($testTables) . "\n";

$teachersCount = $rawPdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$timetableCount = $rawPdo->query("SELECT COUNT(*) FROM timetable")->fetchColumn();
$diaryCount = $rawPdo->query("SELECT COUNT(*) FROM diary")->fetchColumn();

echo "   Restored record counts: Teachers=$teachersCount, Timetable=$timetableCount, Diary=$diaryCount\n";

if (count($testTables) === count($tables) && $teachersCount > 0) {
    echo "   [PASS] Restore verification succeeded cleanly!\n";
} else {
    echo "   [FAIL] Restore count mismatch!\n";
}

// Cleanup sandbox database
$rawPdo->exec("DROP DATABASE IF EXISTS `$testDbName`");
echo "   Sandbox database cleaned up.\n";
echo "\n=== BACKUP & RESTORE TEST COMPLETED SUCCESSFULLY ===\n";
