<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

$pdo = db();

$illegal = $pdo->query("SELECT short_code, COUNT(*) cnt FROM teachers WHERE short_code IN ('BB','PP','FUA') GROUP BY short_code")->fetchAll();
$numTeachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$numProgrammes = (int)$pdo->query("SELECT COUNT(*) FROM programmes")->fetchColumn();
$numSemesters = (int)$pdo->query("SELECT COUNT(*) FROM semesters")->fetchColumn();
$numPapersUsed = (int)$pdo->query("SELECT COUNT(DISTINCT paper_id) FROM timetable WHERE active = 1")->fetchColumn();
$numRooms = (int)$pdo->query("SELECT COUNT(*) FROM rooms WHERE active = 1")->fetchColumn();
$numTimetable = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1")->fetchColumn();
$numPractical = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1 AND class_type = 'Practical'")->fetchColumn();
$numBlankRoom = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1 AND room_id IS NULL")->fetchColumn();
$numDups = (int)$pdo->query("SELECT COUNT(*) FROM (SELECT day_of_week, start_time, programme_id, semester_id FROM timetable WHERE active=1 GROUP BY day_of_week, start_time, programme_id, semester_id HAVING COUNT(*) > 1) d")->fetchColumn();
$numUnresolved = (int)$pdo->query("SELECT COUNT(*) FROM timetable t LEFT JOIN programmes p ON p.id=t.programme_id LEFT JOIN semesters s ON s.id=t.semester_id LEFT JOIN papers pa ON pa.id=t.paper_id WHERE p.id IS NULL OR s.id IS NULL OR pa.id IS NULL")->fetchColumn();

$valErrors = 0;
if (!empty($illegal)) $valErrors++;
if ($numDups > 0) $valErrors++;
if ($numUnresolved > 0) $valErrors++;

echo "1. Number of teacher master records: $numTeachers\n";
echo "2. Number of programme records: $numProgrammes\n";
echo "3. Number of semester records: $numSemesters\n";
echo "4. Number of paper records used: $numPapersUsed\n";
echo "5. Number of room records: $numRooms\n";
echo "6. Number of timetable entries: $numTimetable\n";
echo "7. Number of Practical entries: $numPractical\n";
echo "8. Number of entries with blank room: $numBlankRoom\n";
echo "9. Number of validation errors: $valErrors\n";
echo "10. Number of duplicate entries: $numDups\n";
echo "11. Number of unresolved mappings: $numUnresolved\n";

echo "\nIllegal teacher search:\n";
echo "  teacher_code = 'BB': " . (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'BB'")->fetchColumn() . "\n";
echo "  teacher_code = 'PP': " . (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'PP'")->fetchColumn() . "\n";
echo "  teacher_code = 'FUA': " . (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'FUA'")->fetchColumn() . "\n";
echo "Official teacher codes present:\n";
foreach ($pdo->query("SELECT short_code, name FROM teachers ORDER BY id") as $t) {
    echo "  - {$t['short_code']}: {$t['name']}\n";
}
