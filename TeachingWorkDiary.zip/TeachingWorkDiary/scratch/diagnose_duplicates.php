<?php
require_once 'c:/xampp/htdocs/TeachingWorkDiary/config/db.php';
$pdo = db();

$pdo->exec("UPDATE timetable t JOIN papers p ON p.id = t.paper_id SET t.active = 0 WHERE t.programme_id != p.programme_id");
$pdo->exec("DELETE d FROM diary d JOIN papers p ON p.id = d.paper_id WHERE d.is_edited = 0 AND d.programme_id != p.programme_id");
echo "=== CLEANUP OF MISMATCHED TIMETABLE & DIARY COMPLETED ===\n";


echo "\n=== ALL TIMETABLE SLOTS FOR B.Sc.-IT 3rd ===\n";
$q2 = $pdo->query("
    SELECT t.id, t.day_of_week, t.start_time, t.end_time, te.short_code as teacher, p.short_code as prog, s.name as sem, pa.name as paper, pa.code
    FROM timetable t
    JOIN teachers te ON te.id = t.teacher_id
    JOIN programmes p ON p.id = t.programme_id
    JOIN semesters s ON s.id = t.semester_id
    JOIN papers pa ON pa.id = t.paper_id
    WHERE t.active = 1 AND p.short_code = 'BSc-IT' AND s.name = '3rd'
    ORDER BY t.day_of_week, t.start_time
");
while ($r = $q2->fetch(PDO::FETCH_ASSOC)) {
    echo "ID: {$r['id']} | Day: {$r['day_of_week']} | {$r['start_time']}-{$r['end_time']} | {$r['prog']} {$r['sem']} | {$r['paper']} ({$r['code']}) | Teacher: {$r['teacher']}\n";
}

echo "\n=== ALL TIMETABLE SLOTS FOR BCA 3rd ===\n";
$q3 = $pdo->query("
    SELECT t.id, t.day_of_week, t.start_time, t.end_time, te.short_code as teacher, p.short_code as prog, s.name as sem, pa.name as paper, pa.code
    FROM timetable t
    JOIN teachers te ON te.id = t.teacher_id
    JOIN programmes p ON p.id = t.programme_id
    JOIN semesters s ON s.id = t.semester_id
    JOIN papers pa ON pa.id = t.paper_id
    WHERE t.active = 1 AND p.short_code = 'BCA' AND s.name = '3rd'
    ORDER BY t.day_of_week, t.start_time
");
while ($r = $q3->fetch(PDO::FETCH_ASSOC)) {
    echo "ID: {$r['id']} | Day: {$r['day_of_week']} | {$r['start_time']}-{$r['end_time']} | {$r['prog']} {$r['sem']} | {$r['paper']} ({$r['code']}) | Teacher: {$r['teacher']}\n";
}

echo "\n=== CHECKING DIARY ROWS FOR 2026-10-01 to 2026-10-08 ===\n";
$q4 = $pdo->query("
    SELECT d.id, d.diary_date, d.start_time, d.end_time, te.short_code as teacher, p.short_code as prog, s.name as sem, pa.name as paper, d.status
    FROM diary d
    JOIN teachers te ON te.id = d.teacher_id
    JOIN programmes p ON p.id = d.programme_id
    JOIN semesters s ON s.id = d.semester_id
    JOIN papers pa ON pa.id = d.paper_id
    WHERE d.diary_date BETWEEN '2026-10-01' AND '2026-10-08'
    ORDER BY d.diary_date, d.start_time, p.short_code
");
$diaryRows = $q4->fetchAll(PDO::FETCH_ASSOC);
echo "Total diary rows in 01-08 Oct: " . count($diaryRows) . "\n";
echo "\n=== TEACHER TIME CONFLICTS IN TIMETABLE ===\n";
$qConf = $pdo->query("
    SELECT t.day_of_week, t.start_time, t.end_time, t.teacher_id, te.short_code, COUNT(*) as c
    FROM timetable t
    JOIN teachers te ON te.id = t.teacher_id
    WHERE t.active = 1
    GROUP BY t.day_of_week, t.start_time, t.end_time, t.teacher_id
    HAVING c > 1
");
while ($r = $qConf->fetch(PDO::FETCH_ASSOC)) {
    echo json_encode($r) . "\n";
}



