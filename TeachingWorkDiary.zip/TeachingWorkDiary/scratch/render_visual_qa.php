<?php
require_once 'config/config.php';
require_once 'config/db.php';
require_once 'lib/materializer.php';
require_once 'report_pdf.php';

$pdo = db();

$dates = get_active_report_dates($pdo, '2026-10-01', '2026-10-08', 0);
$chunks = array_chunk($dates, 2);

$edgePath = '"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"';

foreach ($chunks as $i => $c) {
    $pageNum = $i + 1;
    $d1 = $c[0];
    $d2 = $c[1] ?? null;
    
    $c1Count = (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d1'")->fetchColumn();
    $w1Count = (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d1'")->fetchColumn();
    $c2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d2'")->fetchColumn() : 0;
    $w2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d2'")->fetchColumn() : 0;
    
    $maxClasses = max($c1Count, $c2Count);
    $maxWorks = max($w1Count, $w2Count);
    list($ht, $hr) = calculate_page_box_heights($maxClasses, $maxWorks);
    
    $col1 = render_day_panel_html($pdo, $d1, 0, $ht, $hr);
    $col2 = render_day_panel_html($pdo, $d2, 0, $ht, $hr);
    
    $pageHtml = '<!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <style>
            @page { size: 297mm 210mm; margin: 7mm 8mm 7mm 8mm; }
            * { box-sizing: border-box; }
            body { font-family: Helvetica, Arial, sans-serif; margin: 0; padding: 7mm 8mm 7mm 8mm; color: #111827; background: #fff; font-size: 7.5pt; line-height: 1.15; width: 297mm; height: 210mm; overflow: hidden; }
        </style>
    </head>
    <body>
        <div style="text-align:center;border-bottom:1.5px solid #112a4a;padding-bottom:1.2mm;margin-bottom:1.5mm;">
            <div style="font-size:11.5pt;font-weight:bold;text-transform:uppercase;color:#112a4a;">LALIT CHANDRA BHARALI COLLEGE, MALIGAON, GUWAHATI – 781011</div>
            <div style="font-size:13pt;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#0f172a;margin:0.4mm 0;">TEACHING &amp; WORK DIARY</div>
            <div style="font-size:9.5pt;font-weight:bold;color:#334155;">Department of Information Technology</div>
            <div style="text-align:left;font-size:8.5pt;font-weight:bold;margin-top:0.8mm;">Teacher: All Teachers</div>
        </div>
        <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
            <tr>' . $col1 . $col2 . '</tr>
        </table>
    </body>
    </html>';
    
    $htmlFile = "c:/xampp/htdocs/TeachingWorkDiary/scratch/page_{$pageNum}.html";
    $pngFile = "c:/xampp/htdocs/TeachingWorkDiary/scratch/page_{$pageNum}.png";
    file_put_contents($htmlFile, $pageHtml);
    
    $cmd = "$edgePath --headless --disable-gpu --screenshot=\"$pngFile\" --window-size=1400,990 \"file:///$htmlFile\" 2>&1";
    exec($cmd);
    
    if (file_exists($pngFile)) {
        echo "Rendered Page $pageNum to $pngFile (" . filesize($pngFile) . " bytes)\n";
    } else {
        echo "Failed to render Page $pageNum\n";
    }
}
