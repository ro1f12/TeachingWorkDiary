<?php
require 'config/config.php';
require 'config/db.php';
$pdo = db();
$pdo->exec('DELETE FROM programmes WHERE id > 3');
$pdo->exec('DELETE FROM semesters WHERE id > 3');
try { $pdo->exec('ALTER TABLE programmes ADD UNIQUE KEY uq_prog_code (short_code)'); } catch (Exception $e) {}
try { $pdo->exec('ALTER TABLE semesters ADD UNIQUE KEY uq_sem_name (name)'); } catch (Exception $e) {}
echo "Cleaned and indexed successfully.\n";
