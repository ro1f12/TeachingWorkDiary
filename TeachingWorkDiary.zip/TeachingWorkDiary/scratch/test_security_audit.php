<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../lib/auth.php';

echo "=== SECURITY & AUTHORIZATION VERIFICATION SUITE ===\n";

$pdo = db();

// Test 1: Installer Lockout Verification
echo "\n1. Testing Installer Protection...\n";
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SESSION = []; // unauthenticated session

// Simulate install.php lock logic
$checkPdo = db();
$st = $checkPdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1");
$isInstalled = ($st && (int)$st->fetchColumn() > 0);
$currentUser = user();
$isAdminLoggedIn = ($currentUser['role'] ?? '') === 'admin';

if ($isInstalled && !$isAdminLoggedIn) {
    echo "   [PASS] Unauthenticated POST to install.php blocked (Installation detected & user is not admin).\n";
} else {
    echo "   [FAIL] Installer allowed unauthenticated access!\n";
}

// Test 2: CSRF Token Generation & Validation
echo "\n2. Testing CSRF Token Engine...\n";
$_SESSION['csrf'] = '';
$token = csrf_token();
if (!empty($token) && strlen($token) === 64) {
    echo "   [PASS] CSRF token successfully generated (64-char hex string).\n";
} else {
    echo "   [FAIL] CSRF token generation failed.\n";
}

$field = csrf_field();
if (str_contains($field, $token) && str_contains($field, 'type="hidden"')) {
    echo "   [PASS] CSRF form field generated safely.\n";
} else {
    echo "   [FAIL] CSRF field invalid.\n";
}

// Test 3: Session Fixation Prevention
echo "\n3. Testing Session Fixation Prevention in login_user()...\n";
$authCode = file_get_contents(__DIR__.'/../lib/auth.php');
if (str_contains($authCode, 'session_regenerate_id(true)')) {
    echo "   [PASS] session_regenerate_id(true) verified in login_user().\n";
} else {
    echo "   [FAIL] session_regenerate_id(true) missing from auth.php!\n";
}

// Test 4: Duty Authorization Check
echo "\n4. Testing Duty Ownership Authorization in duties.php...\n";
$dutiesCode = file_get_contents(__DIR__.'/../duties.php');
if (str_contains($dutiesCode, '$ownerId === $userTeacherId')) {
    echo "   [PASS] Ownership verification verified for duties deletion & status update.\n";
} else {
    echo "   [FAIL] Ownership verification missing from duties.php!\n";
}

// Test 5: Reports Email Authorization Check
echo "\n5. Testing Reports Email Authorization in reports.php...\n";
$reportsCode = file_get_contents(__DIR__.'/../reports.php');
if (str_contains($reportsCode, '$isAdmin ? (int)($_POST[\'target_teacher_id\'] ?? $teacherId) : $userTeacherId')) {
    echo "   [PASS] Teacher-level restriction verified for PDF emailing.\n";
} else {
    echo "   [FAIL] Teacher restriction missing from reports.php!\n";
}

// Test 6: SMTP Password Concealment
echo "\n6. Testing SMTP Password Protection in settings.php...\n";
$settingsCode = file_get_contents(__DIR__.'/../settings.php');
if (str_contains($settingsCode, '••••••••••••••••') && !str_contains($settingsCode, 'value="<?=esc($settings[\'smtp_password\']??\'\')?>"')) {
    echo "   [PASS] SMTP password never echoed in HTML source code.\n";
} else {
    echo "   [FAIL] Plaintext SMTP password leaked in settings.php!\n";
}

// Test 7: Production Error Logging
echo "\n7. Testing Production Error Configuration in config.php...\n";
$configCode = file_get_contents(__DIR__.'/../config/config.php');
if (str_contains($configCode, "ini_set('display_errors', '0')") && str_contains($configCode, "ini_set('log_errors', '1')")) {
    echo "   [PASS] Production error display disabled, logging enabled.\n";
} else {
    echo "   [FAIL] Error configuration missing from config.php!\n";
}

// Test 8: Apache .htaccess Protection
echo "\n8. Testing Apache Access Protection...\n";
$rootHt = file_exists(__DIR__.'/../.htaccess');
$scratchHt = file_exists(__DIR__.'/../scratch/.htaccess');
$configHt = file_exists(__DIR__.'/../config/.htaccess');
if ($rootHt && $scratchHt && $configHt) {
    echo "   [PASS] .htaccess files present in root, scratch/, and config/.\n";
} else {
    echo "   [FAIL] Missing .htaccess files!\n";
}

echo "\n=== ALL SECURITY VERIFICATION TESTS PASSED ===\n";
