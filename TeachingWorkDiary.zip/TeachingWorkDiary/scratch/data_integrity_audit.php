<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

$pdo = db();

echo "=== 1. TIMETABLE MISMATCH AUDIT ===\n";
$m = $pdo->query('SELECT t.id, t.teacher_id, t.programme_id, t.paper_id, p.programme_id as paper_prog_id 
                  FROM timetable t 
                  JOIN papers p ON p.id = t.paper_id 
                  WHERE t.programme_id != p.programme_id AND t.active = 1')->fetchAll();
echo "Mismatched active timetable rows: " . count($m) . "\n";
foreach ($m as $row) {
    print_r($row);
}

echo "\n=== 2. B.Sc-IT 3rd SEMESTER TIMETABLE RECORDS ===\n";
$b3 = $pdo->query("SELECT t.id, t.day_of_week, t.start_time, t.end_time, tc.short_code, pa.name, pa.code, t.active 
                   FROM timetable t 
                   JOIN teachers tc ON tc.id = t.teacher_id 
                   JOIN papers pa ON pa.id = t.paper_id 
                   JOIN programmes pr ON pr.id = t.programme_id 
                   JOIN semesters s ON s.id = t.semester_id 
                   WHERE pr.short_code = 'BSc-IT' AND s.name = '3rd'")->fetchAll();
foreach ($b3 as $r) {
    echo "ID: {$r['id']} | Day: {$r['day_of_week']} | {$r['start_time']}–{$r['end_time']} | Teacher: {$r['short_code']} | Paper: {$r['name']} ({$r['code']}) | Active: {$r['active']}\n";
}

echo "\n=== 3. DUPLICATE ACTIVE TIMETABLE SLOTS ===\n";
$dups = $pdo->query("SELECT day_of_week, start_time, end_time, teacher_id, programme_id, semester_id, paper_id, COUNT(*) as cnt 
                     FROM timetable 
                     WHERE active = 1 
                     GROUP BY day_of_week, start_time, end_time, teacher_id, programme_id, semester_id, paper_id 
                     HAVING cnt > 1")->fetchAll();
echo "Duplicate active timetable slots: " . count($dups) . "\n";

echo "\n=== 4. DIARY MISMATCH AUDIT ===\n";
$dM = $pdo->query("SELECT d.id, d.diary_date, d.programme_id, d.paper_id, p.programme_id as paper_prog_id 
                   FROM diary d 
                   JOIN papers p ON p.id = d.paper_id 
                   WHERE d.programme_id != p.programme_id")->fetchAll();
echo "Mismatched diary rows: " . count($dM) . "\n";

echo "\n=== 5. CLASS STRENGTH AUDIT ===\n";
$cs = $pdo->query("SELECT cs.id, pr.short_code, s.name as sem, cs.strength, cs.session_name, cs.active 
                   FROM class_strength cs 
                   JOIN programmes pr ON pr.id = cs.programme_id 
                   JOIN semesters s ON s.id = cs.semester_id 
                   ORDER BY pr.short_code, s.name")->fetchAll();
foreach ($cs as $c) {
    echo "ID: {$c['id']} | {$c['short_code']} {$c['sem']} | Strength: {$c['strength']} | Session: {$c['session_name']} | Active: {$c['active']}\n";
}
