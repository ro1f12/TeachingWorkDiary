<?php
require_once __DIR__ . '/../config/db.php';
$pdo = db();

echo "=== DATABASE REGRESSION VERIFICATION ===\n";

$teacherCount = (int)$pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
echo "1. Teachers Count: $teacherCount (Expected: 8) -> " . ($teacherCount === 8 ? "PASS" : "FAIL") . "\n";

$progCount = (int)$pdo->query("SELECT COUNT(*) FROM programmes")->fetchColumn();
echo "2. Programmes Count: $progCount (Expected: 2) -> " . ($progCount === 2 ? "PASS" : "FAIL") . "\n";

$semCount = (int)$pdo->query("SELECT COUNT(*) FROM semesters")->fetchColumn();
echo "3. Semesters Count: $semCount (Expected: 3) -> " . ($semCount === 3 ? "PASS" : "FAIL") . "\n";

$paperCount = (int)$pdo->query("SELECT COUNT(*) FROM papers")->fetchColumn();
echo "4. Papers Count: $paperCount (Expected: 32) -> " . ($paperCount === 32 ? "PASS" : "FAIL") . "\n";

$roomCount = (int)$pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
echo "5. Rooms Count: $roomCount (Expected: 8) -> " . ($roomCount === 8 ? "PASS" : "FAIL") . "\n";

$ttCount = (int)$pdo->query("SELECT COUNT(*) FROM timetable")->fetchColumn();
echo "6. Timetable Count: $ttCount (Expected: 128) -> " . ($ttCount === 128 ? "PASS" : "FAIL") . "\n";

$practicalCount = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE class_type = 'Practical'")->fetchColumn();
echo "7. Practical Entries: $practicalCount (Expected: 25) -> " . ($practicalCount === 25 ? "PASS" : "FAIL") . "\n";

$blankRooms = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE room_id IS NULL")->fetchColumn();
echo "8. Blank-Room Entries: $blankRooms (Expected: 22) -> " . ($blankRooms === 22 ? "PASS" : "FAIL") . "\n";

$satCount = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE day_of_week = 6")->fetchColumn();
echo "9. Saturday Entries: $satCount (Expected: 0) -> " . ($satCount === 0 ? "PASS" : "FAIL") . "\n";

$sunCount = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE day_of_week = 7")->fetchColumn();
echo "10. Sunday Entries: $sunCount (Expected: 0) -> " . ($sunCount === 0 ? "PASS" : "FAIL") . "\n";

$expectedCodes = ['MD-IT', 'PLP-IT', 'MAR-IT', 'AC-IT', 'MN-IT', 'PPDS-CSC', 'FUA-CSC', 'BKB-MAT'];
$actualCodes = $pdo->query("SELECT short_code FROM teachers ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
echo "11. Teacher Codes: " . implode(', ', $actualCodes) . " -> " . ($expectedCodes === $actualCodes ? "PASS" : "FAIL") . "\n";

$bbCount = (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'BB'")->fetchColumn();
$ppCount = (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'PP'")->fetchColumn();
$fuaOldCount = (int)$pdo->query("SELECT COUNT(*) FROM teachers WHERE short_code = 'FUA'")->fetchColumn();
$forbiddenCheck = ($bbCount === 0 && $ppCount === 0 && $fuaOldCount === 0);
echo "12. Forbidden codes (BB=0, PP=0, FUA=0): BB=$bbCount, PP=$ppCount, FUA=$fuaOldCount -> " . ($forbiddenCheck ? "PASS" : "FAIL") . "\n";

$roomClashes = (int)$pdo->query("
    SELECT COUNT(*) FROM (
        SELECT day_of_week, start_time, end_time, room_id, COUNT(*) c
        FROM timetable
        WHERE room_id IS NOT NULL AND active = 1
        GROUP BY day_of_week, start_time, end_time, room_id
        HAVING c > 1
    ) x
")->fetchColumn();
echo "13. Simultaneous Room Clashes: $roomClashes (Expected: 0) -> " . ($roomClashes === 0 ? "PASS" : "FAIL") . "\n";

$teacherClashes = (int)$pdo->query("
    SELECT COUNT(*) FROM (
        SELECT day_of_week, start_time, end_time, teacher_id, COUNT(*) c
        FROM timetable
        WHERE teacher_id IS NOT NULL AND active = 1
        GROUP BY day_of_week, start_time, end_time, teacher_id
        HAVING c > 1
    ) x
")->fetchColumn();
echo "14. Simultaneous Teacher Clashes: $teacherClashes (Expected: 0) -> " . ($teacherClashes === 0 ? "PASS" : "FAIL") . "\n";
