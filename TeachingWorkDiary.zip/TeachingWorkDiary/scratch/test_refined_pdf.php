<?php
require 'config/config.php';
require 'config/db.php';
require 'lib/materializer.php';
require 'report_pdf.php';

$pdo = db();

// Test the calculation for various class counts
function calculate_box_heights(int $maxClasses, int $maxWorks): array {
    // Printable height in A4 Landscape (210mm - 14mm margins) = 196mm.
    // Static elements (Header 18mm, Banner 7mm, Labels 18mm, Table thead 10mm, Totals 4.5mm, Signatures 11.5mm, Spacing 8mm) = ~77mm.
    // Table rows take: classes * ~4.8mm, works * ~4.8mm.
    // If 0 works, 'Nil' takes ~5mm.
    $worksCount = max(1, $maxWorks);
    $tableRowsHeight = ($maxClasses * 4.8) + ($worksCount * 4.8);
    
    // Remaining available height for topic + remarks
    $available = 196 - 77 - $tableRowsHeight;
    
    // Clamp between min 22mm (dense day) and max 80mm (light day)
    $available = max(22.0, min(80.0, $available));
    
    $hTopic = round($available * 0.60);
    $hRemarks = round($available * 0.40);
    
    return [(int)$hTopic, (int)$hRemarks];
}

foreach ([1, 2, 3, 4, 5, 6, 7] as $c) {
    [$ht, $hr] = calculate_box_heights($c, 1);
    echo "Classes: $c, Works: 1 => Topic: {$ht}mm, Remarks: {$hr}mm (Total: " . ($ht+$hr) . "mm)\n";
}
