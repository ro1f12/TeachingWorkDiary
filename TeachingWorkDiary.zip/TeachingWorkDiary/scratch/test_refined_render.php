<?php
require 'config/config.php';
require 'config/db.php';
require 'lib/materializer.php';
require 'report_pdf.php';

$pdo = db();

// Let's create a test function to render and check the new layout
function test_render_new_layout(PDO $pdo, string $from, string $to, int $teacherId, string $label): void {
    $html = generate_report_html($pdo, $from, $to, $teacherId);
    $pdf = generate_dompdf_binary($html);
    
    preg_match_all('/\/Type\s*\/Page\b/', $pdf, $m);
    $pages = count($m[0]);
    echo "[$label] Dates: $from to $to | Teacher: $teacherId | Pages: $pages\n";
    file_put_contents("scratch/{$label}.pdf", $pdf);
}

test_render_new_layout($pdo, '2026-10-01', '2026-10-02', 0, 'test_2days');
test_render_new_layout($pdo, '2026-10-01', '2026-10-05', 0, 'test_4days');
test_render_new_layout($pdo, '2026-10-01', '2026-10-07', 0, 'test_6days');
test_render_new_layout($pdo, '2026-10-01', '2026-10-08', 0, 'test_7days');
test_render_new_layout($pdo, '2026-10-01', '2026-10-08', 3, 'test_teacher_MAR');
