<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../lib/auth.php';

$testUsers = ['admin', 'mar', 'mar_it', 'plp', 'plp_it', 'md', 'md_it', 'ac', 'ac_it', 'mn', 'mn_it', 'ppds', 'ppds_csc', 'fua', 'fua_csc', 'bkb', 'bkb_mat'];
foreach ($testUsers as $u) {
    $p = ($u === 'admin') ? 'admin123' : $u . '123';
    $ok = login_user($u, $p);
    echo "User $u login: " . ($ok ? 'OK' : 'FAILED') . "\n";
}
