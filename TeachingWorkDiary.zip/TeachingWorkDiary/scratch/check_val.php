<?php
require 'config/config.php';
require 'config/db.php';
$pdo = db();

echo "Papers programme_ids: " . implode(',', $pdo->query("SELECT DISTINCT programme_id FROM papers")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Timetable programme_ids: " . implode(',', $pdo->query("SELECT DISTINCT programme_id FROM timetable")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Diary programme_ids: " . implode(',', $pdo->query("SELECT DISTINCT programme_id FROM diary")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Class strength programme_ids: " . implode(',', $pdo->query("SELECT DISTINCT programme_id FROM class_strength")->fetchAll(PDO::FETCH_COLUMN)) . "\n";

echo "\nPapers semester_ids: " . implode(',', $pdo->query("SELECT DISTINCT semester_id FROM papers")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Timetable semester_ids: " . implode(',', $pdo->query("SELECT DISTINCT semester_id FROM timetable")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Diary semester_ids: " . implode(',', $pdo->query("SELECT DISTINCT semester_id FROM diary")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
echo "Class strength semester_ids: " . implode(',', $pdo->query("SELECT DISTINCT semester_id FROM class_strength")->fetchAll(PDO::FETCH_COLUMN)) . "\n";
