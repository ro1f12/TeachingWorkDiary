<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../lib/materializer.php';
require_once __DIR__.'/../report_pdf.php';

$pdo = db();

function get_pdf_page_count(string $pdfContent): int {
    preg_match_all("/\/Type\s*\/Page\b/", $pdfContent, $matches);
    return count($matches[0]);
}

echo "=== TESTING PRODUCTION report_pdf.php ===\n";

// Test 1: 01-10-2026 to 07-10-2026 (6 valid days -> 3 pages)
$html1 = generate_report_html($pdo, '2026-10-01', '2026-10-07', 0);
$pdfBin1 = generate_dompdf_binary($html1);
file_put_contents(__DIR__.'/prod_test_01_07.pdf', $pdfBin1);
$pages1 = get_pdf_page_count($pdfBin1);

$hasSunday1 = stripos($html1, 'Sunday') !== false || stripos($html1, '04 October') !== false;
$hasAllTeachers1 = stripos($html1, 'Teacher: All Teachers') !== false;

echo "Test 1 (01 to 07 Oct):\n";
echo "  Page count: $pages1 (Expected: 3)\n";
echo "  Sunday present in HTML: " . ($hasSunday1 ? 'YES (FAIL)' : 'NO (PASS)') . "\n";
echo "  Teacher label has 'All Teachers': " . ($hasAllTeachers1 ? 'YES (PASS)' : 'NO (FAIL)') . "\n";

// Test 2: 01-10-2026 to 08-10-2026 (7 valid days -> 4 pages)
$html2 = generate_report_html($pdo, '2026-10-01', '2026-10-08', 0);
$pdfBin2 = generate_dompdf_binary($html2);
file_put_contents(__DIR__.'/prod_test_01_08.pdf', $pdfBin2);
$pages2 = get_pdf_page_count($pdfBin2);

$hasSunday2 = stripos($html2, 'Sunday') !== false || stripos($html2, '04 October') !== false;
$hasBlankNotice = stripos($html2, 'Intentionally Blank') !== false;

echo "\nTest 2 (01 to 08 Oct):\n";
echo "  Page count: $pages2 (Expected: 4)\n";
echo "  Sunday present in HTML: " . ($hasSunday2 ? 'YES (FAIL)' : 'NO (PASS)') . "\n";
echo "  Page 4 blank panel notice: " . ($hasBlankNotice ? 'YES (PASS)' : 'NO (FAIL)') . "\n";

// Test 3: Individual Teacher Report (Teacher #1: Dr. Manisha Deka)
$html3 = generate_report_html($pdo, '2026-10-01', '2026-10-07', 1);
$pdfBin3 = generate_dompdf_binary($html3);
$pages3 = get_pdf_page_count($pdfBin3);

$hasTeacherName = stripos($html3, 'Manisha Deka') !== false;
$hasBlankTeacherLine = stripos($html3, 'Teacher: __________________________') !== false;

echo "\nTest 3 (Individual Teacher #1):\n";
echo "  Page count: $pages3\n";
echo "  Teacher name present: " . ($hasTeacherName ? 'YES (PASS)' : 'NO (FAIL)') . "\n";
echo "  Blank underline present: " . ($hasBlankTeacherLine ? 'YES (FAIL)' : 'NO (PASS)') . "\n";

// Test 4: Dense Day Single Page Fit (7 classes, 2 duties, holiday status, substitution, long remarks)
echo "\nTest 4 (Dense Day Fit):\n";
// Let's create a temporary dense day in diary on 2026-10-29
$testDenseDate = '2026-10-29';
$pdo->exec("DELETE FROM diary WHERE diary_date='$testDenseDate'");
$pdo->exec("DELETE FROM additional_works WHERE work_date='$testDenseDate'");

// Insert 7 classes with long subjects, holiday, substitution, remarks
$statuses = ['Conducted', 'Scheduled - Holiday', 'Conducted', 'Cancelled', 'Conducted', 'Conducted', 'Conducted'];
for ($i = 1; $i <= 7; $i++) {
    $st = $statuses[$i-1];
    $pdo->exec("INSERT INTO diary (diary_date, timetable_id, teacher_id, original_teacher_id, programme_id, semester_id, paper_id, room_id, start_time, end_time, status, present, total, topic, remarks) 
    VALUES ('$testDenseDate', NULL, 1, 2, 1, 1, 1, 1, '09:00:00', '10:00:00', '$st', 25, 30, 'Unit $i: Advance Distributed Architecture with Microservices and Event Queues', 'Substituted class with detailed remarks discussing semester practical syllabus')");
}
// Insert 2 additional works
$pdo->exec("INSERT INTO additional_works (work_date, teacher_id, work_type, details, duration, remarks) 
VALUES ('$testDenseDate', 1, 'Meeting', 'Departmental Academic Review & NAAC Criterion III Consultation', '1 hr 30 mins', 'Discussed documentation roadmap')");
$pdo->exec("INSERT INTO additional_works (work_date, teacher_id, work_type, details, duration, remarks) 
VALUES ('$testDenseDate', 1, 'Examination', 'Internal Assessment Script Scrutiny and Marksheet Entry', '2 hrs', 'Marks verified')");

$htmlDense = generate_report_html($pdo, $testDenseDate, $testDenseDate, 0);
$pdfBinDense = generate_dompdf_binary($htmlDense);
$pagesDense = get_pdf_page_count($pdfBinDense);
echo "  Dense day (7 classes + 2 duties + remarks) page count: $pagesDense (Expected: 1)\n";

// Cleanup test dense date
$pdo->exec("DELETE FROM diary WHERE diary_date='$testDenseDate'");
$pdo->exec("DELETE FROM additional_works WHERE work_date='$testDenseDate'");

echo "\n=== ALL PRODUCTION PDF TESTS COMPLETE ===\n";
