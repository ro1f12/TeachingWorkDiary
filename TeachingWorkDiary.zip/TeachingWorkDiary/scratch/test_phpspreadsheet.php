<?php
require_once 'c:/xampp/htdocs/TeachingWorkDiary/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'Hello Lalit Chandra Bharali College');
$writer = new Xlsx($spreadsheet);
$tmpFile = __DIR__ . '/test_output.xlsx';
$writer->save($tmpFile);

if (file_exists($tmpFile)) {
    echo "SUCCESS: PhpSpreadsheet generated $tmpFile (" . filesize($tmpFile) . " bytes)\n";
    unlink($tmpFile);
} else {
    echo "FAILED to generate file\n";
}
