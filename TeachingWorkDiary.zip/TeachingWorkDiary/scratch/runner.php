<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$file = $argv[1] ?? 'index.php';
$queryString = $argv[2] ?? '';
$userType = $argv[3] ?? 'admin';

parse_str($queryString, $_GET);

$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI'] = '/TeachingWorkDiary/' . $file . ($queryString ? '?' . $queryString : '');
$_SERVER['SCRIPT_NAME'] = '/TeachingWorkDiary/' . $file;
$_SERVER['HTTP_HOST'] = 'localhost';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($userType === 'teacher') {
    $_SESSION['user'] = [
        'id' => 10,
        'username' => 'md_it',
        'role' => 'teacher',
        'teacher_id' => 1,
        'display_name' => 'Dr. Manisha Deka',
        'teacher_name' => 'Dr. Manisha Deka',
        'teacher_code' => 'MD-IT'
    ];
} else {
    $_SESSION['user'] = [
        'id' => 1,
        'username' => 'admin',
        'role' => 'admin',
        'teacher_id' => null,
        'display_name' => 'Administrator',
        'teacher_name' => 'Administrator',
        'teacher_code' => 'ADMIN'
    ];
}

try {
    ob_start();
    require __DIR__ . '/../' . $file;
    $out = ob_get_clean();
    echo "STATUS: SUCCESS | Bytes: " . strlen($out) . "\n";
} catch (Throwable $e) {
    ob_end_clean();
    echo "STATUS: EXCEPTION | " . get_class($e) . ": " . $e->getMessage() . " at " . $e->getFile() . ":" . $e->getLine() . "\n";
}
