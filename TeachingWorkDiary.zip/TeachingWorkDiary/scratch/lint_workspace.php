<?php
$dir = __DIR__ . '/..';
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
$phpFiles = [];
foreach ($files as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $path = $file->getRealPath();
        if (str_contains($path, 'vendor')) continue; // skip vendor
        $phpFiles[] = $path;
    }
}

$errors = 0;
foreach ($phpFiles as $f) {
    $out = [];
    $ret = 0;
    exec("c:\\xampp\\php\\php.exe -l " . escapeshellarg($f) . " 2>&1", $out, $ret);
    if ($ret !== 0) {
        echo "LINT ERROR in $f:\n" . implode("\n", $out) . "\n\n";
        $errors++;
    }
}

if ($errors === 0) {
    echo "LINT SUCCESS: All " . count($phpFiles) . " PHP files passed syntax check with 0 errors.\n";
} else {
    echo "LINT FAILED: $errors errors found.\n";
    exit(1);
}
