<?php
$backupDir = __DIR__ . '/../backups/routing_fix_backup_' . date('Ymd_His');
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0777, true);
}

$filesToBackup = [
    'lib/materializer.php',
    'index.php',
    'lib/layout.php',
    'masters.php',
    'edit_diary.php',
    'report_pdf.php'
];

foreach ($filesToBackup as $f) {
    $src = __DIR__ . '/../' . $f;
    $dst = $backupDir . '/' . basename($f);
    if (file_exists($src)) {
        copy($src, $dst);
        echo "Backed up: $f -> $dst\n";
    }
}
echo "Backup completed in $backupDir\n";
