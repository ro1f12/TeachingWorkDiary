<?php
require 'config/config.php';
require 'config/db.php';
require 'lib/materializer.php';
require 'report_pdf.php';

$pdo = db();
$testDate = '2026-11-28'; // Saturday
$tMAR = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='MAR'")->fetchColumn();
$tPLP = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='PLP'")->fetchColumn();

// Clean up
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$testDate]);
$pdo->prepare("DELETE FROM additional_works WHERE work_date=?")->execute([$testDate]);

// Disable timetable generation on this test date by checking what's on Saturday
// Saturday has 1 or 2 classes, let's delete them after materialize or insert 7 classes
materialize_range($testDate, $testDate);
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$testDate]);

$validPapers = $pdo->query("SELECT id, programme_id, semester_id, name FROM papers LIMIT 7")->fetchAll();
$r1 = (int)$pdo->query("SELECT id FROM rooms LIMIT 1")->fetchColumn();

// Insert exactly 7 classes:
// including long paper names, substituted class, holiday status, long remarks
$classes = [
    ['09:00:00', '10:00:00', $tMAR, $tMAR, $validPapers[0]['programme_id'], $validPapers[0]['semester_id'], $validPapers[0]['id'], $r1, 'Theory', 'Unit 1: Object-Oriented Programming Principles & Class Syntax', 30, 30, 'Conducted', 'All regular students attended punctually'],
    ['10:00:00', '11:00:00', $tMAR, $tPLP, $validPapers[1]['programme_id'], $validPapers[1]['semester_id'], $validPapers[1]['id'], $r1, 'Theory', 'Unit 1: Inheritance, Polymorphism & Virtual Functions in C++', 28, 30, 'Conducted', 'Substituted class taken by PLP'],
    ['11:00:00', '12:00:00', $tMAR, $tMAR, $validPapers[2]['programme_id'], $validPapers[2]['semester_id'], $validPapers[2]['id'], $r1, 'Theory', 'Unit 2: Network Layer Protocols & IPv4 / IPv6 Subnetting Architecture', 29, 30, 'Conducted', 'Conducted with practical simulation examples'],
    ['12:00:00', '13:00:00', $tMAR, $tMAR, $validPapers[3]['programme_id'], $validPapers[3]['semester_id'], $validPapers[3]['id'], $r1, 'Theory', 'Unit 3: Relational Algebra, Normalization & SQL Queries', 0, 30, 'Cancelled', 'Cancelled due to college urgent general assembly meeting'],
    ['13:00:00', '13:45:00', $tMAR, $tMAR, $validPapers[4]['programme_id'], $validPapers[4]['semester_id'], $validPapers[4]['id'], $r1, 'Theory', 'Restricted Holiday Observance / Department Review', 0, 30, 'Scheduled - Holiday', 'Holiday status recorded'],
    ['13:45:00', '14:45:00', $tMAR, $tMAR, $validPapers[5]['programme_id'], $validPapers[5]['semester_id'], $validPapers[5]['id'], $r1, 'Practical', 'Lab Exercise: Implementing Dynamic Memory Allocation & Friend Functions', 30, 30, 'Conducted', 'Practical lab session held in IT Lab 1'],
    ['14:45:00', '15:45:00', $tMAR, $tMAR, $validPapers[6]['programme_id'], $validPapers[6]['semester_id'], $validPapers[6]['id'], $r1, 'Theory', 'Unit 4: Server-Side Web Scripting with PHP and Session Management', 30, 30, 'Conducted', 'Comprehensive review and doubt clearing session']
];

foreach ($classes as $c) {
    $pdo->prepare("
        INSERT INTO diary(diary_date, start_time, end_time, teacher_id, original_teacher_id, programme_id, semester_id, paper_id, room_id, class_type, topic, present, total, status, remarks, is_edited)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    ")->execute([
        $testDate, $c[0], $c[1], $c[2], $c[3], $c[4], $c[5], $c[6], $c[7], $c[8], $c[9], $c[10], $c[11], $c[12], $c[13]
    ]);
}

// 2 Additional works / duties
$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '08:30:00', '09:00:00', ?, 'Departmental Work', 'Academic routine review and departmental log verification', '30 mins', 'Routine')")
    ->execute([$testDate, $tMAR]);
$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '16:00:00', '17:00:00', ?, 'Official Meeting', 'Departmental Faculty Meeting with Academic Coordinator', '1 hr', 'Discussed exams')")
    ->execute([$testDate, $tMAR]);

// Generate HTML and PDF
// Note: In generate_report_html, materialize_range is called. Since diary has is_edited=1, it won't overwrite them!
$html = generate_report_html($pdo, $testDate, $testDate, $tMAR);
$pdf = generate_dompdf_binary($html);
preg_match_all('/\/Type\s*\/Page\b/', $pdf, $m);
$pageCount = count($m[0]);
echo "7 Classes Dense Day Page Count: " . $pageCount . "\n";
file_put_contents('scratch/dense_7_classes.pdf', $pdf);
