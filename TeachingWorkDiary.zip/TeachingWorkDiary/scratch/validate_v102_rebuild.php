<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

$pdo = db();

echo "============================================================\n";
echo "V1.0.2 TIMETABLE DATABASE VALIDATION & VERIFICATION\n";
echo "============================================================\n\n";

$validationErrors = [];

// 1. Check for illegal teacher codes: BB, PP, FUA
$illegalCodes = ['BB', 'PP', 'FUA'];
foreach ($illegalCodes as $code) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE short_code = ?");
    $st->execute([$code]);
    $count = (int)$st->fetchColumn();
    if ($count > 0) {
        $validationErrors[] = "Illegal teacher code found in database: '$code' ($count records)! Must be BKB-MAT, PPDS-CSC, or FUA-CSC.";
    }
}

// 2. Verify Official Teacher Codes present
$officialCodes = ['MD-IT', 'PLP-IT', 'MAR-IT', 'AC-IT', 'MN-IT', 'PPDS-CSC', 'FUA-CSC', 'BKB-MAT'];
$dbTeachers = $pdo->query("SELECT id, name, short_code FROM teachers ORDER BY id")->fetchAll();
$foundCodes = array_column($dbTeachers, 'short_code');
foreach ($officialCodes as $code) {
    if (!in_array($code, $foundCodes, true)) {
        $validationErrors[] = "Missing official teacher code: '$code' in teachers master.";
    }
}

// 3. Count duplicate timetable slots (same day, start_time, prog, sem)
$dupCheck = $pdo->query("
    SELECT day_of_week, start_time, programme_id, semester_id, COUNT(*) as cnt
    FROM timetable
    WHERE active = 1
    GROUP BY day_of_week, start_time, programme_id, semester_id
    HAVING cnt > 1
")->fetchAll();

$duplicateCount = count($dupCheck);
if ($duplicateCount > 0) {
    foreach ($dupCheck as $d) {
        $validationErrors[] = "Duplicate class scheduled for same programme/semester/day/time: Day {$d['day_of_week']}, {$d['start_time']} (Count: {$d['cnt']})";
    }
}

// 4. Check for room clash at the same hour
$roomClashCheck = $pdo->query("
    SELECT day_of_week, start_time, room_id, COUNT(*) as cnt
    FROM timetable
    WHERE active = 1 AND room_id IS NOT NULL
    GROUP BY day_of_week, start_time, room_id
    HAVING cnt > 1
")->fetchAll();
if (count($roomClashCheck) > 0) {
    foreach ($roomClashCheck as $rc) {
        $rName = $pdo->query("SELECT name FROM rooms WHERE id = {$rc['room_id']}")->fetchColumn();
        $validationErrors[] = "Room clash detected: Room $rName is scheduled for {$rc['cnt']} classes simultaneously on Day {$rc['day_of_week']} at {$rc['start_time']}";
    }
}

// 5. Check for teacher clash at the same hour
$teacherClashCheck = $pdo->query("
    SELECT day_of_week, start_time, teacher_id, COUNT(*) as cnt
    FROM timetable
    WHERE active = 1 AND teacher_id IS NOT NULL
    GROUP BY day_of_week, start_time, teacher_id
    HAVING cnt > 1
")->fetchAll();
if (count($teacherClashCheck) > 0) {
    foreach ($teacherClashCheck as $tc) {
        $tCode = $pdo->query("SELECT short_code FROM teachers WHERE id = {$tc['teacher_id']}")->fetchColumn();
        $validationErrors[] = "Teacher clash detected: Teacher $tCode is scheduled for {$tc['cnt']} classes simultaneously on Day {$tc['day_of_week']} at {$tc['start_time']}";
    }
}

// 6. Metrics
$numTeachers = (int)$pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$numProgrammes = (int)$pdo->query("SELECT COUNT(*) FROM programmes")->fetchColumn();
$numSemesters = (int)$pdo->query("SELECT COUNT(*) FROM semesters")->fetchColumn();
$numPapers = (int)$pdo->query("SELECT COUNT(*) FROM papers WHERE active = 1")->fetchColumn();
$numRooms = (int)$pdo->query("SELECT COUNT(*) FROM rooms WHERE active = 1")->fetchColumn();
$numTimetable = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1")->fetchColumn();
$numPractical = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1 AND class_type = 'Practical'")->fetchColumn();
$numBlankRoom = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE active = 1 AND room_id IS NULL")->fetchColumn();
$numUnresolvedMappings = (int)$pdo->query("
    SELECT COUNT(*) 
    FROM timetable t 
    LEFT JOIN programmes p ON p.id = t.programme_id 
    LEFT JOIN semesters s ON s.id = t.semester_id 
    LEFT JOIN papers pa ON pa.id = t.paper_id 
    WHERE p.id IS NULL OR s.id IS NULL OR pa.id IS NULL
")->fetchColumn();

// 7. Check for Saturday or Sunday entries
$weekendCount = (int)$pdo->query("SELECT COUNT(*) FROM timetable WHERE day_of_week IN (6, 7)")->fetchColumn();
if ($weekendCount > 0) {
    $validationErrors[] = "Found $weekendCount weekend (Saturday/Sunday) timetable entries in Monday–Friday timetable!";
}

// Print Metrics
echo "1. Number of teacher master records: $numTeachers\n";
echo "2. Number of programme records: $numProgrammes\n";
echo "3. Number of semester records: $numSemesters\n";
echo "4. Number of paper records used: $numPapers\n";
echo "5. Number of room records: $numRooms\n";
echo "6. Number of timetable entries: $numTimetable\n";
echo "7. Number of Practical entries: $numPractical\n";
echo "8. Number of entries with blank room: $numBlankRoom\n";
echo "9. Number of validation errors: " . count($validationErrors) . "\n";
echo "10. Number of duplicate entries: $duplicateCount\n";
echo "11. Number of unresolved mappings: $numUnresolvedMappings\n\n";

if (!empty($validationErrors)) {
    echo "!!! VALIDATION ERRORS DETECTED !!!\n";
    foreach ($validationErrors as $err) {
        echo " - FAIL: $err\n";
    }
    echo "\n";
} else {
    echo ">>> ALL VALIDATION CHECKS PASSED WITH ZERO ERRORS <<<\n\n";
}

// 8. Fetch complete timetable ordered by DAY, TIME, PROGRAMME, SEMESTER
$dayNames = [
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday',
    6 => 'Saturday',
    7 => 'Sunday'
];

$qTT = $pdo->query("
    SELECT t.id, t.day_of_week, t.start_time, t.end_time,
           p.short_code as programme_code,
           s.name as semester_name,
           pa.name as paper_name, pa.code as paper_code,
           tc.short_code as teacher_code, tc.name as teacher_name,
           r.name as room_name,
           t.class_type,
           t.notes
    FROM timetable t
    JOIN programmes p ON p.id = t.programme_id
    JOIN semesters s ON s.id = t.semester_id
    JOIN papers pa ON pa.id = t.paper_id
    LEFT JOIN teachers tc ON tc.id = t.teacher_id
    LEFT JOIN rooms r ON r.id = t.room_id
    WHERE t.active = 1
    ORDER BY t.day_of_week, t.start_time, p.short_code, s.name
")->fetchAll();

echo "========================================================================================================================\n";
echo "COMPLETE OFFICIAL V1.0.2 TIMETABLE (ORDERED BY DAY, TIME, PROGRAMME, SEMESTER)\n";
echo "========================================================================================================================\n";
printf("%-10s | %-13s | %-8s | %-5s | %-8s | %-10s | %-28s | %-14s | %-10s\n",
    "DAY", "TIME", "PROG", "SEM", "PAPER", "TEACHER", "TEACHER NAME", "ROOM", "CLASS TYPE"
);
echo str_repeat("-", 120) . "\n";

$currentDay = null;
foreach ($qTT as $row) {
    if ($currentDay !== $row['day_of_week']) {
        $currentDay = $row['day_of_week'];
        echo "\n--- " . strtoupper($dayNames[$currentDay]) . " ---\n";
    }

    $timeStr = substr($row['start_time'], 0, 5) . '–' . substr($row['end_time'], 0, 5);
    $tCode = $row['teacher_code'] ?? '—';
    $tName = $row['teacher_name'] ?? '— (Unassigned)';
    $rName = $row['room_name'] ?? '— (Blank)';
    if (!empty($row['notes'])) {
        $rName .= ' [' . $row['notes'] . ']';
    }

    printf("%-10s | %-13s | %-8s | %-5s | %-8s | %-10s | %-28s | %-14s | %-10s\n",
        $dayNames[$row['day_of_week']],
        $timeStr,
        $row['programme_code'],
        $row['semester_name'],
        $row['paper_name'],
        $tCode,
        $tName,
        $rName,
        $row['class_type']
    );
}
echo "\n========================================================================================================================\n";
echo "TOTAL TIMETABLE ENTRIES PRINTED: " . count($qTT) . "\n";
echo "========================================================================================================================\n";
