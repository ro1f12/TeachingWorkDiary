<?php
require_once 'config/config.php';
require_once 'config/db.php';
require_once 'lib/materializer.php';
require_once 'report_pdf.php';

$pdo = db();

function calculate_page_box_heights(int $maxClasses, int $maxWorks): array {
    if ($maxClasses <= 1) {
        $hTopic = 44;
        $hRemarks = 28;
    } elseif ($maxClasses <= 2) {
        $hTopic = 40;
        $hRemarks = 26;
    } elseif ($maxClasses <= 3) {
        $hTopic = 35;
        $hRemarks = 23;
    } elseif ($maxClasses <= 4) {
        $hTopic = 30;
        $hRemarks = 20;
    } elseif ($maxClasses <= 5) {
        $hTopic = 25;
        $hRemarks = 17;
    } elseif ($maxClasses <= 6) {
        $hTopic = 20;
        $hRemarks = 13;
    } else { // 7+ classes (Dense Day)
        $hTopic = 13;
        $hRemarks = 9;
    }

    if ($maxWorks >= 2) {
        $hTopic = max(11, $hTopic - 4);
        $hRemarks = max(8, $hRemarks - 3);
    }

    return [$hTopic, $hRemarks];
}

function render_day_panel_refined(PDO $pdo, ?string $dateStr, int $teacherId, int $hTopic, int $hRemarks): string {
    if (!$dateStr) {
        return '
        <td class="blank-panel" style="width:50%;vertical-align:top;padding:0 2.5mm;">
            <table style="width:100%;height:152mm;border:1px dashed #cbd5e1;background:#fafbfc;border-collapse:collapse;">
                <tr>
                    <td style="text-align:center;vertical-align:middle;color:#94a3b8;font-size:8.5pt;font-style:italic;">
                        — Intentionally Blank —
                    </td>
                </tr>
            </table>
        </td>';
    }

    $q = '
        SELECT d.*, 
               t.name teacher_name, t.short_code teacher_code,
               ot.name original_teacher_name, ot.short_code original_code,
               p.name programme_name, p.short_code prog_code, s.name semester_name, 
               pa.name paper_name, pa.code paper_code, 
               r.name room_name
        FROM diary d
        JOIN teachers t ON t.id = d.teacher_id
        LEFT JOIN teachers ot ON ot.id = d.original_teacher_id
        JOIN programmes p ON p.id = d.programme_id
        JOIN semesters s ON s.id = d.semester_id
        JOIN papers pa ON pa.id = d.paper_id
        LEFT JOIN rooms r ON r.id = d.room_id
        WHERE d.diary_date = ?
    ';
    $args = [$dateStr];
    if ($teacherId > 0) {
        $q .= ' AND d.teacher_id = ?';
        $args[] = $teacherId;
    }
    $q .= ' ORDER BY d.start_time, d.id';
    $st = $pdo->prepare($q);
    $st->execute($args);
    $classes = $st->fetchAll();

    $totalClasses = count($classes);
    $conductedCount = count(array_filter($classes, fn($c) => $c['status'] === 'Conducted'));
    $cancelledCount = count(array_filter($classes, fn($c) => $c['status'] === 'Cancelled'));

    $qW = 'SELECT * FROM additional_works WHERE work_date = ?';
    $argsW = [$dateStr];
    if ($teacherId > 0) {
        $qW .= ' AND teacher_id = ?';
        $argsW[] = $teacherId;
    }
    $qW .= ' ORDER BY start_time, id';
    $stW = $pdo->prepare($qW);
    $stW->execute($argsW);
    $works = $stW->fetchAll();

    $formattedDate = date('l, d F Y', strtotime($dateStr));

    // Collect Topic entries
    $topicEntries = [];
    foreach ($classes as $c) {
        if (!empty(trim($c['topic'] ?? ''))) {
            $topicEntries[] = [
                'paper_code' => $c['paper_code'] ?: ($c['prog_code'].' '.$c['semester_name']),
                'topic' => trim($c['topic'])
            ];
        }
    }

    // Collect Remark entries
    $remarkEntries = [];
    foreach ($classes as $c) {
        if (!empty(trim($c['remarks'] ?? ''))) {
            $remarkEntries[] = [
                'source' => $c['prog_code'].' '.$c['semester_name'].($c['paper_code'] ? ' ('.$c['paper_code'].')' : ''),
                'remark' => trim($c['remarks'])
            ];
        }
    }
    foreach ($works as $w) {
        if (!empty(trim($w['remarks'] ?? ''))) {
            $remarkEntries[] = [
                'source' => $w['work_type'],
                'remark' => trim($w['remarks'])
            ];
        }
    }

    // Calculate ruled lines for Topic box
    $topicLinesUsed = count($topicEntries);
    $topicRemainingHeight = max(0, $hTopic - ($topicLinesUsed * 4.2) - 2.5);
    $topicRuledCount = (int)floor($topicRemainingHeight / 5.0);

    // Calculate ruled lines for Remarks box
    $remarksLinesUsed = count($remarkEntries);
    $remarksRemainingHeight = max(0, $hRemarks - ($remarksLinesUsed * 4.2) - 2.5);
    $remarksRuledCount = (int)floor($remarksRemainingHeight / 5.0);

    ob_start();
    ?>
    <td class="day-panel" style="width:50%;vertical-align:top;padding:0 2.5mm;">
        <div class="day-banner" style="background:#e2e8f0;border:1px solid #475569;font-size:9pt;font-weight:bold;text-align:center;padding:1.4mm;margin-bottom:1.2mm;color:#0f172a;">
            <?=htmlspecialchars($formattedDate, ENT_QUOTES, 'UTF-8')?>
        </div>
        
        <div class="section-label" style="font-size:7.5pt;font-weight:bold;background:#f1f5f9;border:1px solid #64748b;padding:0.7mm 1.8mm;margin-bottom:0.7mm;color:#1e293b;letter-spacing:0.3px;">
            ACADEMIC WORKS
        </div>
        <table class="report-table" style="width:100%;border-collapse:collapse;font-size:7.2pt;margin-bottom:1mm;line-height:1.15;">
            <thead>
                <tr style="background:#f8fafc;">
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:6%;text-align:center;">Sl.</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:12%;">Time</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:18%;">Programme</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:30%;">Paper / Subject</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:9%;text-align:center;">P/T</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:10%;text-align:center;">Room</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:15%;text-align:center;">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php $sl = 1; foreach ($classes as $c): ?>
                <tr>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;"><?=$sl++?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;"><?=substr($c['start_time'], 0, 5).'–'.substr($c['end_time'], 0, 5)?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;"><?=htmlspecialchars($c['prog_code'].' '.$c['semester_name'], ENT_QUOTES, 'UTF-8')?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;word-break:break-word;">
                        <?=htmlspecialchars($c['paper_name'], ENT_QUOTES, 'UTF-8')?>
                    </td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;font-weight:bold;"><?=$c['present']?>/<?=$c['total']?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;"><?=htmlspecialchars($c['room_name'] ?? '—', ENT_QUOTES, 'UTF-8')?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;font-size:6.8pt;">
                        <?php if ($c['status'] === 'Conducted'): ?>
                            <span style="color:#166534;font-weight:bold;">Conducted</span>
                        <?php elseif ($c['status'] === 'Cancelled'): ?>
                            <span style="color:#991b1b;font-weight:bold;">Cancelled</span>
                        <?php elseif (str_contains($c['status'], 'Holiday')): ?>
                            <span style="color:#6b21a8;font-weight:bold;line-height:1.05;display:inline-block;">Scheduled<br>– Holiday</span>
                        <?php else: ?>
                            <span style="font-weight:bold;"><?=htmlspecialchars($c['status'], ENT_QUOTES, 'UTF-8')?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($totalClasses === 0): ?>
                <tr>
                    <td colspan="7" style="border:1px solid #64748b;padding:2mm;text-align:center;color:#64748b;font-style:italic;">No academic classes scheduled / conducted.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <div class="totals-strip" style="font-size:7.2pt;font-weight:bold;background:#f8fafc;border:1px solid #64748b;padding:0.7mm 1.8mm;text-align:center;margin-bottom:1.1mm;color:#1e293b;">
            TOTAL CLASS: <?=$totalClasses?> &nbsp;|&nbsp; ALLOTTED: <?=$totalClasses?> &nbsp;|&nbsp; CONDUCTED: <?=$conductedCount?> &nbsp;|&nbsp; CANCELLED: <?=$cancelledCount?>
        </div>

        <div class="section-label" style="font-size:7.5pt;font-weight:bold;background:#f1f5f9;border:1px solid #64748b;padding:0.7mm 1.8mm;margin-bottom:0.7mm;color:#1e293b;letter-spacing:0.3px;">
            ADDITIONAL WORKS / MEETINGS
        </div>
        <table class="report-table" style="width:100%;border-collapse:collapse;font-size:7.2pt;margin-bottom:1.2mm;line-height:1.15;">
            <thead>
                <tr style="background:#f8fafc;">
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:6%;text-align:center;">Sl.</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:14%;">Time</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:66%;">Details / Work</th>
                    <th style="border:1px solid #64748b;padding:0.8mm 0.7mm;width:14%;text-align:center;">Duration</th>
                </tr>
            </thead>
            <tbody>
            <?php $wSl = 1; foreach ($works as $w): ?>
                <tr>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;"><?=$wSl++?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;"><?=htmlspecialchars(($w['start_time'] ? substr($w['start_time'],0,5).'–'.substr($w['end_time']?:'',0,5) : '—'), ENT_QUOTES, 'UTF-8')?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;"><?=htmlspecialchars($w['work_type'].': '.$w['details'], ENT_QUOTES, 'UTF-8')?></td>
                    <td style="border:1px solid #64748b;padding:0.8mm 0.7mm;text-align:center;"><?=htmlspecialchars($w['duration'] ?? '—', ENT_QUOTES, 'UTF-8')?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (count($works) === 0): ?>
                <tr><td colspan="4" style="border:1px solid #64748b;padding:1.4mm;text-align:center;color:#64748b;font-style:italic;">— Nil —</td></tr>
            <?php endif; ?>
            </tbody>
        </table>

        <div class="section-label" style="font-size:7.5pt;font-weight:bold;background:#f1f5f9;border:1px solid #64748b;padding:0.7mm 1.8mm;margin-bottom:0.7mm;color:#1e293b;letter-spacing:0.3px;">
            TOPIC / ACADEMIC NOTES
        </div>
        <div class="diary-box topic-box" style="height:<?=$hTopic?>mm;border:1px solid #64748b;background:#ffffff;padding:1mm 1.8mm;margin-bottom:1.1mm;font-size:6.8pt;color:#1e293b;overflow:hidden;box-sizing:border-box;">
            <?php if (!empty($topicEntries)): ?>
                <?php foreach ($topicEntries as $tItem): ?>
                    <div style="margin-bottom:0.6mm;line-height:1.15;">
                        <strong><?=htmlspecialchars($tItem['paper_code'], ENT_QUOTES, 'UTF-8')?>:</strong> 
                        <?=htmlspecialchars($tItem['topic'], ENT_QUOTES, 'UTF-8')?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php for ($i = 0; $i < $topicRuledCount; $i++): ?>
                <div style="border-bottom:1px dotted #cbd5e1;height:5.0mm;"></div>
            <?php endfor; ?>
        </div>

        <div class="section-label" style="font-size:7.5pt;font-weight:bold;background:#f1f5f9;border:1px solid #64748b;padding:0.7mm 1.8mm;margin-bottom:0.7mm;color:#1e293b;letter-spacing:0.3px;">
            REMARKS
        </div>
        <div class="diary-box remarks-box" style="height:<?=$hRemarks?>mm;border:1px solid #64748b;background:#ffffff;padding:1mm 1.8mm;margin-bottom:1.5mm;font-size:6.8pt;color:#1e293b;overflow:hidden;box-sizing:border-box;">
            <?php if (!empty($remarkEntries)): ?>
                <?php foreach ($remarkEntries as $rItem): ?>
                    <div style="margin-bottom:0.6mm;line-height:1.15;">
                        <strong><?=htmlspecialchars($rItem['source'], ENT_QUOTES, 'UTF-8')?>:</strong> 
                        <?=htmlspecialchars($rItem['remark'], ENT_QUOTES, 'UTF-8')?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php for ($i = 0; $i < $remarksRuledCount; $i++): ?>
                <div style="border-bottom:1px dotted #cbd5e1;height:5.0mm;"></div>
            <?php endfor; ?>
        </div>

        <table style="width:100%;border-collapse:collapse;margin-top:1.5mm;">
            <tr>
                <td style="width:50%;text-align:center;vertical-align:bottom;padding-top:4.5mm;">
                    <div style="border-top:1px solid #1e293b;width:82%;margin:0 auto;padding-top:0.8mm;font-size:7.5pt;font-weight:bold;color:#1e293b;">
                        Signature of Teacher
                    </div>
                </td>
                <td style="width:50%;text-align:center;vertical-align:bottom;padding-top:4.5mm;">
                    <div style="border-top:1px solid #1e293b;width:82%;margin:0 auto;padding-top:0.8mm;font-size:7.5pt;font-weight:bold;color:#1e293b;">
                        Signature of HoD / Coordinator
                    </div>
                </td>
            </tr>
        </table>
    </td>
    <?php
    return ob_get_clean();
}

function generate_report_html_refined(PDO $pdo, string $from, string $to, int $teacherId): string {
    materialize_range($from, $to);

    $settings = [];
    foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $s) {
        $settings[$s['setting_key']] = $s['setting_value'];
    }

    // Teacher label: "All Teachers" if 0, otherwise actual teacher name
    if ($teacherId > 0) {
        $tSt = $pdo->prepare('SELECT name, designation FROM teachers WHERE id=?');
        $tSt->execute([$teacherId]);
        $tInfo = $tSt->fetch();
        $teacherName = $tInfo ? ($tInfo['name'] . ($tInfo['designation'] ? ' ('.$tInfo['designation'].')' : '')) : 'All Teachers';
    } else {
        $teacherName = 'All Teachers';
    }

    $dates = get_active_report_dates($pdo, $from, $to, $teacherId);

    $institution = $settings['institution_name'] ?? 'LALIT CHANDRA BHARALI COLLEGE, MALIGAON, GUWAHATI – 781011';
    $department = $settings['department'] ?? 'Department of Information Technology';
    $reportTitle = $settings['report_title'] ?? 'TEACHING & WORK DIARY';

    $pagesHtml = '';
    $totalDays = count($dates);

    if ($totalDays === 0) {
        $pagesHtml = '
        <div class="pdf-page">
            <div class="institution-header" style="text-align:center;border-bottom:1.5px solid #112a4a;padding-bottom:1.2mm;margin-bottom:1.5mm;">
                <div style="font-size:11.5pt;font-weight:bold;text-transform:uppercase;color:#112a4a;">'.htmlspecialchars($institution, ENT_QUOTES, 'UTF-8').'</div>
                <div style="font-size:13pt;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#0f172a;margin:0.4mm 0;">'.htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8').'</div>
                <div style="font-size:9.5pt;font-weight:bold;color:#334155;">'.htmlspecialchars($department, ENT_QUOTES, 'UTF-8').'</div>
                <div style="text-align:left;font-size:8.5pt;font-weight:bold;margin-top:0.8mm;">Teacher: '.htmlspecialchars($teacherName, ENT_QUOTES, 'UTF-8').'</div>
            </div>
            <div style="text-align:center;padding:40px;font-size:12px;color:#64748b;">
                No scheduled academic classes or additional works found for the selected criteria and date range.
            </div>
        </div>';
    } else {
        $chunks = array_chunk($dates, 2);
        $pairIndex = 0;
        foreach ($chunks as $chunk) {
            $d1 = $chunk[0];
            $d2 = $chunk[1] ?? null;
            $pBreak = ($pairIndex > 0) ? 'page-break-before: always;' : '';
            $pairIndex++;

            // Count classes and works for d1 and d2 to dynamically size topic & remarks
            $c1Count = (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d1'" . ($teacherId>0?" AND teacher_id=$teacherId":""))->fetchColumn();
            $w1Count = (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d1'" . ($teacherId>0?" AND teacher_id=$teacherId":""))->fetchColumn();

            $c2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d2'" . ($teacherId>0?" AND teacher_id=$teacherId":""))->fetchColumn() : 0;
            $w2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d2'" . ($teacherId>0?" AND teacher_id=$teacherId":""))->fetchColumn() : 0;

            $maxClasses = max($c1Count, $c2Count);
            $maxWorks = max($w1Count, $w2Count);

            [$hTopic, $hRemarks] = calculate_page_box_heights($maxClasses, $maxWorks);

            $col1 = render_day_panel_refined($pdo, $d1, $teacherId, $hTopic, $hRemarks);
            $col2 = render_day_panel_refined($pdo, $d2, $teacherId, $hTopic, $hRemarks);

            $pagesHtml .= '
            <div class="pdf-page" style="'.$pBreak.'">
                <div class="institution-header" style="text-align:center;border-bottom:1.5px solid #112a4a;padding-bottom:1.2mm;margin-bottom:1.5mm;">
                    <div style="font-size:11.5pt;font-weight:bold;text-transform:uppercase;color:#112a4a;">'.htmlspecialchars($institution, ENT_QUOTES, 'UTF-8').'</div>
                    <div style="font-size:13pt;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#0f172a;margin:0.4mm 0;">'.htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8').'</div>
                    <div style="font-size:9.5pt;font-weight:bold;color:#334155;">'.htmlspecialchars($department, ENT_QUOTES, 'UTF-8').'</div>
                    <div style="text-align:left;font-size:8.5pt;font-weight:bold;margin-top:0.8mm;">Teacher: '.htmlspecialchars($teacherName, ENT_QUOTES, 'UTF-8').'</div>
                </div>
                <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
                    <tr>
                        '.$col1.'
                        '.$col2.'
                    </tr>
                </table>
            </div>';
        }
    }

    ob_start();
    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?=htmlspecialchars($reportTitle, ENT_QUOTES, 'UTF-8')?></title>
        <style>
            @page {
                size: 297mm 210mm;
                margin: 7mm 8mm 7mm 8mm;
            }
            * {
                box-sizing: border-box;
                -webkit-box-sizing: border-box;
            }
            body {
                font-family: Helvetica, Arial, sans-serif;
                margin: 0;
                padding: 0;
                color: #111827;
                background: #fff;
                font-size: 7.5pt;
                line-height: 1.15;
            }
            .pdf-page {
                width: 100%;
                page-break-inside: avoid;
            }
        </style>
    </head>
    <body>
        <?=$pagesHtml?>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

$dates = get_active_report_dates($pdo, '2026-10-01', '2026-10-08', 0);
$chunks = array_chunk($dates, 2);
foreach ($chunks as $i => $c) {
    $d1 = $c[0];
    $d2 = $c[1] ?? null;
    $c1Count = (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d1'")->fetchColumn();
    $w1Count = (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d1'")->fetchColumn();
    $c2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM diary WHERE diary_date='$d2'")->fetchColumn() : 0;
    $w2Count = $d2 ? (int)$pdo->query("SELECT COUNT(*) FROM additional_works WHERE work_date='$d2'")->fetchColumn() : 0;
    $maxClasses = max($c1Count, $c2Count);
    $maxWorks = max($w1Count, $w2Count);
    list($ht, $hr) = calculate_page_box_heights($maxClasses, $maxWorks);
    $col1 = render_day_panel_refined($pdo, $d1, 0, $ht, $hr);
    $col2 = render_day_panel_refined($pdo, $d2, 0, $ht, $hr);
    $pairHtml = '
    <!doctype html><html><head><style>
    @page { size: 297mm 210mm; margin: 7mm 8mm 7mm 8mm; }
    body { font-family: Helvetica; font-size: 7.5pt; margin: 0; line-height: 1.15; }
    </style></head><body>
    <div style="font-size:11.5pt;font-weight:bold;text-align:center;">LALIT CHANDRA BHARALI COLLEGE</div>
    <div style="font-size:13pt;font-weight:bold;text-align:center;">TEACHING &amp; WORK DIARY</div>
    <div style="font-size:9.5pt;font-weight:bold;text-align:center;">Department of Information Technology</div>
    <div style="font-size:8.5pt;font-weight:bold;margin-bottom:1.5mm;">Teacher: All Teachers</div>
    <table style="width:100%;border-collapse:collapse;table-layout:fixed;"><tr>'.$col1.$col2.'</tr></table>
    </body></html>';
    $pairPdf = generate_dompdf_binary($pairHtml);
    if ($i === 3) {
        file_put_contents('scratch/pair3.html', $pairHtml);
    }
    preg_match_all('/\/Type\s*\/Page\b/', $pairPdf, $mPair);
    $pCount = count($mPair[0]);
    echo "Pair $i ($d1 / " . ($d2 ?? 'blank') . ") [maxClasses=$maxClasses, maxWorks=$maxWorks, ht=$ht, hr=$hr] -> Pages: $pCount\n";
}

// -------------------------------------------------------------
// DENSE DAY TEST
// -------------------------------------------------------------
$denseDate = '2026-11-28';
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$denseDate]);
$pdo->prepare("DELETE FROM additional_works WHERE work_date=?")->execute([$denseDate]);

$tMAR = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='MAR'")->fetchColumn();
$tPLP = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='PLP'")->fetchColumn();
$validPapers = $pdo->query("SELECT id, programme_id, semester_id, name FROM papers LIMIT 7")->fetchAll();
$r1 = (int)$pdo->query("SELECT id FROM rooms LIMIT 1")->fetchColumn();

$denseClasses = [
    ['09:00:00', '10:00:00', $tMAR, $tMAR, $validPapers[0]['programme_id'], $validPapers[0]['semester_id'], $validPapers[0]['id'], $r1, 'Theory', 'Unit 1: Object-Oriented Programming Principles & Class Syntax', 30, 30, 'Conducted', 'All regular students attended punctually'],
    ['10:00:00', '11:00:00', $tMAR, $tPLP, $validPapers[1]['programme_id'], $validPapers[1]['semester_id'], $validPapers[1]['id'], $r1, 'Theory', 'Unit 1: Inheritance, Polymorphism & Virtual Functions in C++', 28, 30, 'Conducted', 'Substituted class taken by PLP due to admission duty'],
    ['11:00:00', '12:00:00', $tMAR, $tMAR, $validPapers[2]['programme_id'], $validPapers[2]['semester_id'], $validPapers[2]['id'], $r1, 'Theory', 'Unit 2: Network Layer Protocols & IPv4 / IPv6 Subnetting Architecture', 29, 30, 'Conducted', 'Conducted with practical simulation examples'],
    ['12:00:00', '13:00:00', $tMAR, $tMAR, $validPapers[3]['programme_id'], $validPapers[3]['semester_id'], $validPapers[3]['id'], $r1, 'Theory', 'Unit 3: Relational Algebra, Normalization & SQL Queries', 0, 30, 'Cancelled', 'Cancelled due to college urgent general assembly meeting'],
    ['13:00:00', '13:45:00', $tMAR, $tMAR, $validPapers[4]['programme_id'], $validPapers[4]['semester_id'], $validPapers[4]['id'], $r1, 'Theory', 'Restricted Holiday Observance / Department Review', 0, 30, 'Scheduled - Holiday', 'Holiday status recorded'],
    ['13:45:00', '14:45:00', $tMAR, $tMAR, $validPapers[5]['programme_id'], $validPapers[5]['semester_id'], $validPapers[5]['id'], $r1, 'Practical', 'Lab Exercise: Implementing Dynamic Memory Allocation & Friend Functions', 30, 30, 'Conducted', 'Practical lab session held in IT Lab 1'],
    ['14:45:00', '15:45:00', $tMAR, $tMAR, $validPapers[6]['programme_id'], $validPapers[6]['semester_id'], $validPapers[6]['id'], $r1, 'Theory', 'Unit 4: Server-Side Web Scripting with PHP and Session Management', 30, 30, 'Conducted', 'Comprehensive review and doubt clearing session']
];

foreach ($denseClasses as $c) {
    $pdo->prepare("
        INSERT INTO diary(diary_date, start_time, end_time, teacher_id, original_teacher_id, programme_id, semester_id, paper_id, room_id, class_type, topic, present, total, status, remarks, is_edited)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    ")->execute([
        $denseDate, $c[0], $c[1], $c[2], $c[3], $c[4], $c[5], $c[6], $c[7], $c[8], $c[9], $c[10], $c[11], $c[12], $c[13]
    ]);
}

$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '08:30:00', '09:00:00', ?, 'Departmental Work', 'Academic routine review and departmental log book verification', '30 mins', 'Routine task')")
    ->execute([$denseDate, $tMAR]);
$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '16:00:00', '17:00:00', ?, 'Official Meeting', 'Departmental Faculty Meeting with Academic Coordinator regarding internal exam schedule', '1 hr', 'Discussed syllabus progress')")
    ->execute([$denseDate, $tMAR]);

[$hDenseT, $hDenseR] = calculate_page_box_heights(7, 2);
$denseCol1 = render_day_panel_refined($pdo, $denseDate, $tMAR, $hDenseT, $hDenseR);
$denseCol2 = render_day_panel_refined($pdo, null, $tMAR, $hDenseT, $hDenseR);
$denseHtml = '
<!doctype html><html><head><style>
@page { size: 297mm 210mm; margin: 7mm 8mm 7mm 8mm; }
body { font-family: Helvetica; font-size: 7.5pt; margin: 0; line-height: 1.15; }
</style></head><body>
<div style="font-size:11.5pt;font-weight:bold;text-align:center;">LALIT CHANDRA BHARALI COLLEGE</div>
<div style="font-size:13pt;font-weight:bold;text-align:center;">TEACHING &amp; WORK DIARY</div>
<div style="font-size:9.5pt;font-weight:bold;text-align:center;">Department of Information Technology</div>
<div style="font-size:8.5pt;font-weight:bold;margin-bottom:1.5mm;">Teacher: Masud Alam Rofi</div>
<table style="width:100%;border-collapse:collapse;table-layout:fixed;"><tr>'.$denseCol1.$denseCol2.'</tr></table>
</body></html>';

$densePdf = generate_dompdf_binary($denseHtml);
preg_match_all('/\/Type\s*\/Page\b/', $densePdf, $mDense);
$densePages = count($mDense[0]);
echo "Dense Day (7 classes + 2 works) [ht=$hDenseT, hr=$hDenseR] -> Pages: $densePages\n";

// Clean up
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$denseDate]);
$pdo->prepare("DELETE FROM additional_works WHERE work_date=?")->execute([$denseDate]);
