<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

$pdo = db();

echo "============================================================\n";
echo "REBUILDING DATABASE WITH REAL V1.0.2 TIMETABLE DATA\n";
echo "Lalit Chandra Bharali College, Department of Information Technology\n";
echo "============================================================\n\n";

$pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

// 1. Ensure schema allows NULL teacher_id in timetable & diary for unassigned classes
$pdo->exec("ALTER TABLE timetable MODIFY teacher_id INT NULL;");
$pdo->exec("ALTER TABLE diary MODIFY teacher_id INT NULL;");

// 2. Clear test data
echo "1. Truncating test operational data...\n";
$pdo->exec("TRUNCATE TABLE diary;");
$pdo->exec("TRUNCATE TABLE overrides;");
$pdo->exec("TRUNCATE TABLE timetable;");
$pdo->exec("TRUNCATE TABLE papers;");
$pdo->exec("TRUNCATE TABLE class_strength;");
$pdo->exec("TRUNCATE TABLE rooms;");
$pdo->exec("TRUNCATE TABLE semesters;");
$pdo->exec("TRUNCATE TABLE programmes;");
$pdo->exec("TRUNCATE TABLE teachers;");
$pdo->exec("DELETE FROM users WHERE role != 'admin';");

// 3. Insert Authoritative Teachers from Annexure-I
echo "2. Seeding Authoritative Teachers (Annexure-I)...\n";
$teachersData = [
    ['code' => 'MD-IT',    'name' => 'Dr. Manisha Deka',            'dept' => 'Information Technology'],
    ['code' => 'PLP-IT',   'name' => 'Mr. Pinak Loshan Patowary',    'dept' => 'Information Technology'],
    ['code' => 'MAR-IT',   'name' => 'Mr. Masud Alam Rofi',          'dept' => 'Information Technology'],
    ['code' => 'AC-IT',    'name' => 'Mr. Abhijit Choudhury',        'dept' => 'Information Technology'],
    ['code' => 'MN-IT',    'name' => 'Mr. Manjit Kumar Nath',        'dept' => 'Information Technology'],
    ['code' => 'PPDS-CSC', 'name' => 'Mr. Prity Prakash Deva Sarma', 'dept' => 'Computer Science'],
    ['code' => 'FUA-CSC',  'name' => 'Dr. Fakhar Uddin Ahmed',       'dept' => 'Computer Science'],
    ['code' => 'BKB-MAT',  'name' => 'Dr. Bijoy Komol Bhattacharyya','dept' => 'Mathematics']
];

$insT = $pdo->prepare("INSERT INTO teachers (name, short_code, designation, active) VALUES (?, ?, NULL, 1)");
$insU = $pdo->prepare("INSERT INTO users (username, password_hash, display_name, role, teacher_id) VALUES (?, ?, ?, 'teacher', ?)");

$teacherMap = []; // code -> id
foreach ($teachersData as $t) {
    $insT->execute([$t['name'], $t['code']]);
    $tid = (int)$pdo->lastInsertId();
    $teacherMap[$t['code']] = $tid;

    // Create primary user account for teacher
    $uname = strtolower(str_replace('-', '_', $t['code']));
    $hash = password_hash($uname . '123', PASSWORD_DEFAULT);
    $insU->execute([$uname, $hash, $t['name'], $tid]);

    // Also support short alias login if applicable (e.g. mar, plp, md, ac, mn)
    $alias = strtolower(explode('-', $t['code'])[0]);
    if ($alias !== $uname) {
        $insU->execute([$alias, password_hash($alias . '123', PASSWORD_DEFAULT), $t['name'], $tid]);
    }
}
echo "   -> Seeded " . count($teacherMap) . " teacher master records.\n";

// 4. Insert Authoritative Programmes
echo "3. Seeding Programmes...\n";
$progData = [
    ['name' => 'Bachelor of Computer Applications', 'code' => 'BCA'],
    ['name' => 'Bachelor of Science in Information Technology', 'code' => 'B.Sc-IT']
];
$insP = $pdo->prepare("INSERT INTO programmes (name, short_code, active) VALUES (?, ?, 1)");
$progMap = []; // code -> id
foreach ($progData as $p) {
    $insP->execute([$p['name'], $p['code']]);
    $progMap[$p['code']] = (int)$pdo->lastInsertId();
}
echo "   -> Seeded " . count($progMap) . " programme records.\n";

// 5. Insert Authoritative Semesters
echo "4. Seeding Semesters...\n";
$semData = ['1st', '3rd', '5th'];
$insS = $pdo->prepare("INSERT INTO semesters (name, active) VALUES (?, 1)");
$semMap = []; // name -> id
foreach ($semData as $s) {
    $insS->execute([$s]);
    $semMap[$s] = (int)$pdo->lastInsertId();
}
echo "   -> Seeded " . count($semMap) . " semester records.\n";

// 6. Insert Authoritative Rooms
echo "5. Seeding Rooms...\n";
$roomData = [
    'C219', 'C220', 'C222', 'C223', 'C224', 'C225', 'LAB III', 'C219/LAB III'
];
$insR = $pdo->prepare("INSERT INTO rooms (name, room_type, active) VALUES (?, 'Classroom', 1)");
$roomMap = []; // name -> id
foreach ($roomData as $r) {
    $insR->execute([$r]);
    $roomMap[$r] = (int)$pdo->lastInsertId();
}
echo "   -> Seeded " . count($roomMap) . " room records.\n";

// 7. Insert Class Strengths
echo "6. Seeding Class Strengths...\n";
$strengths = [
    ['prog' => 'BCA', 'sem' => '1st', 'str' => 60],
    ['prog' => 'BCA', 'sem' => '3rd', 'str' => 62],
    ['prog' => 'BCA', 'sem' => '5th', 'str' => 54],
    ['prog' => 'B.Sc-IT', 'sem' => '1st', 'str' => 30],
    ['prog' => 'B.Sc-IT', 'sem' => '3rd', 'str' => 24],
    ['prog' => 'B.Sc-IT', 'sem' => '5th', 'str' => 28]
];
$insCS = $pdo->prepare("INSERT INTO class_strength (programme_id, semester_id, strength, session_name, active) VALUES (?, ?, ?, '2026-27', 1)");
foreach ($strengths as $cs) {
    $insCS->execute([$progMap[$cs['prog']], $semMap[$cs['sem']], $cs['str']]);
}
echo "   -> Seeded " . count($strengths) . " class strength records.\n";

// 8. Define and Seed Authoritative Papers
echo "7. Seeding Authoritative Papers (Source Codes)...\n";
$papersToCreate = [
    // BCA 1st
    ['BCA', '1st', 'MDC'],
    ['BCA', '1st', 'AEC'],
    ['BCA', '1st', 'MATH I'],
    ['BCA', '1st', 'C'],
    ['BCA', '1st', 'SEC'],
    ['BCA', '1st', 'VAC'],

    // BCA 3rd
    ['BCA', '3rd', 'VAC'],
    ['BCA', '3rd', 'MATH II'],
    ['BCA', '3rd', 'OOP'],
    ['BCA', '3rd', 'SEC'],
    ['BCA', '3rd', 'MDC'],
    ['BCA', '3rd', 'COA'],

    // BCA 5th
    ['BCA', '5th', 'ISCL'],
    ['BCA', '5th', 'SE'],
    ['BCA', '5th', 'CN'],
    ['BCA', '5th', 'JAVA'],

    // B.Sc-IT 1st
    ['B.Sc-IT', '1st', 'AEC'],
    ['B.Sc-IT', '1st', 'MDC'],
    ['B.Sc-IT', '1st', 'MFIT'],
    ['B.Sc-IT', '1st', 'C'],
    ['B.Sc-IT', '1st', 'SEC'],
    ['B.Sc-IT', '1st', 'VAC'],

    // B.Sc-IT 3rd
    ['B.Sc-IT', '3rd', 'VAC'],
    ['B.Sc-IT', '3rd', 'OS'],
    ['B.Sc-IT', '3rd', 'COA'],
    ['B.Sc-IT', '3rd', 'OOP'],
    ['B.Sc-IT', '3rd', 'MDC'],
    ['B.Sc-IT', '3rd', 'SEC'],

    // B.Sc-IT 5th
    ['B.Sc-IT', '5th', 'CN'],
    ['B.Sc-IT', '5th', 'JAVA'],
    ['B.Sc-IT', '5th', 'SE'],
    ['B.Sc-IT', '5th', 'ISCL']
];

$insPaper = $pdo->prepare("INSERT INTO papers (programme_id, semester_id, name, code, active) VALUES (?, ?, ?, ?, 1)");
$paperLookup = []; // "prog|sem|paper" -> id
foreach ($papersToCreate as $p) {
    $pid = $progMap[$p[0]];
    $sid = $semMap[$p[1]];
    $paperName = $p[2];
    $insPaper->execute([$pid, $sid, $paperName, $paperName]);
    $paperLookup[$p[0] . '|' . $p[1] . '|' . $paperName] = (int)$pdo->lastInsertId();
}
echo "   -> Seeded " . count($paperLookup) . " paper records.\n";

// 9. Raw Weekly Timetable Definition (128 entries)
// Day: 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri
$rawTimetable = [
    // ========================================================
    // MONDAY (Day 1)
    // ========================================================
    // BCA 1st
    [1, '09:00', '10:00', 'BCA', '1st', 'MDC', null, 'C224', 'Theory', null],
    [1, '10:00', '11:00', 'BCA', '1st', 'AEC', null, 'C224', 'Theory', null],
    [1, '11:00', '12:00', 'BCA', '1st', 'MATH I', 'BKB-MAT', 'C224', 'Theory', null],
    [1, '13:00', '14:00', 'BCA', '1st', 'C', 'PLP-IT', 'C224', 'Theory', null],
    [1, '14:00', '15:00', 'BCA', '1st', 'SEC', 'MD-IT', null, 'Practical', null],

    // BCA 3rd
    [1, '09:00', '10:00', 'BCA', '3rd', 'VAC', null, 'C222', 'Theory', null],
    [1, '10:00', '11:00', 'BCA', '3rd', 'MATH II', 'BKB-MAT', 'C222', 'Theory', null],
    [1, '11:00', '12:00', 'BCA', '3rd', 'OOP', 'MAR-IT', 'C222', 'Theory', null],
    [1, '13:00', '14:00', 'BCA', '3rd', 'SEC', 'AC-IT', 'C222', 'Practical', null],
    [1, '14:00', '15:00', 'BCA', '3rd', 'MDC', null, 'C224', 'Theory', null],

    // BCA 5th
    [1, '10:00', '11:00', 'BCA', '5th', 'ISCL', 'MN-IT', 'C223', 'Theory', null],
    [1, '11:00', '12:00', 'BCA', '5th', 'SE', 'AC-IT', 'C220', 'Theory', null],
    [1, '12:00', '13:00', 'BCA', '5th', 'CN', 'FUA-CSC', 'C224', 'Theory', null],
    [1, '14:00', '15:00', 'BCA', '5th', 'JAVA', 'MN-IT', null, 'Practical', null],

    // B.Sc-IT 1st
    [1, '09:00', '10:00', 'B.Sc-IT', '1st', 'AEC', null, 'C224', 'Theory', null],
    [1, '10:00', '11:00', 'B.Sc-IT', '1st', 'MDC', null, null, 'Theory', null],
    [1, '11:00', '12:00', 'B.Sc-IT', '1st', 'MFIT', 'PPDS-CSC', 'LAB III', 'Theory', null],
    [1, '12:00', '13:00', 'B.Sc-IT', '1st', 'C', 'MAR-IT', null, 'Practical', null],
    [1, '14:00', '15:00', 'B.Sc-IT', '1st', 'SEC', 'MD-IT', null, 'Practical', null],

    // B.Sc-IT 3rd
    [1, '09:00', '10:00', 'B.Sc-IT', '3rd', 'VAC', null, 'C222', 'Theory', null],
    [1, '10:00', '11:00', 'B.Sc-IT', '3rd', 'OS', 'MD-IT', 'C225', 'Theory', null],
    [1, '11:00', '12:00', 'B.Sc-IT', '3rd', 'COA', 'PLP-IT', 'C225', 'Theory', null],
    [1, '13:00', '14:00', 'B.Sc-IT', '3rd', 'OOP', 'MAR-IT', 'C225', 'Theory', null],
    [1, '14:00', '15:00', 'B.Sc-IT', '3rd', 'MDC', null, 'C224', 'Theory', null],

    // B.Sc-IT 5th
    [1, '10:00', '11:00', 'B.Sc-IT', '5th', 'CN', 'AC-IT', 'C220', 'Theory', null],
    [1, '11:00', '12:00', 'B.Sc-IT', '5th', 'JAVA', 'MN-IT', null, 'Practical', null],
    [1, '12:00', '13:00', 'B.Sc-IT', '5th', 'JAVA', 'MN-IT', 'C220', 'Theory', null],

    // ========================================================
    // TUESDAY (Day 2)
    // ========================================================
    // BCA 1st
    [2, '09:00', '10:00', 'BCA', '1st', 'MDC', null, 'C224', 'Theory', null],
    [2, '10:00', '11:00', 'BCA', '1st', 'AEC', null, 'C224', 'Theory', null],
    [2, '11:00', '12:00', 'BCA', '1st', 'SEC', 'MD-IT', 'C224', 'Theory', null],
    [2, '13:00', '14:00', 'BCA', '1st', 'C', 'PLP-IT', 'C224', 'Theory', null],

    // BCA 3rd
    [2, '10:00', '11:00', 'BCA', '3rd', 'MATH II', 'BKB-MAT', 'C222', 'Theory', null],
    [2, '11:00', '12:00', 'BCA', '3rd', 'OOP', 'MAR-IT', 'C222', 'Theory', null],
    [2, '12:00', '13:00', 'BCA', '3rd', 'COA', 'PLP-IT', 'C222', 'Theory', null],
    [2, '14:00', '15:00', 'BCA', '3rd', 'MDC', null, 'C224', 'Theory', null],

    // BCA 5th
    [2, '10:00', '11:00', 'BCA', '5th', 'JAVA', 'MN-IT', 'C220', 'Theory', null],
    [2, '11:00', '12:00', 'BCA', '5th', 'CN', 'FUA-CSC', 'C220', 'Theory', null],
    [2, '13:00', '14:00', 'BCA', '5th', 'SE', 'AC-IT', 'C222', 'Theory', null],
    [2, '14:00', '15:00', 'BCA', '5th', 'ISCL', 'MD-IT', 'C220', 'Theory', null],

    // B.Sc-IT 1st
    [2, '09:00', '10:00', 'B.Sc-IT', '1st', 'MDC', null, 'C224', 'Theory', null],
    [2, '10:00', '11:00', 'B.Sc-IT', '1st', 'AEC', null, 'C224', 'Theory', null],
    [2, '11:00', '12:00', 'B.Sc-IT', '1st', 'MFIT', 'PPDS-CSC', 'C225', 'Theory', null],
    [2, '12:00', '13:00', 'B.Sc-IT', '1st', 'SEC', 'MD-IT', 'C225', 'Practical', 'C225/(p)'],
    [2, '13:00', '14:00', 'B.Sc-IT', '1st', 'C', 'MAR-IT', null, 'Practical', null],

    // B.Sc-IT 3rd
    [2, '10:00', '11:00', 'B.Sc-IT', '3rd', 'COA', 'PLP-IT', 'C225', 'Theory', null],
    [2, '11:00', '12:00', 'B.Sc-IT', '3rd', 'SEC', 'PLP-IT', null, 'Practical', null],
    [2, '12:00', '13:00', 'B.Sc-IT', '3rd', 'OS', 'MD-IT', 'C225', 'Theory', null],
    [2, '13:00', '14:00', 'B.Sc-IT', '3rd', 'OOP', 'MAR-IT', null, 'Practical', null],
    [2, '14:00', '15:00', 'B.Sc-IT', '3rd', 'MDC', null, 'C224', 'Theory', null],

    // B.Sc-IT 5th
    [2, '10:00', '11:00', 'B.Sc-IT', '5th', 'CN', 'AC-IT', null, 'Practical', null],
    [2, '11:00', '12:00', 'B.Sc-IT', '5th', 'JAVA', 'MN-IT', null, 'Practical', null],
    [2, '12:00', '13:00', 'B.Sc-IT', '5th', 'SE', 'AC-IT', 'C220', 'Theory', null],
    [2, '13:00', '14:00', 'B.Sc-IT', '5th', 'ISCL', 'MN-IT', 'C220', 'Theory', null],

    // ========================================================
    // WEDNESDAY (Day 3)
    // ========================================================
    // BCA 1st
    [3, '09:00', '10:00', 'BCA', '1st', 'AEC', null, 'C224', 'Theory', null],
    [3, '10:00', '11:00', 'BCA', '1st', 'MDC', null, 'C224', 'Theory', null],
    [3, '11:00', '12:00', 'BCA', '1st', 'MATH I', 'BKB-MAT', 'C224', 'Theory', null],
    [3, '13:00', '14:00', 'BCA', '1st', 'C', 'PLP-IT', null, 'Practical', null],
    [3, '14:00', '15:00', 'BCA', '1st', 'VAC', null, 'C222', 'Theory', null],

    // BCA 3rd
    [3, '10:00', '11:00', 'BCA', '3rd', 'OOP', 'MAR-IT', 'C222', 'Theory', null],
    [3, '11:00', '12:00', 'BCA', '3rd', 'COA', 'PLP-IT', 'C222', 'Theory', null],
    [3, '13:00', '14:00', 'BCA', '3rd', 'SEC', 'AC-IT', 'C224', 'Theory', null],
    [3, '14:00', '15:00', 'BCA', '3rd', 'MDC', null, 'C223', 'Theory', null],

    // BCA 5th
    [3, '10:00', '11:00', 'BCA', '5th', 'SE', 'AC-IT', 'C220', 'Theory', null],
    [3, '11:00', '12:00', 'BCA', '5th', 'CN', 'FUA-CSC', null, 'Practical', null],
    [3, '12:00', '13:00', 'BCA', '5th', 'ISCL', 'MN-IT', 'C222', 'Theory', null],
    [3, '13:00', '14:00', 'BCA', '5th', 'JAVA', 'MN-IT', 'C222', 'Theory', null],

    // B.Sc-IT 1st
    [3, '09:00', '10:00', 'B.Sc-IT', '1st', 'AEC', null, 'C224', 'Theory', null],
    [3, '10:00', '11:00', 'B.Sc-IT', '1st', 'MDC', null, 'C224', 'Theory', null],
    [3, '12:00', '13:00', 'B.Sc-IT', '1st', 'MFIT', 'PPDS-CSC', 'C220', 'Theory', null],
    [3, '13:00', '14:00', 'B.Sc-IT', '1st', 'C', 'MAR-IT', 'C220', 'Theory', null],
    [3, '14:00', '15:00', 'B.Sc-IT', '1st', 'VAC', null, 'C222', 'Theory', null],

    // B.Sc-IT 3rd
    [3, '10:00', '11:00', 'B.Sc-IT', '3rd', 'OS', 'MD-IT', 'C225', 'Theory', null],
    [3, '11:00', '12:00', 'B.Sc-IT', '3rd', 'OOP', 'MAR-IT', 'C225', 'Theory', null],
    [3, '12:00', '13:00', 'B.Sc-IT', '3rd', 'COA', 'PLP-IT', 'C225', 'Theory', null],
    [3, '14:00', '15:00', 'B.Sc-IT', '3rd', 'MDC', null, 'C223', 'Theory', null],

    // B.Sc-IT 5th
    [3, '11:00', '12:00', 'B.Sc-IT', '5th', 'ISCL', 'MN-IT', 'C220', 'Theory', null],
    [3, '12:00', '13:00', 'B.Sc-IT', '5th', 'SE', 'AC-IT', 'C224', 'Theory', null],
    [3, '14:00', '15:00', 'B.Sc-IT', '5th', 'ISCL', 'MD-IT', 'C220', 'Theory', null],

    // ========================================================
    // THURSDAY (Day 4)
    // ========================================================
    // BCA 1st
    [4, '09:00', '10:00', 'BCA', '1st', 'AEC', null, 'C224', 'Theory', null],
    [4, '10:00', '11:00', 'BCA', '1st', 'C', 'PLP-IT', 'C224', 'Theory', null],
    [4, '11:00', '12:00', 'BCA', '1st', 'MATH I', 'BKB-MAT', 'C224', 'Theory', null],
    [4, '13:00', '14:00', 'BCA', '1st', 'SEC', 'MD-IT', 'C224', 'Practical', 'C224/(p)'],
    [4, '14:00', '15:00', 'BCA', '1st', 'VAC', null, 'C224', 'Theory', null],

    // BCA 3rd
    [4, '10:00', '11:00', 'BCA', '3rd', 'MATH II', 'BKB-MAT', 'C222', 'Theory', null],
    [4, '11:00', '12:00', 'BCA', '3rd', 'OOP', 'MAR-IT', null, 'Practical', null],
    [4, '13:00', '14:00', 'BCA', '3rd', 'COA', 'PLP-IT', 'C222', 'Theory', null],
    [4, '14:00', '15:00', 'BCA', '3rd', 'SEC', 'AC-IT', 'C222', 'Practical', 'C222/(P)'],

    // BCA 5th
    [4, '10:00', '11:00', 'BCA', '5th', 'JAVA', 'MN-IT', 'C220', 'Theory', null],
    [4, '11:00', '12:00', 'BCA', '5th', 'CN', 'FUA-CSC', 'C222', 'Theory', null],
    [4, '12:00', '13:00', 'BCA', '5th', 'ISCL', 'MN-IT', 'C222', 'Theory', null],

    // B.Sc-IT 1st
    [4, '09:00', '10:00', 'B.Sc-IT', '1st', 'AEC', null, 'C224', 'Theory', null],
    [4, '10:00', '11:00', 'B.Sc-IT', '1st', 'SEC', 'MD-IT', 'C219/LAB III', 'Theory', null],
    [4, '12:00', '13:00', 'B.Sc-IT', '1st', 'C', 'MAR-IT', 'C224', 'Theory', null],
    [4, '14:00', '15:00', 'B.Sc-IT', '1st', 'VAC', null, 'C224', 'Theory', null],

    // B.Sc-IT 3rd
    [4, '10:00', '11:00', 'B.Sc-IT', '3rd', 'OOP', 'MAR-IT', 'C225', 'Theory', null],
    [4, '11:00', '12:00', 'B.Sc-IT', '3rd', 'OS', 'MD-IT', 'C225', 'Theory', null],
    [4, '12:00', '13:00', 'B.Sc-IT', '3rd', 'COA', 'PLP-IT', 'C225', 'Theory', null],
    [4, '13:00', '14:00', 'B.Sc-IT', '3rd', 'SEC', 'PLP-IT', 'C225', 'Theory', null],

    // B.Sc-IT 5th
    [4, '11:00', '12:00', 'B.Sc-IT', '5th', 'ISCL', 'MN-IT', 'C220', 'Theory', null],
    [4, '12:00', '13:00', 'B.Sc-IT', '5th', 'CN', 'AC-IT', 'C220', 'Theory', null],
    [4, '13:00', '14:00', 'B.Sc-IT', '5th', 'SE', 'AC-IT', 'C220', 'Theory', null],
    [4, '14:00', '15:00', 'B.Sc-IT', '5th', 'JAVA', 'MN-IT', 'C220', 'Theory', null],

    // ========================================================
    // FRIDAY (Day 5)
    // ========================================================
    // BCA 1st
    [5, '09:00', '10:00', 'BCA', '1st', 'C', 'PLP-IT', null, 'Practical', null],
    [5, '10:00', '11:00', 'BCA', '1st', 'MATH I', 'BKB-MAT', 'C224', 'Theory', null],
    [5, '11:00', '12:00', 'BCA', '1st', 'SEC', 'MD-IT', 'C224', 'Theory', null],
    [5, '12:00', '13:00', 'BCA', '1st', 'SEC', 'MD-IT', null, 'Practical', null],

    // BCA 3rd
    [5, '10:00', '11:00', 'BCA', '3rd', 'MATH II', 'BKB-MAT', 'C222', 'Theory', null],
    [5, '11:00', '12:00', 'BCA', '3rd', 'COA', 'PLP-IT', 'C222', 'Theory', null],
    [5, '12:00', '13:00', 'BCA', '3rd', 'SEC', 'MAR-IT', null, 'Practical', null],
    [5, '13:00', '14:00', 'BCA', '3rd', 'VAC', null, 'C224', 'Theory', null],
    [5, '14:00', '15:00', 'BCA', '3rd', 'OOP', 'MAR-IT', null, 'Practical', null],

    // BCA 5th
    [5, '10:00', '11:00', 'BCA', '5th', 'ISCL', 'MN-IT', 'C224', 'Theory', null],
    [5, '11:00', '12:00', 'BCA', '5th', 'JAVA', 'MN-IT', null, 'Practical', null],
    [5, '12:00', '13:00', 'BCA', '5th', 'CN', 'FUA-CSC', 'C222', 'Theory', null],
    [5, '13:00', '14:00', 'BCA', '5th', 'SE', 'AC-IT', 'C222', 'Theory', null],

    // B.Sc-IT 1st
    [5, '10:00', '11:00', 'B.Sc-IT', '1st', 'SEC', 'MD-IT', 'C220', 'Theory', null],
    [5, '11:00', '12:00', 'B.Sc-IT', '1st', 'C', 'MAR-IT', 'C219/LAB III', 'Theory', null],
    [5, '13:00', '14:00', 'B.Sc-IT', '1st', 'MFIT', 'PPDS-CSC', 'C225', 'Theory', null],
    [5, '14:00', '15:00', 'B.Sc-IT', '1st', 'SEC', 'MD-IT', 'C220', 'Theory', null],

    // B.Sc-IT 3rd
    [5, '10:00', '11:00', 'B.Sc-IT', '3rd', 'OOP', 'MAR-IT', null, 'Practical', null],
    [5, '11:00', '12:00', 'B.Sc-IT', '3rd', 'OS', 'MD-IT', 'C225', 'Theory', null],
    [5, '12:00', '13:00', 'B.Sc-IT', '3rd', 'SEC', 'PLP-IT', 'C225', 'Theory', null],
    [5, '13:00', '14:00', 'B.Sc-IT', '3rd', 'VAC', null, 'C224', 'Theory', null],
    [5, '14:00', '15:00', 'B.Sc-IT', '3rd', 'SEC', 'PLP-IT', null, 'Practical', null],

    // B.Sc-IT 5th
    [5, '10:00', '11:00', 'B.Sc-IT', '5th', 'CN', 'AC-IT', 'C225', 'Theory', null],
    [5, '11:00', '12:00', 'B.Sc-IT', '5th', 'SE', 'AC-IT', 'C220', 'Theory', null],
    [5, '13:00', '14:00', 'B.Sc-IT', '5th', 'JAVA', 'MN-IT', 'C223', 'Theory', null],
    [5, '14:00', '15:00', 'B.Sc-IT', '5th', 'CN', 'AC-IT', null, 'Practical', null]
];

echo "8. Inserting 128 Authoritative Timetable Entries...\n";
$insTT = $pdo->prepare("
    INSERT INTO timetable (day_of_week, start_time, end_time, teacher_id, programme_id, semester_id, paper_id, room_id, class_type, active, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
");

$practicalCount = 0;
$blankRoomCount = 0;
$insertedCount = 0;

foreach ($rawTimetable as $row) {
    [$dow, $st, $et, $pCode, $sName, $paperCode, $tCode, $rName, $classType, $note] = $row;

    $progId = $progMap[$pCode] ?? null;
    $semId = $semMap[$sName] ?? null;
    $paperKey = $pCode . '|' . $sName . '|' . $paperCode;
    $paperId = $paperLookup[$paperKey] ?? null;
    $teacherId = $tCode ? ($teacherMap[$tCode] ?? null) : null;
    $roomId = $rName ? ($roomMap[$rName] ?? null) : null;

    if ($classType === 'Practical') {
        $practicalCount++;
    }
    if ($roomId === null) {
        $blankRoomCount++;
    }

    $insTT->execute([
        $dow,
        $st . ':00',
        $et . ':00',
        $teacherId,
        $progId,
        $semId,
        $paperId,
        $roomId,
        $classType,
        $note
    ]);
    $insertedCount++;
}

echo "   -> Inserted $insertedCount timetable entries.\n";

// 10. Update Timetable Version in settings table
$ttSettings = [
    'timetable_version_name' => 'BCA & B.Sc.-IT Aug-Dec 2026-27',
    'timetable_effective_from' => '2026-08-01',
    'timetable_effective_to' => '2026-12-31',
    'timetable_version_active' => '1',
    'timetable_version_note' => 'Official V1.0.2 timetable'
];
$insSet = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
foreach ($ttSettings as $k => $v) {
    $insSet->execute([$k, $v]);
}

$pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");

echo "\n============================================================\n";
echo "DATABASE REBUILD COMPLETED SUCCESSFULLY\n";
echo "============================================================\n";
