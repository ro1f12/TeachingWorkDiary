<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

$pdo = db();
$tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
foreach ($tables as $t) {
    echo "=== TABLE: $t ===\n";
    $cols = $pdo->query("DESCRIBE `$t`")->fetchAll();
    foreach ($cols as $c) {
        echo "  {$c['Field']} ({$c['Type']}) Null:{$c['Null']} Key:{$c['Key']} Default:{$c['Default']}\n";
    }
}
