<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/db.php';

$pdo = db();

$dayNames = [
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday'
];

$rows = $pdo->query("
    SELECT t.id, t.day_of_week, t.start_time, t.end_time,
           p.short_code as programme_code,
           s.name as semester_name,
           pa.name as paper_name,
           tc.short_code as teacher_code, tc.name as teacher_name,
           r.name as room_name,
           t.class_type,
           t.notes
    FROM timetable t
    JOIN programmes p ON p.id = t.programme_id
    JOIN semesters s ON s.id = t.semester_id
    JOIN papers pa ON pa.id = t.paper_id
    LEFT JOIN teachers tc ON tc.id = t.teacher_id
    LEFT JOIN rooms r ON r.id = t.room_id
    WHERE t.active = 1
    ORDER BY t.day_of_week, t.start_time, p.short_code, s.name
")->fetchAll();

$fp = fopen(__DIR__.'/timetable_table_full.txt', 'w');
fwrite($fp, sprintf("%-9s | %-11s | %-7s | %-4s | %-7s | %-9s | %-28s | %-15s | %-10s\n",
    "DAY", "TIME", "PROG", "SEM", "PAPER", "TEACHER", "TEACHER NAME", "ROOM", "CLASS TYPE"
));
fwrite($fp, str_repeat("-", 115) . "\n");

$currentDay = null;
foreach ($rows as $r) {
    if ($currentDay !== $r['day_of_week']) {
        $currentDay = $r['day_of_week'];
        fwrite($fp, "\n=== " . strtoupper($dayNames[$currentDay]) . " ===\n");
    }
    $time = substr($r['start_time'], 0, 5) . '–' . substr($r['end_time'], 0, 5);
    $tCode = $r['teacher_code'] ?? '—';
    $tName = $r['teacher_name'] ?? '— (Unassigned)';
    $room = $r['room_name'] ?? '— (Blank)';
    if (!empty($r['notes'])) {
        $room .= ' [' . $r['notes'] . ']';
    }
    fwrite($fp, sprintf("%-9s | %-11s | %-7s | %-4s | %-7s | %-9s | %-28s | %-15s | %-10s\n",
        $dayNames[$r['day_of_week']],
        $time,
        $r['programme_code'],
        $r['semester_name'],
        $r['paper_name'],
        $tCode,
        $tName,
        $room,
        $r['class_type']
    ));
}
fclose($fp);
echo "Written full timetable to timetable_table_full.txt (" . count($rows) . " rows).\n";
