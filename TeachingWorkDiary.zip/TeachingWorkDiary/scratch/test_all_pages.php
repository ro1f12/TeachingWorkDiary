<?php
$pages = [
    'Diary Dashboard' => ['file' => 'index.php', 'query' => ''],
    'Timetable' => ['file' => 'timetable.php', 'query' => ''],
    'Academic Holidays' => ['file' => 'holidays.php', 'query' => ''],
    'Overrides & Leave' => ['file' => 'overrides.php', 'query' => ''],
    'Assigned Duties' => ['file' => 'duties.php', 'query' => ''],
    'Additional Work' => ['file' => 'work.php', 'query' => ''],
    'Teaching Diary Report' => ['file' => 'reports.php', 'query' => ''],
    'Teachers Master' => ['file' => 'masters.php', 'query' => 'type=teachers'],
    'Programmes Master' => ['file' => 'masters.php', 'query' => 'type=programmes'],
    'Semesters Master' => ['file' => 'masters.php', 'query' => 'type=semesters'],
    'Papers Master' => ['file' => 'masters.php', 'query' => 'type=papers'],
    'Rooms Master' => ['file' => 'masters.php', 'query' => 'type=rooms'],
    'Class Strength Master' => ['file' => 'masters.php', 'query' => 'type=strength'],
    'Duty Types Master' => ['file' => 'masters.php', 'query' => 'type=duty_types'],
    'Settings & SMTP' => ['file' => 'settings.php', 'query' => ''],
    'Backup & Restore' => ['file' => 'backup.php', 'query' => ''],
];

echo "=== TESTING ALL SIDEBAR TARGETS AS ADMIN ===\n";
foreach ($pages as $name => $info) {
    $cmd = "c:\\xampp\\php\\php.exe " . escapeshellarg(__DIR__ . '/runner.php') . " " . escapeshellarg($info['file']) . " " . escapeshellarg($info['query']);
    $res = shell_exec($cmd);
    echo str_pad($name, 25) . " => " . trim($res) . "\n";
}
