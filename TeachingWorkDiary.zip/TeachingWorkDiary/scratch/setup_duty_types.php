<?php
require_once 'c:/xampp/htdocs/TeachingWorkDiary/config/db.php';
$pdo = db();

$pdo->exec("
CREATE TABLE IF NOT EXISTS duty_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    active TINYINT(1) DEFAULT 1
);
");

$defaultDutyTypes = [
    ['Invigilation Duty', 'Internal / Semester examination invigilation'],
    ['Examination Duty', 'Examination evaluation, scrutiny or administrative duty'],
    ['Admission Duty', 'Student counseling, verification and admission desk duty'],
    ['Official Meeting', 'Departmental, Governing Body, or Academic Committee meeting'],
    ['Special Duty', 'Institutional events, NAAC, or special assignments'],
    ['Departmental Work', 'Curriculum planning, departmental routine, logbook verification'],
    ['Other', 'Other approved academic or official duty']
];

$ins = $pdo->prepare("INSERT IGNORE INTO duty_types (name, description, active) VALUES (?, ?, 1)");
foreach ($defaultDutyTypes as $dt) {
    $ins->execute([$dt[0], $dt[1]]);
}

echo "duty_types table ready and seeded!\n";
