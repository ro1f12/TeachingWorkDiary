<?php
declare(strict_types=1);

require_once 'c:/xampp/htdocs/TeachingWorkDiary/config/config.php';
require_once 'c:/xampp/htdocs/TeachingWorkDiary/config/db.php';
require_once 'c:/xampp/htdocs/TeachingWorkDiary/lib/materializer.php';
require_once 'c:/xampp/htdocs/TeachingWorkDiary/report_pdf.php';

$pdo = db();
$testsPassed = 0;
$testsFailed = 0;

function assertTest(string $name, bool $condition, string $details = ''): void {
    global $testsPassed, $testsFailed;
    if ($condition) {
        echo " [PASS] $name\n";
        if ($details) echo "        $details\n";
        $testsPassed++;
    } else {
        echo " [FAIL] $name\n";
        if ($details) echo "        $details\n";
        $testsFailed++;
    }
}

function count_pdf_pages(string $pdfBinary): int {
    preg_match_all("/\/Type\s*\/Page\b/", $pdfBinary, $matches);
    return count($matches[0]);
}

echo "======================================================================\n";
echo "TEACHING & WORK DIARY — FINAL MASTER COMPREHENSIVE ACCEPTANCE TEST SUITE\n";
echo "Lalit Chandra Bharali College, Department of Information Technology\n";
echo "======================================================================\n\n";

// ---------------------------------------------------------------------
// TEST 1: Section 29 — Strict Sunday Exclusion Test
// ---------------------------------------------------------------------
echo "--- TEST 1: Section 29 — Strict Sunday Exclusion Regression Test ---\n";
materialize_range('2026-10-01', '2026-10-07');
$dates = get_active_report_dates($pdo, '2026-10-01', '2026-10-07', 0);
$expectedDates = ['2026-10-01', '2026-10-02', '2026-10-03', '2026-10-05', '2026-10-06', '2026-10-07'];

assertTest("Requested 01-10-2026 to 07-10-2026 active dates match exactly expected weekdays",
    $dates === $expectedDates,
    "Got: " . implode(', ', $dates) . " | Expected: " . implode(', ', $expectedDates)
);

assertTest("Sunday 04-10-2026 is completely absent from report dataset",
    !in_array('2026-10-04', $dates, true),
    "04-10-2026 was excluded at dataset level"
);

$htmlOct = generate_report_html($pdo, '2026-10-01', '2026-10-07', 0);
assertTest("Generated HTML contains no Sunday date panels or headers",
    !str_contains($htmlOct, '04 Oct') && !str_contains($htmlOct, '04-10-2026') && !str_contains($htmlOct, 'Sunday'),
    "No Sunday panel, header, or signature area found in HTML"
);

$pdfOct = generate_dompdf_binary($htmlOct);
$pagesOct = count_pdf_pages($pdfOct);
assertTest("6 active dates produce exactly 3 physical A4 Landscape pages (no Sunday-induced page)",
    $pagesOct === 3,
    "Generated pages: $pagesOct (Expected: 3)"
);


// ---------------------------------------------------------------------
// TEST 2: Section 30 — PDF Physical Fit Tests (Tests A, B, C, D)
// ---------------------------------------------------------------------
echo "\n--- TEST 2: Section 30 — Physical Fit Tests (A, B, C, D) ---\n";

// Test A: 2 active dates -> 1 physical page
$htmlA = generate_report_html($pdo, '2026-10-01', '2026-10-02', 0);
$pdfA = generate_dompdf_binary($htmlA);
$pagesA = count_pdf_pages($pdfA);
$datesA = get_active_report_dates($pdo, '2026-10-01', '2026-10-02', 0);
assertTest("Test A: 2 active dates -> exactly 1 physical page",
    $pagesA === 1 && count($datesA) === 2,
    "Dates: " . count($datesA) . " -> Pages: $pagesA"
);

// Test B: 4 active dates -> 2 physical pages
$htmlB = generate_report_html($pdo, '2026-10-01', '2026-10-05', 0);
$pdfB = generate_dompdf_binary($htmlB);
$pagesB = count_pdf_pages($pdfB);
$datesB = get_active_report_dates($pdo, '2026-10-01', '2026-10-05', 0);
assertTest("Test B: 4 active dates -> exactly 2 physical pages",
    $pagesB === 2 && count($datesB) === 4,
    "Dates: " . count($datesB) . " -> Pages: $pagesB"
);

// Test C: 6 active dates -> 3 physical pages
$htmlC = generate_report_html($pdo, '2026-10-01', '2026-10-07', 0);
$pdfC = generate_dompdf_binary($htmlC);
$pagesC = count_pdf_pages($pdfC);
$datesC = get_active_report_dates($pdo, '2026-10-01', '2026-10-07', 0);
assertTest("Test C: 6 active dates -> exactly 3 physical pages",
    $pagesC === 3 && count($datesC) === 6,
    "Dates: " . count($datesC) . " -> Pages: $pagesC"
);

// Test D: 7 active dates -> 4 physical pages (final page has 1 valid date + 1 blank; NO Sunday inserted)
materialize_range('2026-10-01', '2026-10-08');
$htmlD = generate_report_html($pdo, '2026-10-01', '2026-10-08', 0);
$pdfD = generate_dompdf_binary($htmlD);
$pagesD = count_pdf_pages($pdfD);
$datesD = get_active_report_dates($pdo, '2026-10-01', '2026-10-08', 0);
assertTest("Test D: 7 active dates -> exactly 4 physical pages (final page contains 1 date, no artificial Sunday)",
    $pagesD === 4 && count($datesD) === 7,
    "Dates: " . count($datesD) . " -> Pages: $pagesD"
);


// ---------------------------------------------------------------------
// TEST 3: Section 31 — Dense Data Test
// ---------------------------------------------------------------------
echo "\n--- TEST 3: Section 31 — Dense Day Overflow Test (7 Classes + Duties + Works) ---\n";
// Create a heavy dense day on 2026-11-28 (Saturday)
$denseDate = '2026-11-28';
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$denseDate]);
$pdo->prepare("DELETE FROM additional_works WHERE work_date=?")->execute([$denseDate]);

// Materialize range first, then clear auto-generated classes for this date so we can insert the precise 7 classes
materialize_range($denseDate, $denseDate);
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$denseDate]);

$tMAR = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='MAR'")->fetchColumn();
$tPLP = (int)$pdo->query("SELECT id FROM teachers WHERE short_code='PLP'")->fetchColumn();
$validPapers = $pdo->query("SELECT id, programme_id, semester_id, name FROM papers LIMIT 7")->fetchAll();
$r1 = (int)$pdo->query("SELECT id FROM rooms LIMIT 1")->fetchColumn();

// Insert exactly 7 classes:
// including long paper names, substituted class, holiday status, long remarks, lab practicals
$denseClasses = [
    ['09:00:00', '10:00:00', $tMAR, $tMAR, $validPapers[0]['programme_id'], $validPapers[0]['semester_id'], $validPapers[0]['id'], $r1, 'Theory', 'Unit 1: Object-Oriented Programming Principles & Class Syntax', 30, 30, 'Conducted', 'All regular students attended punctually'],
    ['10:00:00', '11:00:00', $tMAR, $tPLP, $validPapers[1]['programme_id'], $validPapers[1]['semester_id'], $validPapers[1]['id'], $r1, 'Theory', 'Unit 1: Inheritance, Polymorphism & Virtual Functions in C++', 28, 30, 'Conducted', 'Substituted class taken by PLP due to admission duty'],
    ['11:00:00', '12:00:00', $tMAR, $tMAR, $validPapers[2]['programme_id'], $validPapers[2]['semester_id'], $validPapers[2]['id'], $r1, 'Theory', 'Unit 2: Network Layer Protocols & IPv4 / IPv6 Subnetting Architecture', 29, 30, 'Conducted', 'Conducted with practical simulation examples'],
    ['12:00:00', '13:00:00', $tMAR, $tMAR, $validPapers[3]['programme_id'], $validPapers[3]['semester_id'], $validPapers[3]['id'], $r1, 'Theory', 'Unit 3: Relational Algebra, Normalization & SQL Queries', 0, 30, 'Cancelled', 'Cancelled due to college urgent general assembly meeting'],
    ['13:00:00', '13:45:00', $tMAR, $tMAR, $validPapers[4]['programme_id'], $validPapers[4]['semester_id'], $validPapers[4]['id'], $r1, 'Theory', 'Restricted Holiday Observance / Department Review', 0, 30, 'Scheduled - Holiday', 'Holiday status recorded'],
    ['13:45:00', '14:45:00', $tMAR, $tMAR, $validPapers[5]['programme_id'], $validPapers[5]['semester_id'], $validPapers[5]['id'], $r1, 'Practical', 'Lab Exercise: Implementing Dynamic Memory Allocation & Friend Functions', 30, 30, 'Conducted', 'Practical lab session held in IT Lab 1'],
    ['14:45:00', '15:45:00', $tMAR, $tMAR, $validPapers[6]['programme_id'], $validPapers[6]['semester_id'], $validPapers[6]['id'], $r1, 'Theory', 'Unit 4: Server-Side Web Scripting with PHP and Session Management', 30, 30, 'Conducted', 'Comprehensive review and doubt clearing session']
];

foreach ($denseClasses as $c) {
    $pdo->prepare("
        INSERT INTO diary(diary_date, start_time, end_time, teacher_id, original_teacher_id, programme_id, semester_id, paper_id, room_id, class_type, topic, present, total, status, remarks, is_edited)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    ")->execute([
        $denseDate, $c[0], $c[1], $c[2], $c[3], $c[4], $c[5], $c[6], $c[7], $c[8], $c[9], $c[10], $c[11], $c[12], $c[13]
    ]);
}

// 2 Additional works / duties
$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '08:30:00', '09:00:00', ?, 'Departmental Work', 'Academic routine review and departmental log book verification', '30 mins', 'Routine task')")
    ->execute([$denseDate, $tMAR]);
$pdo->prepare("INSERT INTO additional_works(work_date, start_time, end_time, teacher_id, work_type, details, duration, remarks) VALUES (?, '16:00:00', '17:00:00', ?, 'Official Meeting', 'Departmental Faculty Meeting with Academic Coordinator regarding internal exam schedule', '1 hr', 'Discussed syllabus progress')")
    ->execute([$denseDate, $tMAR]);

// Generate PDF for this single dense day (must fit on exactly 1 physical page)
$htmlDense = generate_report_html($pdo, $denseDate, $denseDate, $tMAR);
$pdfDense = generate_dompdf_binary($htmlDense);
$pagesDense = count_pdf_pages($pdfDense);

assertTest("Dense day with 7 classes, multiple duties, long remarks, holiday status, and substitution fits on exactly 1 physical page",
    $pagesDense === 1,
    "Generated pages: $pagesDense (Expected: 1 page)"
);

// Clean up dense day
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$denseDate]);
$pdo->prepare("DELETE FROM additional_works WHERE work_date=?")->execute([$denseDate]);


// ---------------------------------------------------------------------
// TEST 4: Class Strength Propagation & Historical Attendance
// ---------------------------------------------------------------------
echo "\n--- TEST 4: Class Strength Architecture & Historical Attendance Preservation ---\n";
$progBsc = (int)$pdo->query("SELECT id FROM programmes WHERE short_code='BSc-IT'")->fetchColumn();
$sem1st = (int)$pdo->query("SELECT id FROM semesters WHERE name='1st'")->fetchColumn();

// 1. Set initial strength to 30
$pdo->prepare("UPDATE class_strength SET strength=30 WHERE programme_id=? AND semester_id=? AND session_name='2026-27'")
    ->execute([$progBsc, $sem1st]);

$testDateHist = '2026-11-06';
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$testDateHist]);
materialize_range($testDateHist, $testDateHist);

// Confirmed historical record: 27 / 30 with is_edited = 1
$pdo->prepare("UPDATE diary SET present=27, total=30, is_edited=1 WHERE diary_date=? AND programme_id=? AND semester_id=? LIMIT 1")
    ->execute([$testDateHist, $progBsc, $sem1st]);

// Untouched auto-generated record on another date: 2026-11-13
$testDateUntouched = '2026-11-13';
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$testDateUntouched]);
materialize_range($testDateUntouched, $testDateUntouched);

// Update class strength from 30 -> 32
$pdo->prepare("UPDATE class_strength SET strength=32 WHERE programme_id=? AND semester_id=? AND session_name='2026-27'")
    ->execute([$progBsc, $sem1st]);
propagate_class_strength($pdo, $progBsc, $sem1st, '2026-27', 32);

// Check untouched record: 32/32
$chkU = $pdo->prepare("SELECT present, total, is_edited FROM diary WHERE diary_date=? AND programme_id=? AND semester_id=? LIMIT 1");
$chkU->execute([$testDateUntouched, $progBsc, $sem1st]);
$rU = $chkU->fetch();
assertTest("Untouched record automatically propagated to 32/32",
    $rU && (int)$rU['total'] === 32 && (int)$rU['present'] === 32,
    "Got: present=" . ($rU['present']??'none') . ", total=" . ($rU['total']??'none')
);

// Check confirmed historical record: preserved 27/30!
$chkH = $pdo->prepare("SELECT present, total, is_edited FROM diary WHERE diary_date=? AND programme_id=? AND semester_id=? LIMIT 1");
$chkH->execute([$testDateHist, $progBsc, $sem1st]);
$rH = $chkH->fetch();
assertTest("Confirmed historical record retained actual recorded attendance (27/30 preserved)",
    $rH && (int)$rH['present'] === 27 && (int)$rH['total'] === 30,
    "Got: present=" . ($rH['present']??'none') . ", total=" . ($rH['total']??'none')
);

// Clean up strength test
$pdo->prepare("UPDATE class_strength SET strength=30 WHERE programme_id=? AND semester_id=? AND session_name='2026-27'")
    ->execute([$progBsc, $sem1st]);
propagate_class_strength($pdo, $progBsc, $sem1st, '2026-27', 30);
$pdo->prepare("DELETE FROM diary WHERE diary_date IN (?, ?)")->execute([$testDateHist, $testDateUntouched]);


// ---------------------------------------------------------------------
// TEST 5: Teacher Substitution in Report Pipeline
// ---------------------------------------------------------------------
echo "\n--- TEST 5: Teacher Substitution in Report Pipeline ---\n";
$subDate = '2026-11-09';
$pdo->prepare("DELETE FROM overrides WHERE start_date=?")->execute([$subDate]);
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$subDate]);

// MAR substituted by PLP on Monday 2026-11-09
$pdo->prepare("INSERT INTO overrides(teacher_id, start_date, end_date, action, substitute_teacher_id, reason, active) VALUES(?, ?, ?, 'substitute', ?, 'Duty leave', 1)")
    ->execute([$tMAR, $subDate, $subDate, $tPLP]);

// Materialize full range first (never pre-filtered by teacher)
materialize_range($subDate, $subDate);

// Verify diary record has MAR original, PLP actual
$chkSub = $pdo->prepare("SELECT teacher_id, original_teacher_id FROM diary WHERE diary_date=? AND original_teacher_id=? LIMIT 1");
$chkSub->execute([$subDate, $tMAR]);
$rSub = $chkSub->fetch();
assertTest("Diary record correctly reflects Original Teacher = MAR, Actual Teacher = PLP",
    $rSub && (int)$rSub['original_teacher_id'] === $tMAR && (int)$rSub['teacher_id'] === $tPLP,
    "original_teacher_id=" . ($rSub['original_teacher_id']??'none') . ", teacher_id=" . ($rSub['teacher_id']??'none')
);

// Check PLP report includes the substituted class
$datesPLP = get_active_report_dates($pdo, $subDate, $subDate, $tPLP);
assertTest("Report pipeline for PLP includes the substituted class",
    in_array($subDate, $datesPLP, true),
    "PLP active dates: " . implode(', ', $datesPLP)
);

// Check MAR report excludes the substituted class
$datesMAR = get_active_report_dates($pdo, $subDate, $subDate, $tMAR);
assertTest("Report pipeline for MAR excludes the substituted class",
    !in_array($subDate, $datesMAR, true),
    "MAR active dates: " . implode(', ', $datesMAR)
);

// Clean up substitution
$pdo->prepare("DELETE FROM overrides WHERE start_date=?")->execute([$subDate]);
$pdo->prepare("DELETE FROM diary WHERE diary_date=?")->execute([$subDate]);


// ---------------------------------------------------------------------
// TEST 6: Official Holiday vs Restricted Holiday
// ---------------------------------------------------------------------
echo "\n--- TEST 6: Official vs Restricted Holiday Behavior ---\n";
// Gandhi Jayanti 2026-10-02 (Official Holiday)
$pdo->prepare("DELETE FROM diary WHERE diary_date='2026-10-02' AND is_edited=0")->execute();
materialize_range('2026-10-02', '2026-10-02');
$stHol = $pdo->query("SELECT status, present, total FROM diary WHERE diary_date='2026-10-02' LIMIT 1")->fetch();
assertTest("Official Holiday (02 Oct 2026) sets status 'Scheduled - Holiday' with Present=0",
    $stHol && $stHol['status'] === 'Scheduled - Holiday' && (int)$stHol['present'] === 0 && (int)$stHol['total'] > 0,
    "Status: " . ($stHol['status']??'none') . ", Present: " . ($stHol['present']??'none')
);

// Restricted holiday check: ensure restricted holidays do not automatically cancel classes
$rhRow = $pdo->query("SELECT holiday_date FROM holidays WHERE holiday_type='restricted' AND active=1 LIMIT 1")->fetch();
if ($rhRow) {
    $rhDate = $rhRow['holiday_date'];
    assertTest("Restricted holiday is separately identified in holiday master",
        !empty($rhDate),
        "Restricted holiday found on: $rhDate"
    );
}

// ---------------------------------------------------------------------
// TEST 7: Timetable Paper Validation
// ---------------------------------------------------------------------
echo "\n--- TEST 7: Paper Selection Validation (Prog + Sem) ---\n";
$pgdcaPaper = (int)$pdo->query("SELECT id FROM papers WHERE code='PGDCA-C' LIMIT 1")->fetchColumn();
$chkInvalid = $pdo->prepare("SELECT id FROM papers WHERE id=? AND programme_id=? AND semester_id=?");
$chkInvalid->execute([$pgdcaPaper, $progBsc, $sem1st]);
$isValidComb = (bool)$chkInvalid->fetchColumn();
assertTest("Paper validation prevents assigning mismatched papers across programmes/semesters",
    $isValidComb === false,
    "PGDCA paper assigned to BSc-IT 1st rejected"
);

// ---------------------------------------------------------------------
// TEST 8: Reusable Excel Exporter Tests
// ---------------------------------------------------------------------
echo "\n--- TEST 8: Reusable Excel Exporter Tests (PhpSpreadsheet) ---\n";
require_once 'c:/xampp/htdocs/TeachingWorkDiary/lib/exporter.php';
require_once 'c:/xampp/htdocs/TeachingWorkDiary/lib/importer.php';

$exporter = new AcademicExporter($pdo);

// 8.1 Timetable Template with Instructions & Reference Values
$ttTplStream = $exporter->generateTemplateBytes('timetable');
assertTest("Timetable template generated successfully with binary content",
    !empty($ttTplStream) && strlen($ttTplStream) > 2000,
    "Bytes generated: " . strlen($ttTplStream)
);

// 8.2 Teachers Export (Passwords must never be exported)
$teachersStream = $exporter->exportDataBytes('teachers');
assertTest("Teachers Excel export generated without exposing passwords",
    !empty($teachersStream) && !str_contains($teachersStream, 'password_hash'),
    "Bytes generated: " . strlen($teachersStream)
);

// 8.3 Diary Export
$diaryStream = $exporter->exportDiaryBytes(['from' => '2026-10-01', 'to' => '2026-10-07', 'teacher_id' => 0]);
assertTest("Diary Excel export generated successfully for requested date range",
    !empty($diaryStream) && strlen($diaryStream) > 2000,
    "Bytes generated: " . strlen($diaryStream)
);

// ---------------------------------------------------------------------
// TEST 9: Excel Importer & Validation Engine Tests
// ---------------------------------------------------------------------
echo "\n--- TEST 9: Excel Importer Validation & Safety Engine Tests ---\n";
$importer = new AcademicImporter($pdo);

function extract_error_messages(array $errors): string {
    $msgs = [];
    foreach ($errors as $e) {
        if (isset($e['messages']) && is_array($e['messages'])) {
            $msgs = array_merge($msgs, $e['messages']);
        } elseif (is_string($e)) {
            $msgs[] = $e;
        }
    }
    return implode('; ', $msgs);
}

// 9.1 Timetable Validation — Valid Row
$headers = ['A'=>'Session','B'=>'Programme','C'=>'Semester','D'=>'Day','E'=>'Start','F'=>'End','G'=>'Paper','H'=>'Teacher','I'=>'Room','J'=>'Type'];
$validRaw = [
    1 => $headers,
    2 => [
        'A' => '2026-27',
        'B' => 'BCA',
        'C' => '3rd',
        'D' => 1, // Monday
        'E' => '09:00',
        'F' => '10:00',
        'G' => 'Object Oriented Programming using C++',
        'H' => 'MAR',
        'I' => 'C222',
        'J' => 'Theory'
    ]
];
$valResult = $importer->validate('timetable', $validRaw);
assertTest("Timetable importer accepts valid row with correct foreign keys & mappings",
    $valResult['valid_count'] === 1 && $valResult['error_count'] === 0,
    "Valid: {$valResult['valid_count']} | Errors: {$valResult['error_count']} | " . extract_error_messages($valResult['errors'])
);

// 9.2 Timetable Validation — Mismatched Paper Rejection
$invalidPaperRaw = [
    1 => $headers,
    2 => [
        'A' => '2026-27',
        'B' => 'BCA',
        'C' => '3rd',
        'D' => 1,
        'E' => '09:00',
        'F' => '10:00',
        'G' => 'Introduction to C-Programming', // Belongs to BSc-IT 1st, NOT BCA 3rd!
        'H' => 'MAR',
        'I' => 'C222',
        'J' => 'Theory'
    ]
];
$valResultMismatch = $importer->validate('timetable', $invalidPaperRaw);
$errTextMismatch = extract_error_messages($valResultMismatch['errors']);
assertTest("Timetable importer strictly rejects paper not belonging to selected Programme and Semester",
    $valResultMismatch['error_count'] > 0 && str_contains($errTextMismatch, 'does not belong to'),
    "Errors detected: $errTextMismatch"
);

// 9.3 Timetable Validation — Invalid Time Range
$invalidTimeRaw = [
    1 => $headers,
    2 => [
        'A' => '2026-27',
        'B' => 'BCA',
        'C' => '3rd',
        'D' => 1,
        'E' => '11:00',
        'F' => '10:00', // End before Start!
        'G' => 'Object Oriented Programming using C++',
        'H' => 'MAR',
        'I' => 'C222',
        'J' => 'Theory'
    ]
];
$valResultTime = $importer->validate('timetable', $invalidTimeRaw);
$errTextTime = extract_error_messages($valResultTime['errors']);
assertTest("Timetable importer rejects invalid time range where Start Time >= End Time",
    $valResultTime['error_count'] > 0 && str_contains($errTextTime, 'must be after start time'),
    "Errors detected: $errTextTime"
);

// 9.4 Timetable Validation — Strict Sunday Exclusion in Timetable
$sundayRaw = [
    1 => $headers,
    2 => [
        'A' => '2026-27',
        'B' => 'BCA',
        'C' => '3rd',
        'D' => 7, // Sunday
        'E' => '09:00',
        'F' => '10:00',
        'G' => 'Object Oriented Programming using C++',
        'H' => 'MAR',
        'I' => 'C222',
        'J' => 'Theory'
    ]
];
$valResultSun = $importer->validate('timetable', $sundayRaw);
$errTextSun = extract_error_messages($valResultSun['errors']);
assertTest("Timetable importer strictly rejects Day 7 (Sunday) import entries",
    $valResultSun['error_count'] > 0 && str_contains($errTextSun, 'Sundays are not permitted'),
    "Errors detected: $errTextSun"
);

// 9.5 Holiday Importer — Protection of Official GU Holidays
$guHolidayRaw = [
    1 => ['A'=>'Date','B'=>'Title','C'=>'Type'],
    2 => [
        'A' => '2026-10-02',
        'B' => 'Arbitrary Replacement Holiday',
        'C' => 'Official'
    ]
];
$valHol = $importer->validate('holidays', $guHolidayRaw);
assertTest("Holiday importer handles official holiday dates safely with validation/warning",
    $valHol['total'] === 1,
    "Processed rows: {$valHol['total']}"
);

// 9.6 Transaction Rollback Simulation
// Pass an invalid record to commitImport that will trigger a DB failure
$testInvalidRow = [
    [
        'day_of_week' => 6,
        'start_time' => '07:00:00',
        'end_time' => '08:00:00',
        'teacher_id' => 9999999, // Foreign key failure!
        'programme_id' => 9999999,
        'semester_id' => 9999999,
        'paper_id' => 9999999,
        'room_id' => null,
        'class_type' => 'Theory'
    ]
];
$commitRes = $importer->commitImport('timetable', $testInvalidRow, ['mode' => 'add_new']);
assertTest("Import transaction safely catches database errors and rolls back",
    $commitRes['success'] === false && !empty($commitRes['error']),
    "Rollback error captured: " . ($commitRes['error'] ?? 'none')
);

echo "\n======================================================================\n";
echo "SUMMARY: Tests Passed: $testsPassed / " . ($testsPassed + $testsFailed) . " | Failed: $testsFailed\n";
echo "======================================================================\n";

